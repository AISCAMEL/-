<?php
/**
 * OpenRouter-powered in-site chatbot.
 *
 * Architecture: the browser never sees the API key. The chat widget POSTs the
 * conversation to a WordPress REST endpoint, which proxies the request to
 * OpenRouter server-side and returns the assistant reply.
 *
 * Configuration (priority order):
 *   1. Constant in wp-config.php:  define( 'APPREX_OPENROUTER_API_KEY', 'sk-or-...' );
 *   2. Option (Settings > APPREX チャット):  apprex_openrouter_api_key
 * Model:  constant APPREX_OPENROUTER_MODEL or option apprex_openrouter_model
 *         (default below — any OpenRouter model id is accepted).
 *
 * Local testing without network: define( 'APPREX_CHAT_MOCK', true );
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const APPREX_OPENROUTER_ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';
// 安定して使える既定モデル（OpenAI直・安価・広く利用可）。設定 > APPREX チャットで変更可。
const APPREX_OPENROUTER_DEFAULT_MODEL = 'openai/gpt-4o-mini';

/**
 * Resolve the API key from constant or option.
 *
 * @return string
 */
function apprex_openrouter_key() {
	if ( defined( 'APPREX_OPENROUTER_API_KEY' ) && APPREX_OPENROUTER_API_KEY ) {
		return (string) APPREX_OPENROUTER_API_KEY;
	}
	return (string) get_option( 'apprex_openrouter_api_key', '' );
}

/**
 * Resolve the model id.
 *
 * @return string
 */
function apprex_openrouter_model() {
	if ( defined( 'APPREX_OPENROUTER_MODEL' ) && APPREX_OPENROUTER_MODEL ) {
		return (string) APPREX_OPENROUTER_MODEL;
	}
	$opt = get_option( 'apprex_openrouter_model', '' );
	return $opt ? (string) $opt : APPREX_OPENROUTER_DEFAULT_MODEL;
}

/**
 * Whether the chatbot is operational (key present or mock mode).
 *
 * @return bool
 */
function apprex_chat_enabled() {
	return ( defined( 'APPREX_CHAT_MOCK' ) && APPREX_CHAT_MOCK ) || apprex_ai_text_ready( true );
}

/**
 * Reusable OpenRouter chat-completion call.
 *
 * @param array $messages [{role, content}, ...] including any system message.
 * @param array $args     Optional: model, temperature, max_tokens.
 * @return string|WP_Error Assistant content or error.
 */
function apprex_openrouter_complete( $messages, $args = array() ) {
	// Claude を使う文章なら Claude で作る（失敗したら OpenRouter でやり直す）。チャットは $args['chat'] = true。
	if ( function_exists( 'apprex_claude_for' ) && apprex_claude_for( ! empty( $args['chat'] ) ? 'chat' : ( ! empty( $args['article'] ) ? 'article' : ( ! empty( $args['sales'] ) ? 'sales' : false ) ) ) ) {
		$claude = apprex_claude_complete( $messages, $args );
		if ( ! is_wp_error( $claude ) || 'refusal' === $claude->get_error_code() || '' === apprex_openrouter_key() ) {
			return $claude;
		}
		unset( $args['model'], $args['effort'] );
	}
	$api_key = apprex_openrouter_key();
	if ( '' === $api_key ) {
		return new WP_Error( 'not_configured', 'OpenRouter APIキーが未設定です（設定 > APPREX チャット）。' );
	}

	$payload = array(
		'model'       => isset( $args['model'] ) ? $args['model'] : apprex_openrouter_model(),
		'messages'    => $messages,
		'temperature' => isset( $args['temperature'] ) ? (float) $args['temperature'] : 0.4,
		'max_tokens'  => isset( $args['max_tokens'] ) ? (int) $args['max_tokens'] : 600,
		// 提供終了プロバイダ等で失敗しても、生きている提供元へ自動フォールバック。
		'provider'    => isset( $args['provider'] ) ? $args['provider'] : array(
			'allow_fallbacks' => true,
		),
	);
	$payload = apply_filters( 'apprex_openrouter_payload', $payload, $args );

	$response = wp_remote_post(
		APPREX_OPENROUTER_ENDPOINT,
		array(
			'timeout' => isset( $args['timeout'] ) ? (int) $args['timeout'] : 45,
			'headers' => array(
				'Authorization' => 'Bearer ' . $api_key,
				'Content-Type'  => 'application/json',
				'HTTP-Referer'  => home_url( '/' ),
				'X-Title'       => 'APPREX',
			),
			'body'    => wp_json_encode( $payload ),
		)
	);

	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'upstream_error', '生成サービスに接続できませんでした。' );
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( 200 !== $code || empty( $body['choices'][0]['message']['content'] ) ) {
		$err    = isset( $body['error'] ) && is_array( $body['error'] ) ? $body['error'] : array();
		$detail = ! empty( $err['message'] ) ? ' ' . $err['message'] : '';
		if ( ! empty( $err['metadata']['provider_name'] ) ) {
			$detail .= ' [' . $err['metadata']['provider_name'] . ']';
		}
		if ( ! empty( $err['metadata']['raw'] ) ) {
			$raw     = $err['metadata']['raw'];
			$detail .= ' / ' . ( is_string( $raw ) ? $raw : wp_json_encode( $raw, JSON_UNESCAPED_UNICODE ) );
		}
		return new WP_Error( 'upstream_error', '生成に失敗しました（HTTP ' . $code . '）。' . $detail );
	}
	return (string) $body['choices'][0]['message']['content'];
}

/**
 * Editable knowledge base (Settings > APPREX チャット). Injected into the prompt.
 *
 * @return string
 */
function apprex_chat_knowledge() {
	return trim( (string) get_option( 'apprex_chat_knowledge', '' ) );
}

/**
 * System prompt: APPREX persona + live pricing/services + admin knowledge base.
 *
 * @return string
 */
function apprex_chat_system_prompt() {
	$pricing = apprex_pricing_summary_text();
	$links   = apprex_chat_links_text();
	$prompt  = <<<PROMPT
あなたは「合同会社アイズ」（福島県いわき市）が運営するノーコードアプリ開発「APPREX（アプリックス）」の、公式サイトと公式LINEのサポートAIです。

# 役割
- 来訪者の質問に正確・簡潔に答え、次の一歩（AIでアプリ画面を作る・無料相談・見積もり）へ自然に案内する。
- 分からないことは正直に伝え、担当者への相談を勧める。金額・仕様・日付を推測で断定しない。
- 日本語・敬体（です・ます）。絵文字は控えめ。1〜3文を基本に簡潔に。最後は相手が答えやすい質問か、次の行動の提案で終える。

# 回答の書式（チャット表示用・厳守）
- 小さなチャット欄に表示される。長文や過度な装飾は避ける。
- 箇条書きは行頭「- 」で、各項目は1行。見出しの「#」やコードブロック（```）は使わない。強調は必要なときだけ **太字**。
- リンクはURLをそのまま書く（下の「主なページ」のURLだけを使う。URLを作らない）。「こちら」だけで隠さない。

# 正しい情報の優先順位（重要）
- 料金・作り方（ノーコード／カスタマイズ／フルスクラッチ）・期間・会社情報は、この指示の「料金」「現在のサービス」を正とする。下の「追加ナレッジ」と食い違うときは、この指示を優先する。
- APPREXの導入事例・お客様の声・数字（〇〇%増など）・導入社数を作らない。「即日公開」とは言わない（最短2週間）。

# 現在のサービス
- アプリの作り方は3つ：(1)ノーコード（APPREXの基盤で作れる範囲）初期費用15万円＋月額19,800円〜、最短2週間 (2)カスタマイズ（基盤をカスタマイズ）初期費用は内容と最初のロットで別途お見積もり (3)フルスクラッチ 用途に応じて相談・お見積もり。マッチングアプリは開発費300万円〜。
- AIスタジオ（無料会員登録）：アプリの画面デザイン・試作・仕様書・概算費用をAIが作り、そのまま相談・ミーティング予約まで進める。
- ホームページ制作：担当者がヒアリングして、提案書（企画・ページ構成・デザイン案）を無料で作る。納得いただけたら月額で見積もり。制作費0円・月額 Light 9,800円／Standard 19,800円／Premium 39,800円（税抜）。契約期間は3年（36か月）で、途中で解約するときは「残りの月数×月額」の解約金がかかる。申し込みはホームページ制作のページのヒアリングフォームから。
- 公式LINEの「APPREX LABO」：LINEの友だち限定の特典として、業種と店名を入れるだけで写真入りのアプリ画面をAIが作る。アプリ集客の記事・動画、無料相談の予約もLINEの中でできる。ブラウザからは無料会員登録で使える。
- 無料オンライン相談（Google Meet・60分）：サイトかLINEで空いている日時を選んで予約。確認・前日・1時間前のお知らせが届く。
- 代理店募集：報酬・加盟金は公開しておらず、無料のオンライン説明会（LINEで予約）で説明する。チャットでは金額を答えない。
- AIMEO（AIで運用するMEO＝Googleマップ対策）、補助金の相談（持続化補助金・自治体の補助金。IT導入補助金は対象外）。
- 窓口：AIチャットは24時間。担当者の対応は平日10:00〜18:00（チャット・メール・オンライン相談）。電話窓口は無し。時間外に担当者を希望されたら、要件を伺ってメールかLINEでの相談・無料相談の予約へ案内する。

# 料金（最新・税抜）
{$pricing}

# 主なページ（案内に使うURL）
{$links}

# 案内の基本
- 興味を持った人には「AIでアプリ画面を作る（LINEのLABO／AIスタジオ）」→「無料相談の予約」の順で勧める。
- 具体的な金額を知りたい人には、見積もりページで条件を選ぶと目安が分かること、正式な金額は無料相談で出すことを伝える。
PROMPT;

	$knowledge = apprex_chat_knowledge();
	if ( '' !== $knowledge ) {
		$prompt .= "\n\n# 追加ナレッジ（運営者がWP管理画面で登録した情報。料金・作り方が上と食い違う場合は上を優先）\n" . $knowledge;
	}

	// よくある質問（学習データとして注入）。
	if ( function_exists( 'apprex_default_faqs' ) ) {
		$faqs = apprex_default_faqs();
		// 新しい料金体系・AIスタジオのFAQを優先して先頭に入れる。
		if ( function_exists( 'apprex_rn_enabled' ) && apprex_rn_enabled() ) {
			$faqs = array_merge( apprex_rn_faqs(), $faqs );
		}
		if ( $faqs ) {
			$prompt .= "\n\n# よくある質問（参考にし、自然な言葉で答える）\n";
			foreach ( $faqs as $f ) {
				$prompt .= '- Q: ' . $f['q'] . ' / A: ' . $f['a'] . "\n";
			}
		}
	}

	// 導入事例（業種の例として提示してよい）。
	$cases = get_posts( array( 'post_type' => 'case', 'posts_per_page' => 12, 'post_status' => 'publish' ) );
	if ( $cases ) {
		$prompt .= "\n# 導入事例（業種の例として挙げてよい）\n";
		foreach ( $cases as $c ) {
			$prompt .= '- ' . get_the_title( $c ) . "\n";
		}
	}

	// 後追い（リード獲得）ルール。
	$meet    = function_exists( 'apprex_meeting_url' ) ? apprex_meeting_url() : '';
	$prompt .= "\n# オリジナル／カスタムアプリのご相談（重要）\n";
	$prompt .= "- 「オリジナルアプリを作りたい」「独自アプリ」「フルスクラッチ」「マッチングアプリ」「業務システム」「こんなアプリは作れる?」など、標準プラン（ノーコード＝APPREXの基盤で作れる範囲。初期費用15万円＋月額）に収まらない開発を希望された場合は、料金を推測で断定せず、基盤のカスタマイズなら『内容と最初のロットにより別途お見積もり』、フルスクラッチなら『用途に応じてご相談のうえお見積もり』と伝える。\n";
	if ( $meet ) {
		$prompt .= "- そのうえで、まず無料のオンライン相談（Webミーティング予約：" . $meet . "）を**最優先で案内**し、要件を直接ヒアリングする流れに誘導する。見積もりフォーム（" . home_url( '/estimate/' ) . "）の『要相談メニュー』からも予約できる旨を添えてよい。\n";
	}
	$prompt .= "\n# 誘導・後追いのルール\n";
	$prompt .= "- 料金や導入に前向きな様子が見えたら、具体的に次の行動を1つ提案する（AIでアプリ画面を作る・見積もり・無料相談の予約。URLは上の「主なページ」から）。\n";
	$prompt .= "- 検討中の相手には、よろしければメールアドレスを伺い、『担当より詳しくご連絡します』と伝える（しつこくしない）。メールをいただけたら、担当からの後追い連絡・フォローメールに繋げる旨を一言添える。\n";
	$prompt .= "- お問い合わせ窓口：" . home_url( '/contact/' ) . "（電話窓口は無し）。\n";
	$prompt .= "- 個人情報（メール・電話）は、相手が自分から教えてくれた範囲で受け取る。無理に聞き出さない。\n";

	return apply_filters( 'apprex_chat_system_prompt', $prompt );
}

/** チャットで案内する主なページ（いまの設定から作る）。 */
function apprex_chat_links_text() {
	$pg   = function ( $slug, $fb ) {
		return function_exists( 'apprex_page_url' ) ? apprex_page_url( $slug ) : home_url( $fb );
	};
	$pub  = ! function_exists( 'apprex_rn_public' ) || apprex_rn_public();
	$rows = array(
		'料金'                       => $pg( 'pricing', '/pricing/' ),
		'見積もり（目安）'             => $pg( 'estimate', '/estimate/' ),
		'無料オンライン相談の予約'      => function_exists( 'apprex_meeting_url' ) ? apprex_meeting_url() : $pg( 'meeting', '/meeting/' ),
		'AIスタジオ（アプリ・無料会員登録）' => $pub && function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : $pg( 'free-trial', '/free-trial/' ),
		'ホームページ制作（ヒアリングの申し込み）' => function_exists( 'apprex_page_url' ) ? apprex_page_url( 'hp-creation' ) . '#hearing' : '',
		'公式LINE（友だち追加）'        => function_exists( 'apprex_line_url' ) ? apprex_line_url() : '',
		'LINEのAPPREX LABO（AIでアプリ画面を作る）' => function_exists( 'apprex_labo_url' ) && function_exists( 'apprex_labo_liff_id' ) && '' !== apprex_labo_liff_id() ? apprex_labo_url( 'chat' ) : '',
		'導入事例'                     => home_url( '/cases/' ),
		'代理店募集'                   => $pg( 'partner', '/partner/' ),
		'代理店説明会の予約（LINE）'     => function_exists( 'apprex_seminar_url' ) ? apprex_seminar_url() : '',
		'補助金の相談'                 => $pub ? home_url( '/subsidy/' ) : '',
		'お問い合わせ（メール）'         => $pg( 'contact', '/contact/' ),
		'会社概要'                     => $pg( 'company', '/company/' ),
	);
	$out = array();
	foreach ( $rows as $k => $v ) {
		if ( $v ) {
			$out[] = '- ' . $k . '：' . $v;
		}
	}
	return implode( "\n", $out );
}

/**
 * Register the REST route.
 */
add_action( 'rest_api_init', function () {
	register_rest_route(
		'apprex/v1',
		'/chat',
		array(
			'methods'             => 'POST',
			'callback'            => 'apprex_rest_chat',
			'permission_callback' => '__return_true', // Public widget; protected by nonce + throttle below.
		)
	);
} );

/**
 * REST handler: validate, throttle, proxy to OpenRouter.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function apprex_rest_chat( WP_REST_Request $request ) {
	// Nonce check (sent by the widget as X-WP-Nonce).
	$nonce = $request->get_header( 'x_wp_nonce' );
	if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
		return new WP_Error( 'forbidden', '不正なリクエストです。ページを再読み込みしてください。', array( 'status' => 403 ) );
	}

	// Simple per-IP throttle: max 20 requests / 60s.
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'anon';
	$key = 'apprex_chat_rl_' . md5( $ip );
	$hits = (int) get_transient( $key );
	if ( $hits >= 20 ) {
		return new WP_Error( 'rate_limited', '混み合っています。しばらくしてからお試しください。', array( 'status' => 429 ) );
	}
	set_transient( $key, $hits + 1, MINUTE_IN_SECONDS );

	// Parse + sanitize history.
	$raw = $request->get_param( 'messages' );
	if ( ! is_array( $raw ) ) {
		return new WP_Error( 'bad_request', 'メッセージがありません。', array( 'status' => 400 ) );
	}
	$messages = array();
	foreach ( array_slice( $raw, -12 ) as $m ) { // Cap history length.
		$role    = isset( $m['role'] ) && in_array( $m['role'], array( 'user', 'assistant' ), true ) ? $m['role'] : 'user';
		$content = isset( $m['content'] ) ? sanitize_textarea_field( $m['content'] ) : '';
		$content = mb_substr( $content, 0, 2000 ); // Cap message length.
		if ( '' !== $content ) {
			$messages[] = array( 'role' => $role, 'content' => $content );
		}
	}
	if ( empty( $messages ) ) {
		return new WP_Error( 'bad_request', 'メッセージが空です。', array( 'status' => 400 ) );
	}

	$session = sanitize_text_field( (string) $request->get_param( 'session' ) );

	// 会話ログ：今回のお客様の発言を記録（AI／有人対応いずれの場合も残す）。
	if ( function_exists( 'apprex_chat_log_append' ) ) {
		$last_user = end( $messages );
		reset( $messages );
		if ( $last_user && 'user' === $last_user['role'] ) {
			apprex_chat_log_append( $session, 'お客様', $last_user['content'] );
		}
	}
	// 社内への通知（inc/notify-hub.php）。
	$apprex_lu = end( $messages );
	reset( $messages );
	if ( $apprex_lu && 'user' === $apprex_lu['role'] ) {
		$apprex_nu = count( array_filter( $messages, function ( $m ) { return 'user' === $m['role']; } ) );
		do_action( 'apprex_chat_user_message', $session, $apprex_lu['content'], $apprex_nu );
	}

	// オペレーター連携：発言を Slack へ転送。有人対応中ならAI応答を止める。
	if ( function_exists( 'apprex_chat_op_ingest' ) ) {
		$is_human = apprex_chat_op_ingest( $session, $messages );
		if ( $is_human ) {
			return rest_ensure_response( array( 'reply' => '', 'human' => true ) );
		}
	}

	// Mock mode for local/dev without network.
	if ( defined( 'APPREX_CHAT_MOCK' ) && APPREX_CHAT_MOCK ) {
		$last = end( $messages );
		return rest_ensure_response(
			array(
				'reply' => apprex_chat_mock_reply( $last['content'] ),
				'mock'  => true,
			)
		);
	}

	if ( ! apprex_ai_text_ready( true ) ) {
		return new WP_Error( 'not_configured', 'チャットは現在準備中です。お問い合わせフォームをご利用ください。', array( 'status' => 503 ) );
	}

	// 毎回同じ指示（$system）と、人・ページで変わる指示（$extra）を分けて渡す（Claude の使い回しのため）。
	$system = apprex_chat_system_prompt();
	$extra  = '';
	// 会員ログイン連携：ログイン中の契約者なら本人の契約情報を文脈に追加。
	if ( function_exists( 'apprex_chat_member_context' ) ) {
		$member_ctx = apprex_chat_member_context();
		if ( '' !== $member_ctx ) {
			$extra .= "\n\n# ログイン中の契約者情報（本人にのみ案内してよい）\n" . $member_ctx;
		}
	}
	// ログイン中の会員の、アプリ制作の進み具合とスケジュール（inc/project-status.php）。
	if ( is_user_logged_in() && function_exists( 'apprex_prod_ai_context' ) ) {
		$prod_ctx = apprex_prod_ai_context( wp_get_current_user() );
		if ( '' !== $prod_ctx ) {
			$extra .= "\n\n" . $prod_ctx . "\n（ログイン中のご本人の記録なので、本人にだけ具体的に案内してよい）";
		}
	}

	// ページに合わせた案内（AIスタジオでは今いる工程のマニュアルを渡す）。
	if ( function_exists( 'apprex_chat_page_prompt' ) ) {
		$page_key = sanitize_key( (string) $request->get_param( 'page' ) );
		$page_ctx = apprex_chat_page_prompt( $page_key, sanitize_key( (string) $request->get_param( 'step' ) ), absint( $request->get_param( 'post' ) ) );
		if ( '' !== $page_ctx ) {
			$extra .= "\n\n# このページでの案内（最優先で従う）\n" . $page_ctx;
		}
	}

	$payload_messages = array_merge(
		array( array( 'role' => 'system', 'content' => $system ) ),
		'' !== $extra ? array( array( 'role' => 'system', 'content' => trim( $extra ) ) ) : array(),
		$messages
	);
	$reply = apprex_openrouter_complete(
		$payload_messages,
		array( 'temperature' => 0.3, 'max_tokens' => 600, 'timeout' => 30, 'chat' => true )
	);

	// 設定モデルが利用不可などで失敗した場合、安全な既定モデルで自動再試行（全件フォーム誘導の回避）。
	if ( is_wp_error( $reply ) && apprex_openrouter_model() !== APPREX_OPENROUTER_DEFAULT_MODEL ) {
		$reply = apprex_openrouter_complete(
			$payload_messages,
			array( 'model' => APPREX_OPENROUTER_DEFAULT_MODEL, 'temperature' => 0.3, 'max_tokens' => 600, 'timeout' => 30, 'chat' => true )
		);
	}

	if ( is_wp_error( $reply ) ) {
		return new WP_Error( 'upstream_error', 'ただいま応答できませんでした。お手数ですがお問い合わせフォームをご利用ください。', array( 'status' => 502 ) );
	}

	// 学習・後追い：会話ログ保存＋メール検出によるリード獲得。
	$captured = false;
	if ( function_exists( 'apprex_chat_after_reply' ) ) {
		$captured = apprex_chat_after_reply( $messages, $reply, $session );
	}

	// オペレーター連携：AI応答もスレッドへ記録（担当者の文脈把握用）。
	if ( function_exists( 'apprex_chat_op_log_ai_reply' ) ) {
		apprex_chat_op_log_ai_reply( $session, $reply );
	}

	$out = array( 'reply' => $reply );
	if ( function_exists( 'apprex_chat_suggestions' ) ) {
		$out['suggestions'] = apprex_chat_suggestions();
	}
	// ページに合わせたリンクボタン（AIスタジオなら今の画面のマニュアル等）。
	if ( function_exists( 'apprex_chat_page_links' ) && isset( $page_key ) ) {
		$links = apprex_chat_page_links( $page_key, sanitize_key( (string) $request->get_param( 'step' ) ) );
		if ( $links ) {
			$out['suggestions'] = $links;
		}
	}
	if ( $captured ) {
		$out['lead_captured'] = true;
	}
	return rest_ensure_response( $out );
}

/**
 * Canned reply for mock mode (UI/plumbing verification).
 *
 * @param string $msg User message.
 * @return string
 */
function apprex_chat_mock_reply( $msg ) {
	if ( false !== mb_strpos( $msg, '料金' ) || false !== mb_strpos( $msg, '見積' ) ) {
		return "アプリ開発は月額19,800円〜、初期費用15万円（ノーコード＝APPREXの基盤で作れる範囲。デザイン・仕様書づくりはAIスタジオで無料）です。基盤のカスタマイズは別途お見積もり、フルスクラッチはご相談です。サービスやオプションを選ぶと概算が出る「見積もりフォーム」から、そのまま発注まで進めます。ご案内しましょうか？【モック応答】";
	}
	return "ご質問ありがとうございます。APPREX はノーコードでiOS/Androidアプリを最短2週間で公開できます。詳しくは見積もりフォームや無料体験もご利用ください。【モック応答】";
}

/**
 * Minimal settings page: Settings > APPREX チャット.
 */
add_action( 'admin_menu', function () {
	add_options_page( 'APPREX チャット設定', 'APPREX チャット', 'manage_options', 'apprex-chat', 'apprex_chat_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'apprex_chat', 'apprex_openrouter_api_key', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'apprex_chat', 'apprex_openrouter_model', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'apprex_chat', 'apprex_chat_knowledge', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
	register_setting( 'apprex_chat', 'apprex_chat_sdr', array( 'sanitize_callback' => 'absint', 'default' => 1 ) );
	register_setting( 'apprex_chat', 'apprex_studio_model', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'apprex_chat', 'apprex_bulk_image_model', array( 'sanitize_callback' => 'sanitize_text_field' ) );
} );

/**
 * Render the settings page.
 */
function apprex_chat_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$key_from_const = defined( 'APPREX_OPENROUTER_API_KEY' ) && APPREX_OPENROUTER_API_KEY;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'APPREX チャット・AI設定', 'apprex' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'apprex_chat' ); ?>
			<table class="form-table" role="presentation">
				<?php if ( function_exists( 'apprex_claude_settings_rows' ) ) { apprex_claude_settings_rows(); } ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'OpenRouter APIキー', 'apprex' ); ?></th>
					<td>
						<?php if ( $key_from_const ) : ?>
							<p><em><?php esc_html_e( 'wp-config.php の APPREX_OPENROUTER_API_KEY で設定済みです（こちらが優先されます）。', 'apprex' ); ?></em></p>
						<?php else : ?>
							<input type="password" name="apprex_openrouter_api_key" value="<?php echo esc_attr( get_option( 'apprex_openrouter_api_key', '' ) ); ?>" class="regular-text" autocomplete="off">
							<p class="description"><?php esc_html_e( 'sk-or- から始まるキー。セキュリティ上、可能なら wp-config.php の定数での設定を推奨します。', 'apprex' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'チャット用モデル', 'apprex' ); ?></th>
					<td>
						<input type="text" name="apprex_openrouter_model" value="<?php echo esc_attr( get_option( 'apprex_openrouter_model', '' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( APPREX_OPENROUTER_DEFAULT_MODEL ); ?>">
						<p class="description"><?php printf( esc_html__( '未入力時は %s。任意の OpenRouter モデルID（例：google/gemini-flash-1.5、deepseek/deepseek-chat 等）を指定できます。', 'apprex' ), esc_html( APPREX_OPENROUTER_DEFAULT_MODEL ) ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'AIスタジオ用モデル（文章）', 'apprex' ); ?></th>
					<td>
						<input type="text" name="apprex_studio_model" value="<?php echo esc_attr( get_option( 'apprex_studio_model', '' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( APPREX_STUDIO_DEFAULT_MODEL ); ?>">
						<p class="description"><?php printf( esc_html__( 'AIデザイナー・オリジナルアプリの試作・仕様定義書・AI企画書に使います。未入力時は %s。うまく動かないときはチャット用モデルで自動的にやり直します。', 'apprex' ), esc_html( APPREX_STUDIO_DEFAULT_MODEL ) ); ?></p>
						<?php $apprex_oe = get_option( 'apprex_orig_last_error' ); ?>
						<?php if ( is_array( $apprex_oe ) && ! empty( $apprex_oe['why'] ) ) : ?>
							<p class="description" style="color:#b32d2e"><?php echo esc_html( '最後にマッチング・オリジナルの試作をAIで作れなかったとき（' . $apprex_oe['t'] . '）：' . $apprex_oe['why'] ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '画像モデル', 'apprex' ); ?></th>
					<td>
						<p style="margin-top:0"><?php echo esc_html( '通常（メインビジュアル・アイコン・画面デザイン・ブログ）：' . apprex_image_model() ); ?><br><span class="description"><?php esc_html_e( '変更は「投稿 > AI記事生成」の画像モデル欄で行えます。', 'apprex' ); ?></span></p>
						<input type="text" name="apprex_bulk_image_model" value="<?php echo esc_attr( get_option( 'apprex_bulk_image_model', '' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( APPREX_BULK_IMAGE_DEFAULT_MODEL ); ?>">
						<p class="description"><?php printf( esc_html__( '枚数の多い画像（オリジナルアプリの試作に入れる写真）に使うモデル。未入力時は %s。', 'apprex' ), esc_html( APPREX_BULK_IMAGE_DEFAULT_MODEL ) ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'ナレッジ（チャット学習内容）', 'apprex' ); ?></th>
					<td>
						<textarea name="apprex_chat_knowledge" rows="10" class="large-text" placeholder="<?php esc_attr_e( '例）よくある質問と回答、キャンペーン情報、対応業種、納期の目安、注意事項 など。ここに書いた内容をチャットボットが最優先で参照して回答します。', 'apprex' ); ?>"><?php echo esc_textarea( get_option( 'apprex_chat_knowledge', '' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'チャットボットに覚えさせたい自社情報・FAQ・ルールを自由に記載してください（WP側で随時更新＝学習）。', 'apprex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'AI自動アポ獲得モード', 'apprex' ); ?></th>
					<td>
						<label><input type="checkbox" name="apprex_chat_sdr" value="1" <?php checked( 1, (int) get_option( 'apprex_chat_sdr', 1 ) ); ?>> <?php esc_html_e( '有効にする（AIが要件をヒアリングし、概算提示→無料相談の予約へ誘導）', 'apprex' ); ?></label>
						<p class="description"><?php esc_html_e( 'ONにすると、チャットが受け身の回答だけでなく、業種・目的・時期などを自然に質問し、最終的にWebミーティング予約や連絡先の取得（アポ獲得）へ導きます。', 'apprex' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php if ( function_exists( 'apprex_claude_test_box' ) ) { apprex_claude_test_box(); } ?>

		<hr>
		<h2 id="apprex-image-compare"><?php esc_html_e( '画像モデルの比較テスト', 'apprex' ); ?></h2>
		<p><?php esc_html_e( '同じお題で、指定したモデルそれぞれに1枚ずつ画像を作り、仕上がりと実際の請求額（OpenRouterの応答に含まれる金額）を並べて表示します。1回のテストで、モデルの数だけ費用がかかります。', 'apprex' ); ?></p>
		<?php $apprex_cmp = get_transient( 'apprex_image_compare_' . get_current_user_id() ); ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="apprex_image_compare">
			<?php wp_nonce_field( 'apprex_image_compare' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'お題', 'apprex' ); ?></th><td><textarea name="prompt" rows="3" class="large-text"><?php echo esc_textarea( $apprex_cmp ? $apprex_cmp['prompt'] : '日本の焼肉店のアプリのメインビジュアル。炭火で焼ける上質な和牛、落ち着いた高級感のある店内、写真風、横長16:9、文字は入れない。' ); ?></textarea></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'モデル（1行に1つ）', 'apprex' ); ?></th><td><textarea name="models" rows="3" class="large-text code"><?php echo esc_textarea( $apprex_cmp ? implode( "\n", wp_list_pluck( $apprex_cmp['rows'], 'model' ) ) : APPREX_IMAGE_DEFAULT_MODEL . "\n" . APPREX_BULK_IMAGE_DEFAULT_MODEL ); ?></textarea></td></tr>
			</table>
			<?php submit_button( __( '比較テストを実行', 'apprex' ), 'secondary' ); ?>
		</form>
		<?php if ( $apprex_cmp ) : ?>
			<div style="display:flex;flex-wrap:wrap;gap:16px">
				<?php foreach ( $apprex_cmp['rows'] as $r ) : ?>
					<div style="width:300px;background:#fff;border:1px solid #dcdcde;padding:10px">
						<strong><?php echo esc_html( $r['model'] ); ?></strong><br>
						<?php if ( ! empty( $r['url'] ) ) : ?>
							<a href="<?php echo esc_url( $r['url'] ); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url( $r['url'] ); ?>" alt="" style="width:100%;height:auto;margin:6px 0"></a>
							<?php echo esc_html( sprintf( '時間：%.1f秒／請求額：%s', $r['sec'], null === $r['cost'] ? '（応答に金額なし）' : '$' . number_format( $r['cost'], 4 ) ) ); ?>
						<?php else : ?>
							<p style="color:#b32d2e"><?php echo esc_html( $r['error'] ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

/* 画像モデルの比較テスト（管理者のみ）。 */
add_action( 'admin_post_apprex_image_compare', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( '権限がありません。', 'apprex' ) );
	}
	check_admin_referer( 'apprex_image_compare' );
	$prompt = sanitize_textarea_field( wp_unslash( isset( $_POST['prompt'] ) ? $_POST['prompt'] : '' ) );
	$models = array_slice( array_filter( array_map( 'trim', explode( "\n", sanitize_textarea_field( wp_unslash( isset( $_POST['models'] ) ? $_POST['models'] : '' ) ) ) ) ), 0, 4 );
	$rows   = array();
	foreach ( $models as $model ) {
		$t0  = microtime( true );
		$img = apprex_openrouter_image( $prompt, array( 'model' => $model ) );
		$row = array( 'model' => $model, 'sec' => microtime( true ) - $t0, 'cost' => null, 'url' => '', 'error' => '' );
		if ( is_wp_error( $img ) ) {
			$row['error'] = $img->get_error_message();
		} else {
			$att = apprex_save_generated_image( $img, '画像モデル比較-' . sanitize_title( $model ) );
			$row['url']  = is_wp_error( $att ) ? '' : wp_get_attachment_url( $att );
			$row['cost'] = $img['cost'];
		}
		$rows[] = $row;
	}
	set_transient( 'apprex_image_compare_' . get_current_user_id(), array( 'prompt' => $prompt, 'rows' => $rows ), DAY_IN_SECONDS );
	wp_safe_redirect( admin_url( 'options-general.php?page=apprex-chat#apprex-image-compare' ) );
	exit;
} );

/**
 * 画像生成モデル（既定：Gemini Image「Nano Banana」）。
 *
 * @return string
 */
function apprex_image_model() {
	$opt = get_option( 'apprex_image_model', '' );
	return $opt ? (string) $opt : APPREX_IMAGE_DEFAULT_MODEL;
}

/* 用途別の既定モデル（OpenRouter のモデルID）。設定 > APPREX チャット で変更できる。 */
const APPREX_IMAGE_DEFAULT_MODEL      = 'google/gemini-3.1-flash-image'; // Nano Banana 2：メインビジュアル・アイコンなど。
const APPREX_BULK_IMAGE_DEFAULT_MODEL = 'openai/gpt-image-2';            // 枚数の多い画像（試作の写真など）。
const APPREX_STUDIO_DEFAULT_MODEL     = 'anthropic/claude-sonnet-5.5';   // AIデザイナー・試作・仕様定義書。

/** 枚数の多い画像に使うモデル。 */
function apprex_bulk_image_model() {
	$opt = trim( (string) get_option( 'apprex_bulk_image_model', '' ) );
	return $opt ? $opt : APPREX_BULK_IMAGE_DEFAULT_MODEL;
}

/** AIスタジオ（AIデザイナー・試作・仕様定義書）に使う文章モデル。 */
function apprex_studio_text_model() {
	$opt = trim( (string) get_option( 'apprex_studio_model', '' ) );
	return $opt ? $opt : APPREX_STUDIO_DEFAULT_MODEL;
}

/**
 * AIスタジオ用の文章生成。スタジオ用モデルで失敗したら、チャット用モデルで再試行する。
 *
 * @param array $messages メッセージ。
 * @param array $args     temperature / max_tokens / timeout。
 * @return string|WP_Error
 */
function apprex_studio_complete( $messages, $args = array() ) {
	if ( function_exists( 'apprex_claude_for' ) && apprex_claude_for( false ) ) {
		return apprex_openrouter_complete( $messages, array_merge( $args, array( 'model' => apprex_claude_studio_model(), 'effort' => 'medium' ) ) );
	}
	$res = apprex_openrouter_complete( $messages, array_merge( $args, array( 'model' => apprex_studio_text_model() ) ) );
	if ( is_wp_error( $res ) && apprex_studio_text_model() !== apprex_openrouter_model() ) {
		$res = apprex_openrouter_complete( $messages, $args );
	}
	return $res;
}

/**
 * OpenRouter のさまざまな応答形から画像URL（data: または http）を取り出す。
 *
 * @param array $body デコード済みレスポンス。
 * @return string URL（無ければ空文字）。
 */
function apprex_extract_image_url( $body ) {
	if ( ! is_array( $body ) ) {
		return '';
	}
	$msg = isset( $body['choices'][0]['message'] ) ? $body['choices'][0]['message'] : array();

	// 1) message.images[].image_url.url（OpenRouter 標準）。
	if ( ! empty( $msg['images'] ) && is_array( $msg['images'] ) ) {
		foreach ( $msg['images'] as $im ) {
			if ( ! empty( $im['image_url']['url'] ) ) {
				return (string) $im['image_url']['url'];
			}
			if ( ! empty( $im['url'] ) ) {
				return (string) $im['url'];
			}
		}
	}
	// 2) message.content が配列（type=image_url / image）の場合。
	if ( ! empty( $msg['content'] ) && is_array( $msg['content'] ) ) {
		foreach ( $msg['content'] as $part ) {
			if ( ! empty( $part['image_url']['url'] ) ) {
				return (string) $part['image_url']['url'];
			}
			if ( isset( $part['type'] ) && 'image' === $part['type'] && ! empty( $part['source']['data'] ) ) {
				$mime = isset( $part['source']['media_type'] ) ? $part['source']['media_type'] : 'image/png';
				return 'data:' . $mime . ';base64,' . $part['source']['data'];
			}
		}
	}
	// 3) 画像生成API互換（data[0].b64_json / url）。
	if ( ! empty( $body['data'][0]['b64_json'] ) ) {
		return 'data:image/png;base64,' . $body['data'][0]['b64_json'];
	}
	if ( ! empty( $body['data'][0]['url'] ) ) {
		return (string) $body['data'][0]['url'];
	}
	return '';
}

/**
 * OpenRouter で画像を生成（Nano Banana 等の画像出力モデル）。
 *
 * @param string $prompt 画像の指示文。
 * @param array  $args   model 等。
 * @return array|WP_Error { mime, data(binary) } または WP_Error。
 */
function apprex_openrouter_image( $prompt, $args = array() ) {
	$key = apprex_openrouter_key();
	if ( '' === $key ) {
		return new WP_Error( 'not_configured', 'OpenRouter APIキーが未設定です。' );
	}
	$payload = array(
		'model'      => isset( $args['model'] ) ? $args['model'] : apprex_image_model(),
		'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
		'modalities' => array( 'image', 'text' ),
		'usage'      => array( 'include' => true ), // 実際の請求額を応答に含める。
	);
	$resp = wp_remote_post(
		APPREX_OPENROUTER_ENDPOINT,
		array(
			'timeout' => 120,
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Content-Type'  => 'application/json',
				'HTTP-Referer'  => home_url( '/' ),
				'X-Title'       => 'APPREX',
			),
			'body'    => wp_json_encode( $payload ),
		)
	);
	if ( is_wp_error( $resp ) ) {
		return new WP_Error( 'upstream_error', '画像生成サービスに接続できませんでした：' . $resp->get_error_message() );
	}
	$code = (int) wp_remote_retrieve_response_code( $resp );
	$body = json_decode( wp_remote_retrieve_body( $resp ), true );

	// API がエラーを返したら、その内容をそのまま伝える（診断しやすく）。
	if ( 200 !== $code || isset( $body['error'] ) ) {
		$detail = isset( $body['error']['message'] ) ? $body['error']['message'] : ( 'HTTP ' . $code );
		return new WP_Error( 'upstream_error', 'モデル「' . $payload['model'] . '」でエラー：' . $detail );
	}

	$url = apprex_extract_image_url( $body );
	if ( '' === $url ) {
		// テキストだけ返ってきた等：本文の冒頭を手掛かりに返す。
		$txt = isset( $body['choices'][0]['message']['content'] ) && is_string( $body['choices'][0]['message']['content'] )
			? mb_substr( trim( $body['choices'][0]['message']['content'] ), 0, 120 )
			: '';
		return new WP_Error( 'no_image', 'モデル「' . $payload['model'] . '」が画像を返しませんでした（画像出力対応モデルかご確認ください）。' . ( $txt ? ' 応答: ' . $txt : '' ) );
	}
	if ( 0 !== strpos( $url, 'data:' ) ) {
		// http(s) URL で返るモデルにも対応：取得して data 化。
		$bin = wp_remote_retrieve_body( wp_remote_get( $url, array( 'timeout' => 60 ) ) );
		if ( '' === $bin ) {
			return new WP_Error( 'no_image', '画像URLを取得できませんでした。' );
		}
		return array( 'mime' => 'image/png', 'data' => $bin, 'cost' => isset( $body['usage']['cost'] ) ? (float) $body['usage']['cost'] : null, 'model' => $payload['model'] );
	}
	if ( ! preg_match( '#^data:(image/[a-zA-Z0-9.+-]+);base64,(.+)$#s', $url, $m ) ) {
		return new WP_Error( 'bad_image', '画像データの形式が不正です。' );
	}
	$bin = base64_decode( $m[2], true );
	if ( false === $bin ) {
		return new WP_Error( 'bad_image', '画像データをデコードできませんでした。' );
	}
	return array( 'mime' => $m[1], 'data' => $bin, 'cost' => isset( $body['usage']['cost'] ) ? (float) $body['usage']['cost'] : null, 'model' => $payload['model'] );
}

/**
 * 生成画像をメディアに保存し添付IDを返す。
 *
 * @param array  $image   { mime, data }。
 * @param string $title   タイトル。
 * @param int    $parent  親投稿ID。
 * @return int|WP_Error
 */
function apprex_save_generated_image( $image, $title = 'apprex-ai', $parent = 0 ) {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$ext      = ( false !== strpos( $image['mime'], 'png' ) ) ? 'png' : ( ( false !== strpos( $image['mime'], 'webp' ) ) ? 'webp' : 'jpg' );
	$filename = sanitize_title( $title ) . '-' . wp_generate_password( 6, false ) . '.' . $ext;
	$upload   = wp_upload_bits( $filename, null, $image['data'] );
	if ( ! empty( $upload['error'] ) ) {
		return new WP_Error( 'save_failed', $upload['error'] );
	}
	$attach_id = wp_insert_attachment(
		array(
			'post_mime_type' => $image['mime'],
			'post_title'     => $title,
			'post_status'    => 'inherit',
		),
		$upload['file'],
		$parent
	);
	if ( is_wp_error( $attach_id ) || ! $attach_id ) {
		return new WP_Error( 'attach_failed', 'メディア登録に失敗しました。' );
	}
	wp_update_attachment_metadata( $attach_id, wp_generate_attachment_metadata( $attach_id, $upload['file'] ) );
	return $attach_id;
}
