<?php
/**
 * Native forms (お問い合わせ / 資料請求 / 無料体験), lead storage, auto-reply,
 * 1-year step-mail (drip) sequence, and LINE誘導.
 *
 * - CPT apprex_inquiry stores every submission.
 * - REST POST /apprex/v1/inquiry handles all form types.
 * - On submit: immediate auto-reply to the customer + admin notification.
 * - A daily cron sends scheduled step mails up to 1 year.
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------------
 * Settings: LINE URL / 通知先 / 資料DL URL
 * ---------------------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_options_page( 'APPREX 連携設定', 'APPREX 連携', 'manage_options', 'apprex-integrations', 'apprex_integrations_page' );
} );
add_action( 'admin_init', function () {
	register_setting( 'apprex_integrations', 'apprex_line_url', array( 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'apprex_integrations', 'apprex_notify_email', array( 'sanitize_callback' => 'sanitize_email' ) );
	register_setting( 'apprex_integrations', 'apprex_document_url', array( 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'apprex_integrations', 'apprex_meeting_url', array( 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'apprex_integrations', 'apprex_drip_enabled', array( 'sanitize_callback' => 'absint' ) );
	register_setting( 'apprex_integrations', 'apprex_wp_meeting_reminders', array( 'sanitize_callback' => 'absint' ) );
	register_setting( 'apprex_integrations', 'apprex_gas_webhook_url', array( 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'apprex_integrations', 'apprex_gas_token', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'apprex_integrations', 'apprex_gsc_verify', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'apprex_integrations', 'apprex_twitter', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'apprex_integrations', 'apprex_slack_webhook', array( 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'apprex_integrations', 'apprex_social_login_shortcode', array( 'sanitize_callback' => 'wp_kses_post' ) );
	register_setting( 'apprex_integrations', 'apprex_preview_app_ios', array( 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'apprex_integrations', 'apprex_preview_app_android', array( 'sanitize_callback' => 'esc_url_raw' ) );
} );

/**
 * Render the integrations settings page.
 */
function apprex_integrations_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'APPREX 連携設定（LINE / メール / 資料）', 'apprex' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'apprex_integrations' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'LINE 公式アカウント URL', 'apprex' ); ?></th>
					<td><input type="url" name="apprex_line_url" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_line_url', '' ) ); ?>" placeholder="https://lin.ee/xxxxxxx">
					<p class="description"><?php esc_html_e( '設定すると、チャット・フォーム・資料請求にLINE誘導ボタンが表示されます。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'ソーシャルログイン ショートコード', 'apprex' ); ?></th>
					<td><input type="text" name="apprex_social_login_shortcode" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_social_login_shortcode', '' ) ); ?>" placeholder="[nextend_social_login] など">
					<p class="description"><?php esc_html_e( '会員マイページ（/mypage）のログイン画面に表示するソーシャルログインのショートコード。導入プラグインのショートコード（例：[nextend_social_login]）を貼ると、Google/LINE/Apple/Facebook 等のボタンが表示されます。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'LINE配信バナー：バッジ文言', 'apprex' ); ?></th>
					<td><input type="text" name="apprex_line_badge" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_line_badge', '📱 新着記事｜APPREX' ) ); ?>" placeholder="📱 新着記事｜APPREX">
					<p class="description"><?php esc_html_e( '記事公開時にLINEへ送るFlexバナー上部の小見出し（訴求コピー）。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'LINE配信バナー：ボタン文言', 'apprex' ); ?></th>
					<td><input type="text" name="apprex_line_cta" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_line_cta', '記事を読む ▶' ) ); ?>" placeholder="記事を読む ▶">
					<p class="description"><?php esc_html_e( 'タップで記事へ遷移するボタンのラベル。画像・カード全体もタップで記事に飛びます。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'LINE配信バナー：代替画像URL', 'apprex' ); ?></th>
					<td><input type="url" name="apprex_line_banner_fallback" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_line_banner_fallback', '' ) ); ?>" placeholder="https://example.com/line-banner.png">
					<p class="description"><?php esc_html_e( 'アイキャッチが無い記事に使うバナー画像（https のPNG/JPEG）。未設定なら画像なしのカードになります。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '通知先メール', 'apprex' ); ?></th>
					<td><input type="email" name="apprex_notify_email" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_notify_email', '' ) ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
					<p class="description"><?php esc_html_e( '未入力時はサイト管理者メールに送信します。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( '資料ダウンロード URL', 'apprex' ); ?></th>
					<td><input type="url" name="apprex_document_url" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_document_url', '' ) ); ?>" placeholder="https://example.com/apprex-document.pdf">
					<p class="description"><?php esc_html_e( '資料請求の自動返信メール・成功画面・ステップメールに記載されるダウンロードリンクです。', 'apprex' ); ?><br>
					<?php printf( esc_html__( '未入力の場合は、テーマ同梱の APPREX サービス資料を自動的に使用します（現在の既定：%s）。', 'apprex' ), '<code>/assets/docs/apprex-service-guide.html</code>' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'ミーティング予約URL（Google Meet）', 'apprex' ); ?></th>
					<td><input type="url" name="apprex_meeting_url" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_meeting_url', '' ) ); ?>" placeholder="https://calendar.app.google/xxxxxxxx">
					<p class="description"><?php esc_html_e( 'Googleカレンダーの予約ページ（appointment schedule）URL。設定すると、ミーティングページに「Google Meetで予約」ボタンを表示します。予約時にGoogle Meetの参加URL・招待・リマインダーが自動で発行されます。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'ステップメール（1年間）', 'apprex' ); ?></th>
					<td><label><input type="checkbox" name="apprex_drip_enabled" value="1" <?php checked( 1, (int) get_option( 'apprex_drip_enabled', 1 ) ); ?>> <?php esc_html_e( '有効にする（申込後、定期的にフォローメールを自動送信）', 'apprex' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'ミーティングのリマインダー', 'apprex' ); ?></th>
					<td><label><input type="checkbox" name="apprex_wp_meeting_reminders" value="1" <?php checked( 1, (int) get_option( 'apprex_wp_meeting_reminders', 0 ) ); ?>> <?php esc_html_e( 'WordPressからも送る', 'apprex' ); ?></label>
					<p class="description"><?php esc_html_e( '通常はOFF。Google Meet予約のリマインダー（前日・直前）はGoogleカレンダーが自動送信するため、重複を避けるためWordPressからは送りません。ONにすると前日・1時間前・翌日フォローをWordPressからも送信します。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'GAS Webhook URL', 'apprex' ); ?></th>
					<td><input type="url" name="apprex_gas_webhook_url" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_gas_webhook_url', '' ) ); ?>" placeholder="https://script.google.com/macros/s/XXXX/exec">
					<p class="description"><?php esc_html_e( 'お問い合わせ・発注の内容を送る GAS WebアプリのURL。GAS側で スプレッド→Asana→Slack に展開します。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'GAS 共有トークン', 'apprex' ); ?></th>
					<td><input type="text" name="apprex_gas_token" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_gas_token', '' ) ); ?>" autocomplete="off">
					<p class="description"><?php esc_html_e( 'なりすまし防止用の合言葉。GAS側の同じ値と照合します（任意の文字列）。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Slack Webhook URL（新着記事通知）', 'apprex' ); ?></th>
					<td><input type="url" name="apprex_slack_webhook" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_slack_webhook', '' ) ); ?>" placeholder="https://hooks.slack.com/services/XXX/YYY/ZZZ">
					<p class="description"><?php esc_html_e( 'Slack の Incoming Webhook URL。ブログ記事を公開すると、このチャンネルに新着記事を自動投稿します。', 'apprex' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Google Search Console 確認コード', 'apprex' ); ?></th>
					<td><input type="text" name="apprex_gsc_verify" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_gsc_verify', '' ) ); ?>" placeholder="例：abcd1234...（content= の値だけ）">
					<p class="description"><?php esc_html_e( 'Search Console の「HTMLタグ」確認で表示される content="..." の中の文字列だけを貼り付け。<head>に確認メタタグを自動出力します。', 'apprex' ); ?></p></td>
				</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'X（旧Twitter）ユーザー名', 'apprex' ); ?></th>
						<td><input type="text" name="apprex_twitter" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_twitter', '' ) ); ?>" placeholder="例：apprex（@は不要）">
						<p class="description"><?php esc_html_e( 'SNSシェア時のTwitterカードに表示するアカウント名（任意）。設定すると twitter:site メタタグを出力します。', 'apprex' ); ?></p></td>
					</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'プレビューアプリ（実機確認）', 'apprex' ); ?></th>
					<td>
						<input type="url" name="apprex_preview_app_ios" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_preview_app_ios', '' ) ); ?>" placeholder="<?php echo esc_attr( APPREX_PREVIEW_IOS ); ?>"><br>
						<input type="url" name="apprex_preview_app_android" class="regular-text" style="margin-top:6px" value="<?php echo esc_attr( get_option( 'apprex_preview_app_android', '' ) ); ?>" placeholder="<?php echo esc_attr( APPREX_PREVIEW_ANDROID ); ?>">
						<p class="description"><?php esc_html_e( 'App Store／Google Play のプレビューアプリのURL（上：iOS、下：Android）。デモアプリ・AIスタジオ・マニュアルで「本番の画面を実機で確認」として案内します。空欄なら管理画面に表示されている既定のURL、「-」と入力すると非表示にします。', 'apprex' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * Output the Google Search Console verification meta tag in <head>.
 *
 * Without this, the stored 確認コード is never rendered and verification fails.
 */
add_action( 'wp_head', function () {
	$token = (string) get_option( 'apprex_gsc_verify', '' );
	// Tolerate a full <meta> tag being pasted: keep only the content token.
	if ( $token && preg_match( '/content=["\']([^"\']+)["\']/i', $token, $m ) ) {
		$token = $m[1];
	}
	if ( '' !== $token ) {
		echo '<meta name="google-site-verification" content="' . esc_attr( $token ) . '">' . "\n";
	}
}, 1 );

/**
 * LINE URL accessor.
 *
 * @return string
 */
function apprex_line_url() {
	return (string) get_option( 'apprex_line_url', '' );
}

/**
 * Google Meet 予約ページ（Googleカレンダー appointment schedule）URL。
 *
 * @return string
 */
function apprex_meeting_url() {
	// サイトで予約を受け付けるときは、サイトの予約ページ（inc/meeting-booking.php）。
	return (string) apply_filters( 'apprex_meeting_url', (string) get_option( 'apprex_meeting_url', 'https://calendar.app.google/6xgkopT97tSwsHb76' ) );
}

/**
 * 資料ダウンロード URL。
 *
 * 管理画面（連携設定）で URL を設定すればそれを優先。未設定なら、テーマ同梱の
 * APPREX サービス資料（自己完結HTML）を既定値として返す。これにより資料請求の
 * 自動返信メール・成功画面・ステップメールのダウンロードリンクが常に有効になる。
 *
 * @return string
 */
function apprex_document_url() {
	$url = (string) get_option( 'apprex_document_url', '' );
	if ( $url ) {
		return $url;
	}
	return APPREX_URI . '/assets/docs/apprex-service-guide.html';
}

/**
 * 資料の共有用ショートURL（例：https://example.com/service-guide ）。
 * 共有・ボタン用のきれいでテーマ非依存のURL。
 *
 * @return string
 */
function apprex_document_view_url() {
	return home_url( '/service-guide' );
}

/**
 * /service-guide でサービス資料を表示するエンドポイント。
 * 管理画面で外部URLが設定されていればそこへリダイレクト、無ければ同梱資料を配信。
 */
add_action( 'init', function () {
	add_rewrite_rule( '^service-guide/?$', 'index.php?apprex_doc=1', 'top' );
	// 初回のみリライト規則を反映（再有効化不要で /service-guide が使えるように）。
	if ( '1' !== get_option( 'apprex_doc_rw' ) ) {
		flush_rewrite_rules( false );
		update_option( 'apprex_doc_rw', '1' );
	}
} );
add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'apprex_doc';
	return $vars;
} );
// /service-guide の末尾スラッシュ正規化リダイレクトを抑止（リダイレクトループ防止）。
add_filter( 'redirect_canonical', function ( $redirect ) {
	return get_query_var( 'apprex_doc' ) ? false : $redirect;
} );
add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'apprex_doc' ) ) {
		return;
	}
	$override = (string) get_option( 'apprex_document_url', '' );
	$self     = home_url( '/service-guide' );
	// 自己参照（無限ループ）防止：override が /service-guide 自身を指す場合は無視して同梱資料を表示。
	if ( $override
		&& false === strpos( $override, 'service-guide' )
		&& false === strpos( $override, 'apprex_doc' )
		&& untrailingslashit( $override ) !== untrailingslashit( $self ) ) {
		wp_redirect( $override ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}
	$file = APPREX_DIR . '/assets/docs/apprex-service-guide.html';
	if ( is_readable( $file ) ) {
		header( 'Content-Type: text/html; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );
		readfile( $file ); // phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData
		exit;
	}
	wp_safe_redirect( home_url( '/' ) );
	exit;
} );

/**
 * Resolve the notification recipient.
 *
 * @return string
 */
function apprex_notify_to() {
	$opt = get_option( 'apprex_notify_email', '' );
	if ( $opt ) {
		return $opt;
	}
	return function_exists( 'apprex_contact_email' ) ? apprex_contact_email() : get_option( 'admin_email' );
}

/* -------------------------------------------------------------------------
 * Inquiry CPT
 * ---------------------------------------------------------------------- */
add_action( 'init', function () {
	register_post_type(
		'apprex_inquiry',
		array(
			'labels'        => array(
				'name'          => __( 'お問い合わせ', 'apprex' ),
				'singular_name' => __( 'お問い合わせ', 'apprex' ),
				'menu_name'     => __( 'お問い合わせ', 'apprex' ),
				'all_items'     => __( 'お問い合わせ一覧', 'apprex' ),
			),
			'public'        => false,
			'show_ui'       => true,
			'menu_icon'     => 'dashicons-email-alt',
			'menu_position' => 7,
			'supports'      => array( 'title' ),
		)
	);
} );

/* -------------------------------------------------------------------------
 * Form rendering helper
 * ---------------------------------------------------------------------- */

/**
 * Labels per form type.
 *
 * @param string $type contact|document|trial|meeting.
 * @return array
 */
function apprex_form_meta( $type ) {
	$map = array(
		'contact'  => array( 'submit' => 'この内容で送信する', 'msg_label' => 'お問い合わせ内容', 'msg_required' => true, 'datetime' => false ),
		'document' => array( 'submit' => '資料をダウンロードする', 'msg_label' => 'ご質問・ご要望（任意）', 'msg_required' => false, 'datetime' => false ),
		'trial'    => array( 'submit' => '30日間 無料体験を申し込む', 'msg_label' => 'ご要望（任意）', 'msg_required' => false, 'datetime' => false ),
		'meeting'  => array( 'submit' => 'この日時で予約する', 'msg_label' => '相談したい内容（任意）', 'msg_required' => false, 'datetime' => true ),
		'partner'  => array( 'submit' => '代理店に申し込む', 'msg_label' => '事業内容・お客様層・ご質問（任意）', 'msg_required' => false, 'datetime' => false ),
		'hp'       => array( 'submit' => '無料でヒアリングを申し込む', 'msg_label' => 'そのほかのご要望・気になること（任意）', 'msg_required' => false, 'datetime' => false ),
	);
	return isset( $map[ $type ] ) ? $map[ $type ] : $map['contact'];
}

/**
 * Allowed inquiry types.
 *
 * @return string[]
 */
function apprex_inquiry_types() {
	return array( 'contact', 'document', 'trial', 'meeting', 'partner', 'signup', 'studio', 'hp' );
}

/**
 * Type → Japanese label.
 *
 * @param string $type Type.
 * @return string
 */
function apprex_type_label( $type ) {
	$labels = array(
		'contact'  => 'お問い合わせ',
		'document' => '資料請求',
		'trial'    => '無料体験申込',
		'meeting'  => 'ミーティング予約',
		'partner'  => '代理店の申し込み',
		'estimate' => '見積もり・発注',
		'signup'   => 'AIスタジオ会員登録',
		'studio'   => 'AIスタジオから開発相談',
		'seminar'  => '説明会の予約',
		'hp'       => 'ホームページのヒアリング',
	);
	return isset( $labels[ $type ] ) ? $labels[ $type ] : 'お問い合わせ';
}

/**
 * Render a native form. Echoes markup; submitted via REST (apprex-forms.js).
 *
 * @param string $type contact|document|trial.
 */
function apprex_render_form( $type = 'contact' ) {
	$meta = apprex_form_meta( $type );
	$line = apprex_line_url();
	?>
	<form class="apprex-form" data-apprex-form data-type="<?php echo esc_attr( $type ); ?>">
		<div class="apprex-form__row">
			<label>
				<span class="apprex-form__lbl"><?php esc_html_e( 'お名前', 'apprex' ); ?> <span class="req">*</span></span>
				<input type="text" name="name" autocomplete="name" required>
			</label>
			<label>
				<span class="apprex-form__lbl"><?php esc_html_e( '会社名（任意）', 'apprex' ); ?></span>
				<input type="text" name="company" autocomplete="organization">
			</label>
		</div>
		<label>
			<span class="apprex-form__lbl"><?php esc_html_e( 'メールアドレス', 'apprex' ); ?> <span class="req">*</span></span>
			<input type="email" name="email" autocomplete="email" inputmode="email" required>
		</label>
		<label>
			<span class="apprex-form__lbl"><?php esc_html_e( '電話番号（任意）', 'apprex' ); ?></span>
			<input type="tel" name="phone" autocomplete="tel" inputmode="tel">
		</label>
		<?php if ( 'partner' === $type ) : ?>
			<label>
				<span class="apprex-form__lbl"><?php esc_html_e( '希望する代理店の種類', 'apprex' ); ?> <span class="req">*</span></span>
				<select name="agency_type" required>
					<option value=""><?php esc_html_e( '選んでください', 'apprex' ); ?></option>
					<?php foreach ( array( '紹介代理店', '販売代理店', 'OEM代理店', '面談で相談して決めたい' ) as $apprex_at ) : ?>
						<option><?php echo esc_html( $apprex_at ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
		<?php endif; ?>
		<?php if ( 'hp' === $type && function_exists( 'apprex_hp_hearing_fields' ) ) : ?>
			<?php apprex_hp_hearing_fields(); ?>
		<?php endif; ?>
		<?php if ( ! empty( $meta['datetime'] ) ) : ?>
			<label>
				<span class="apprex-form__lbl"><?php esc_html_e( 'ご希望日時', 'apprex' ); ?> <span class="req">*</span></span>
				<input type="datetime-local" name="meeting_at" required>
			</label>
		<?php endif; ?>
		<label>
			<span class="apprex-form__lbl"><?php echo esc_html( $meta['msg_label'] ); ?> <?php echo $meta['msg_required'] ? '<span class="req">*</span>' : ''; ?></span>
			<textarea name="message" rows="5" <?php echo $meta['msg_required'] ? 'required' : ''; ?>></textarea>
		</label>
		<label class="apprex-form__consent">
			<input type="checkbox" name="consent" value="1" required>
			<?php $apprex_pp_url = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : ''; ?>
			<span><?php if ( $apprex_pp_url ) : ?><a href="<?php echo esc_url( $apprex_pp_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'プライバシーポリシー', 'apprex' ); ?></a><?php esc_html_e( 'に同意します', 'apprex' ); ?><?php else : ?><?php esc_html_e( 'プライバシーポリシーに同意します', 'apprex' ); ?><?php endif; ?></span>
		</label>
		<button type="submit" class="btn btn--primary btn--block"><?php echo esc_html( $meta['submit'] ); ?></button>
		<div class="apprex-form__result" hidden></div>
	</form>

	<?php if ( $line ) : ?>
		<div class="apprex-form__line">
			<p><?php esc_html_e( 'LINEでのご相談も歓迎です。', 'apprex' ); ?></p>
			<a class="line-cta" href="<?php echo esc_url( $line ); ?>" target="_blank" rel="noopener">
				<?php esc_html_e( 'LINEで相談する', 'apprex' ); ?>
			</a>
		</div>
	<?php endif; ?>
	<?php
}

/**
 * フォーム埋め込み用ショートコード。
 * 例：[apprex_form type="contact"] / [apprex_form type="estimate"]
 * LP（LPtools等）の本文に貼ると、計測（Lead）・自動返信・CRM連携付きフォームを表示。
 *
 * @param array $atts 属性（type）。
 * @return string
 */
add_shortcode( 'apprex_form', function ( $atts ) {
	$atts = shortcode_atts( array( 'type' => 'contact' ), $atts, 'apprex_form' );
	$type = in_array( $atts['type'], apprex_inquiry_types(), true ) ? $atts['type'] : 'contact';
	ob_start();
	echo '<div class="apprex-form-embed">';
	apprex_render_form( $type );
	echo '</div>';
	return ob_get_clean();
} );

/* -------------------------------------------------------------------------
 * REST submit
 * ---------------------------------------------------------------------- */
add_action( 'rest_api_init', function () {
	register_rest_route(
		'apprex/v1',
		'/inquiry',
		array(
			'methods'             => 'POST',
			'callback'            => 'apprex_rest_inquiry',
			'permission_callback' => '__return_true',
		)
	);
} );

/**
 * Handle a form submission.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function apprex_rest_inquiry( WP_REST_Request $request ) {
	$nonce = $request->get_header( 'x_wp_nonce' );
	if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
		return new WP_Error( 'forbidden', '不正なリクエストです。ページを再読み込みしてください。', array( 'status' => 403 ) );
	}

	$type    = sanitize_key( $request->get_param( 'type' ) );
	$type    = in_array( $type, apprex_inquiry_types(), true ) ? $type : 'contact';
	$name    = sanitize_text_field( (string) $request->get_param( 'name' ) );
	$company = sanitize_text_field( (string) $request->get_param( 'company' ) );
	$email   = sanitize_email( (string) $request->get_param( 'email' ) );
	$phone   = sanitize_text_field( (string) $request->get_param( 'phone' ) );
	$message = sanitize_textarea_field( (string) $request->get_param( 'message' ) );

	// 代理店の申し込み：希望する種類を本文の先頭に。
	$agency_type = sanitize_text_field( (string) $request->get_param( 'agency_type' ) );
	if ( 'partner' === $type && '' !== $agency_type ) {
		$message = '【希望する代理店】' . mb_substr( $agency_type, 0, 40 ) . ( '' !== $message ? "\n" . $message : '' );
	}
	// 代理店の紹介URL（?ref=）から来た場合は、紹介元を本文の最後に記録。
	$ref = function_exists( 'apprex_agency_ref' ) ? apprex_agency_ref() : '';
	if ( '' !== $ref ) {
		$message .= ( '' !== $message ? "\n\n" : '' ) . '【紹介元の代理店コード】' . $ref;
	}

	// Meeting preferred datetime (meeting type only).
	// datetime-local の値はサイトのタイムゾーンで解釈する（UTC解釈による時刻ズレ防止）。
	$meeting_raw = sanitize_text_field( (string) $request->get_param( 'meeting_at' ) );
	$meeting_at  = 0;
	if ( 'meeting' === $type && $meeting_raw ) {
		$dt         = date_create( $meeting_raw, wp_timezone() );
		$meeting_at = $dt ? $dt->getTimestamp() : 0;
	}
	if ( 'meeting' === $type && ! $meeting_at ) {
		return new WP_Error( 'bad_request', 'ご希望日時をご指定ください。', array( 'status' => 400 ) );
	}

	// ホームページのヒアリング：答えを本文の先頭にまとめて、別にも保存する。
	$hp_answers = array();
	if ( 'hp' === $type && function_exists( 'apprex_hp_hearing_collect' ) ) {
		$hp_answers = apprex_hp_hearing_collect( (array) $request->get_param( 'hp' ) );
		$lines      = array();
		foreach ( $hp_answers as $k => $v ) {
			$lines[] = '【' . $k . '】' . $v;
		}
		$message = implode( "\n", $lines ) . ( '' !== $message ? "\n\n【そのほかのご要望】\n" . $message : '' );
	}

	if ( '' === $name || ! is_email( $email ) ) {
		return new WP_Error( 'bad_request', 'お名前と有効なメールアドレスをご入力ください。', array( 'status' => 400 ) );
	}

	$type_label = apprex_type_label( $type );
	$post_id    = wp_insert_post(
		array(
			'post_type'   => 'apprex_inquiry',
			'post_status' => 'publish',
			'post_title'  => sprintf( '[%s] %s', $type_label, $name ),
		),
		true
	);
	if ( is_wp_error( $post_id ) ) {
		return new WP_Error( 'save_failed', '送信に失敗しました。時間をおいて再度お試しください。', array( 'status' => 500 ) );
	}

	$fields = compact( 'type', 'name', 'company', 'email', 'phone', 'message' );
	foreach ( $fields as $k => $v ) {
		update_post_meta( $post_id, 'apprex_' . $k, $v );
	}
	update_post_meta( $post_id, 'apprex_submitted_at', current_time( 'mysql' ) );
	if ( ! empty( $hp_answers ) ) {
		update_post_meta( $post_id, 'apprex_hp_hearing', $hp_answers );
	}
	if ( '' !== $ref ) {
		update_post_meta( $post_id, 'apprex_ref', $ref );
	}
	if ( $meeting_at ) {
		update_post_meta( $post_id, 'apprex_meeting_at', $meeting_at );
		$fields['meeting_at'] = $meeting_at;
	}

	// Type-specific auto-reply + step / reminder sequence.
	apprex_enroll_drip( $post_id, $type, $email, $name, $meeting_at );
	$GLOBALS['apprex_last_inquiry_id'] = $post_id; // 自動返信に、予約ごとの参加ボタンを入れるため。
	apprex_send_autoreply( $type, $fields );
	apprex_notify_inquiry( $post_id, $type_label, $fields );

	// GAS連携（スプレッド→Asana→Slack）。
	if ( function_exists( 'apprex_dispatch_event' ) ) {
		apprex_dispatch_event(
			'inquiry',
			array(
				'id'         => $post_id,
				'type'       => $type,
				'type_label' => $type_label,
				'name'       => $name,
				'company'    => $company,
				'email'      => $email,
				'phone'      => $phone,
				'message'    => $message,
				'meeting_at' => $meeting_at ? wp_date( 'Y-m-d H:i', $meeting_at ) : '',
				'admin_url'  => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
			)
		);
	}

	/**
	 * フォーム送信完了フック（SNS広告のコンバージョンAPI等で利用）。
	 *
	 * @param int    $post_id 受付ID。
	 * @param string $type    フォーム種別。
	 * @param array  $fields  送信内容（name/company/email/phone/message/meeting_at）。
	 */
	do_action( 'apprex_inquiry_submitted', $post_id, $type, $fields );

	$result = array(
		'ok'      => true,
		'message' => apprex_autoreply_onscreen( $type ),
		'lead'    => array(
			'type'     => $type,
			'event_id' => 'lead_' . $post_id,
		),
	);
	if ( 'document' === $type ) {
		$doc = apprex_document_url();
		if ( $doc ) {
			$result['download'] = esc_url_raw( $doc );
		}
	}
	// 代理店の申し込みは、説明会（LINEで予約）へ誘導。
	if ( 'partner' === $type && function_exists( 'apprex_seminar_url' ) ) {
		$result['seminar'] = esc_url_raw( apprex_seminar_url() );
	}
	// お問い合わせ・パートナーはミーティング（Web面談）予約へ誘導。
	if ( in_array( $type, array( 'contact', 'partner' ), true ) ) {
		$meet = apprex_meeting_url();
		if ( $meet ) {
			$result['meeting'] = esc_url_raw( $meet );
		}
	}
	$line = apprex_line_url();
	if ( $line ) {
		$result['line'] = esc_url_raw( $line );
	}
	return rest_ensure_response( $result );
}

/**
 * On-screen confirmation per type.
 *
 * @param string $type Type.
 * @return string
 */
function apprex_autoreply_onscreen( $type ) {
	switch ( $type ) {
		case 'document':
			return '資料請求ありがとうございます。ダウンロードリンクをメールでもお送りしました。';
		case 'trial':
			return '無料体験のお申し込みを受け付けました。担当者より2営業日以内にご案内します。';
		case 'meeting':
			return ( function_exists( 'apprex_mb_enabled' ) && apprex_mb_enabled() ) ? 'ミーティングのご予約が確定しました。確認のメールをお送りしました。前日と1時間前にもお知らせします。' : 'ミーティングのご予約を受け付けました。確認のうえ、確定のご連絡を差し上げます。リマインダーもお送りします。';
		case 'hp':
			return 'ヒアリングのお申し込みを受け付けました。担当者が内容を確認し、2営業日以内にご連絡します。続けてオンラインでのヒアリング日時をご予約いただくと、よりスムーズです。';
		case 'partner':
			return '代理店のお申し込みを受け付けました。担当者よりご連絡します。報酬・加盟金は説明会でご説明しますので、まだの方はLINEから説明会をご予約ください。';
		case 'signup':
			return 'AIスタジオへの登録が完了しました。さっそくアプリのデザインを作ってみましょう。';
		case 'studio':
			return '開発のご相談を受け付けました。続けてオンラインミーティングの日時をお選びください。';
		default:
			return 'お問い合わせありがとうございます。担当者より2営業日以内にご連絡いたします。お急ぎの方は、下のボタンからミーティング（Web面談）をご予約ください。';
	}
}

/**
 * Enroll a submission (inquiry or order) into the type-specific drip sequence.
 *
 * @param int    $post_id    Post ID (apprex_inquiry or apprex_order).
 * @param string $type       Sequence type.
 * @param string $email      Recipient.
 * @param string $name       Name.
 * @param int    $meeting_at Meeting timestamp (meeting type only).
 */
function apprex_enroll_drip( $post_id, $type, $email, $name, $meeting_at = 0 ) {
	if ( ! get_option( 'apprex_drip_enabled', 1 ) ) {
		return;
	}
	if ( $meeting_at ) {
		update_post_meta( $post_id, 'apprex_meeting_at', $meeting_at );
	}
	update_post_meta( $post_id, 'apprex_email', $email );
	update_post_meta( $post_id, 'apprex_name', $name );

	// 1人1本：同じメールアドレスで進行中のシリーズと比べ、先に進んだ段階を優先する。
	$track = apprex_drip_track( $type );
	$rank  = apprex_drip_rank( $type );
	foreach ( apprex_drip_active_for( $email, $post_id ) as $other ) {
		$otype = get_post_meta( $other, 'apprex_drip_type', true );
		if ( apprex_drip_track( $otype ) !== $track ) {
			continue;
		}
		if ( apprex_drip_rank( $otype ) > $rank ) {
			// もっと先に進んだシリーズが動いているので、今回は始めない。
			update_post_meta( $post_id, 'apprex_drip_stopped', 'later:' . $otype );
			return;
		}
		update_post_meta( $other, 'apprex_drip_active', 0 );
		update_post_meta( $other, 'apprex_drip_stopped', 'next:' . $type );
	}

	// ミーティングは原則 Google カレンダーがリマインダーを送るため、WordPress 側は既定で送らない。
	if ( 'meeting' === $type && ! get_option( 'apprex_wp_meeting_reminders', 0 ) && ! ( function_exists( 'apprex_mb_enabled' ) && apprex_mb_enabled() ) ) {
		return;
	}
	// 配信停止した人には、案内のシリーズを送らない（ミーティングのリマインダーは除く）。
	if ( 'meeting' !== $type && apprex_drip_unsubscribed( $email ) ) {
		update_post_meta( $post_id, 'apprex_drip_stopped', 'unsubscribed' );
		return;
	}
	update_post_meta( $post_id, 'apprex_drip_active', 1 );
	update_post_meta( $post_id, 'apprex_drip_type', $type );
	update_post_meta( $post_id, 'apprex_drip_start', time() );
	update_post_meta( $post_id, 'apprex_drip_sent', array() );
}

/**
 * ステップメールの系統。お客様向け（customer）と代理店向け（agency）は別々に数える。
 *
 * @param string $type 種類。
 * @return string
 */
function apprex_drip_track( $type ) {
	return 'partner' === $type ? 'agency' : 'customer';
}

/**
 * 段階の順番（大きいほど先に進んでいる）。
 * お問い合わせ < 資料請求 < AIスタジオ登録 < 無料体験 < AIスタジオから相談 < 見積り・発注 < ミーティング予約。
 *
 * @param string $type 種類。
 * @return int
 */
function apprex_drip_rank( $type ) {
	$r = array( 'contact' => 1, 'document' => 2, 'signup' => 3, 'trial' => 4, 'studio' => 5, 'estimate' => 6, 'meeting' => 7, 'partner' => 1, 'hp' => 6 );
	return isset( $r[ $type ] ) ? $r[ $type ] : 1;
}

/**
 * 同じメールアドレスで、ステップメールが進行中の受付ID。
 *
 * @param string $email   メールアドレス。
 * @param int    $exclude 除くID。
 * @return int[]
 */
function apprex_drip_active_for( $email, $exclude = 0 ) {
	if ( ! is_email( $email ) ) {
		return array();
	}
	return get_posts(
		array(
			'post_type'      => array( 'apprex_inquiry', 'apprex_order' ),
			'post_status'    => array( 'publish', 'apprex_new' ),
			'posts_per_page' => 20,
			'fields'         => 'ids',
			'post__not_in'   => $exclude ? array( (int) $exclude ) : array(),
			'meta_query'     => array(
				array( 'key' => 'apprex_drip_active', 'value' => '1' ),
				array( 'key' => 'apprex_email', 'value' => $email ),
			),
		)
	);
}

/** 配信停止したメールアドレスか。 */
function apprex_drip_unsubscribed( $email ) {
	$list = (array) get_option( 'apprex_drip_unsub_list', array() );
	return in_array( wp_hash( strtolower( (string) $email ) ), $list, true );
}

/**
 * もう契約・入金に進んだお客様か（案内のステップメールを止める）。
 * 契約がある、または AIスタジオでお見積りを送った（段階3以上）会員。
 *
 * @param string $email メールアドレス。
 * @return bool
 */
function apprex_drip_is_client( $email ) {
	if ( post_type_exists( 'apprex_contract' ) ) {
		$c = get_posts( array( 'post_type' => 'apprex_contract', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => 'apprex_c_email', 'meta_value' => $email ) );
		if ( $c ) {
			return true;
		}
	}
	$u = get_user_by( 'email', $email );
	return $u && (int) get_user_meta( $u->ID, 'apprex_studio_stage', true ) >= 3;
}

/* -------------------------------------------------------------------------
 * Emails: auto-reply + admin notify
 * ---------------------------------------------------------------------- */

/**
 * Send the immediate auto-reply to the customer.
 *
 * @param string $type   Form type.
 * @param array  $fields Submitted fields.
 */
function apprex_autoreply_message( $type, $fields ) {
	$name = isset( $fields['name'] ) ? $fields['name'] : '';
	$doc  = apprex_document_url();

	switch ( $type ) {
		case 'document':
			$subject = '【APPREX】資料請求ありがとうございます';
			$body    = "{$name} 様\n\nこの度はAPPREXの資料をご請求いただきありがとうございます。\n";
			$body   .= $doc ? "下記より資料をダウンロードいただけます。\n{$doc}\n" : "担当者より資料をお送りいたします。\n";
			break;
		case 'trial':
			$subject = '【APPREX】無料体験のお申し込みありがとうございます';
			$body    = "{$name} 様\n\n30日間無料体験のお申し込みを受け付けました。\n担当者より2営業日以内に開始方法をご案内いたします。\n";
			break;
		case 'meeting':
			$when    = ! empty( $fields['meeting_at'] ) ? wp_date( 'Y年n月j日(D) H:i', (int) $fields['meeting_at'] ) : '';
			$subject = '【APPREX】ミーティングのご予約を受け付けました';
			$body    = "{$name} 様\n\nオンラインミーティング（Google Meet）のご予約ありがとうございます。\n";
			if ( function_exists( 'apprex_mb_enabled' ) && apprex_mb_enabled() ) {
				// サイトで受け付けた予約は、この時点で確定。
				$murl  = (string) apprex_mb_settings()['url'];
				$pid   = (int) ( $GLOBALS['apprex_last_inquiry_id'] ?? 0 );
				$join  = $pid && function_exists( 'apprex_mj_link' ) ? apprex_mj_link( $pid ) : $murl;
				$body .= $when ? "ご予約日時：{$when}（" . (int) apprex_mb_settings()['min'] . "分）\n" : '';
				$body .= $join ? "\nお時間になりましたら、下のボタンからご参加ください（Google Meet）。\n{$join}\n" : "\n参加URLは、担当者からあらためてお送りします。\n";
				$body .= "\n前日と1時間前に、このメールアドレスにお知らせをお送りします。日時の変更は、このメールにご返信ください。\n";
			} else {
				$body .= $when ? "ご希望日時：{$when}\n" : '';
				$body .= "内容を確認のうえ、Google MeetのURLを含む確定のご連絡を差し上げます。\n確定後は、Googleカレンダーより開催前のリマインダーが自動で届きます。\n";
				$meet  = apprex_meeting_url();
				if ( $meet ) {
					$body .= "\n▼ ご自身で今すぐ日時を確定したい方はこちら（Google Meet・URL自動発行）\n{$meet}\n";
				}
			}
			break;
		case 'hp':
			$subject = '【APPREX】ホームページのヒアリングのお申し込みありがとうございます';
			$body    = "{$name} 様\n\nAPPREXのホームページ制作にお申し込みいただき、ありがとうございます。\n\nこれからの流れ\n1. 担当者がご要望を確認し、2営業日以内にご連絡します（必要に応じてオンラインで詳しくお伺いします）\n2. ご要望をもとに、提案書（企画・ページ構成・デザイン案）をお作りします（無料）\n3. 内容にご納得いただけたら、月額のお見積りをお出しします\n4. ご契約後に制作・公開し、公開後の更新・運用もお任せください\n\n制作費は0円、月額9,800円〜（ご契約期間は3年）です。提案書までは費用はかかりません。\n\n▼ オンラインでのヒアリング日時のご予約はこちら\n{meeting_url}\n";
			break;
		case 'partner':
			$subject = '【APPREX】代理店のお申し込みありがとうございます';
			$sem     = function_exists( 'apprex_seminar_url' ) ? apprex_seminar_url() : home_url( '/partner/' );
			$body    = "{$name} 様\n\nこの度はAPPREXの代理店にお申し込みいただきありがとうございます。\n担当者より、代理店の種類と進め方についてご連絡いたします。\n\n報酬のしくみ・加盟金は、無料のオンライン説明会でご説明しています。まだの方は、LINEから日程をお選びください。\n{$sem}\n";
			break;
		case 'signup':
			$studio  = function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : home_url( '/studio/' );
			$subject = '【APPREX】AIスタジオへのご登録ありがとうございます';
			$body    = "{$name} 様\n\nAPPREXのAIスタジオに無料会員登録いただき、ありがとうございます。\n\nAIスタジオでは、次のことが無料でできます。\n・業種と店名を入れるだけで、アプリの画面デザインを5画面作成\n・言葉で頼むだけでデザインを修正\n・機能を選ぶと、企画書・仕様書・画面構成図と概算費用を自動作成\n・作った内容のまま開発を相談し、オンラインミーティングを予約\n\n▼ AIスタジオはこちら（ログインしてご利用ください）\n{$studio}\n\nAPPREXの基盤で作れる範囲（ノーコード）なら、初期費用は150,000円です（基盤のカスタマイズは別途お見積もり、フルスクラッチは要相談）。仕様書ができたら、ホームページやオプションもあわせてご提案します。\n";
			break;
		case 'studio':
			$studio  = function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : home_url( '/studio/' );
			$subject = '【APPREX】開発のご相談を受け付けました';
			$body    = "{$name} 様\n\nAIスタジオから開発のご相談をいただき、ありがとうございます。\nお送りいただいたデザインと仕様書を担当者が確認し、オンラインミーティングでお見積りまでご案内します。\n\nミーティングの日時がまだの方は、AIスタジオからお選びください。\n{$studio}\n";
			break;
		default:
			$subject = '【APPREX】お問い合わせありがとうございます';
			$body    = "{$name} 様\n\nお問い合わせいただきありがとうございます。\n内容を確認のうえ、担当者より2営業日以内にご連絡いたします。\n";
	}

	// お問い合わせ・パートナーは Web ミーティング予約へ誘導（URL行はボタン化される）。
	if ( in_array( $type, array( 'contact', 'partner' ), true ) ) {
		$meet = apprex_meeting_url();
		if ( $meet ) {
			$body .= "\nお急ぎの方・先に相談したい方は、無料のWebミーティングをご予約ください。\n{$meet}\n";
		}
	}

	$ov = function_exists( 'apprex_mail_override' ) ? apprex_mail_override( 'autoreply.' . $type ) : null;
	if ( $ov ) {
		if ( ! empty( $ov['subject'] ) ) {
			$subject = $ov['subject'];
		}
		if ( ! empty( $ov['body'] ) ) {
			$body = $ov['body'];
		}
	}
	$when    = ! empty( $fields['meeting_at'] ) ? wp_date( 'Y年n月j日(D) H:i', (int) $fields['meeting_at'] ) : '';
	$body    = strtr( $body, array( '{name}' => $name, '{download_url}' => $doc, '{meeting_at}' => $when ) );
	$subject = strtr( $subject, array( '{name}' => $name ) );

	$body = apply_filters( 'apprex_autoreply_body', $body, $type, $fields );
	return array( $subject, $body );
}

/**
 * Send the immediate auto-reply (HTML) to the customer.
 *
 * @param string $type   Form type.
 * @param array  $fields Submitted fields.
 */
function apprex_send_autoreply( $type, $fields ) {
	list( $subject, $body ) = apprex_autoreply_message( $type, $fields );
	$html = apprex_render_email(
		$subject,
		$body,
		array( 'heading' => apprex_email_heading_from_subject( $subject ) )
	);
	wp_mail( $fields['email'], $subject, $html, apprex_mail_headers() );
}

/**
 * Notify the admin of a new submission.
 *
 * @param int    $post_id    Inquiry ID.
 * @param string $type_label Label.
 * @param array  $fields     Fields.
 */
function apprex_notify_inquiry( $post_id, $type_label, $fields ) {
	$subject = sprintf( '[APPREX] %s #%d — %s', $type_label, $post_id, $fields['name'] );
	$content = apprex_admin_notify_html( $type_label, $fields, $post_id );
	$html    = apprex_email_wrap( $subject, $content, array( 'heading' => '新しい' . $type_label . 'が届きました' ) );
	wp_mail( apprex_notify_to(), $subject, $html, apprex_mail_headers() );
}

/**
 * Default mail headers.
 *
 * @return array
 */
function apprex_mail_headers() {
	$from = apprex_notify_to();
	return array(
		'Content-Type: text/html; charset=UTF-8',
		'From: APPREX <' . $from . '>',
	);
}

/* -------------------------------------------------------------------------
 * Step mail (drip) — up to 1 year
 * ---------------------------------------------------------------------- */

/**
 * Type-specific step sequences. Offset in MINUTES => {subject, body}.
 * 1日=1440 / 3日=4320 / 7日=10080 / 14日=20160 / 30日=43200 など。
 * {name} is replaced at send time. Editable via the apprex_step_mails filter.
 *
 * @param string $type document|trial|estimate|contact.
 * @return array<int,array{subject:string,body:string}>
 */
function apprex_step_mails( $type = 'contact' ) {
	$ft    = home_url( '/free-trial/' );
	$est   = home_url( '/estimate/' );
	$cases = home_url( '/cases/' );
	$hp    = home_url( '/hp-creation/' );
	$home  = home_url( '/' );
	$meet  = function_exists( 'apprex_meeting_url' ) && apprex_meeting_url() ? apprex_meeting_url() : home_url( '/meeting/' );
	$sem   = function_exists( 'apprex_seminar_url' ) ? apprex_seminar_url() : home_url( '/partner/' );
	// AIスタジオを訪問者に公開しているときだけ、AIスタジオへ案内する（公開前は無料体験へ）。
	$pub    = function_exists( 'apprex_rn_public' ) && apprex_rn_public();
	$studio = function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : $home;
	$try    = $pub
		? "AIスタジオ（無料）なら、業種と店名を入れるだけで、あなたのお店のアプリの画面と仕様書がその場でできあがります。\n{$studio}\n"
		: "30日間の無料体験で、実際の管理画面を触っていただけます（クレジットカード登録不要）。\n{$ft}\n";

	// 文面は PASONA の法則（問題→共感→解決→限定→行動）で構成。
	$sequences = array(
		// 資料請求後：資料活用 → 事例 → 料金 → 体験 → 相談.
		'document' => array(
			1440  => array( 'subject' => '【APPREX】その資料、“積ん読”になっていませんか？', 'body' => "{name} 様\n\n先日は資料をご請求いただき、ありがとうございました。\n\n資料請求された方の多くが「あとでじっくり読もう」と思ったまま、気づけば1週間…というのがよくあるパターンです。お忙しい毎日では当然のことだと思います。\n\nAPPREXの良さは、“読む”より“見る”と早く伝わります。\n{$try}\n気になる点が1つでもあれば、このメールにそのままご返信ください。担当が分かりやすくお答えします。\n" ),
			4320  => array( 'subject' => '【APPREX】「自社でも本当にできる？」を消す9つの実例', 'body' => "{name} 様\n\n「ノーコードと言っても、結局むずかしいのでは？」——資料を見て、そう感じた方もいらっしゃるかもしれません。\n\nそのお気持ち、よく分かります。だからこそ、実際に“自社で運用している”企業の事例をまとめました。不動産・士業・教育・店舗・コミュニティまで、9業種の生きた使い方が見られます。\n\nきっと、貴社に近いケースが見つかるはずです。\n{$cases}\n" ),
			10080 => array( 'subject' => '【APPREX】アプリ開発に数百万円は、もう過去の話です', 'body' => "{name} 様\n\nアプリ開発と聞くと「300万円〜」「数ヶ月待ち」——そんなイメージが、導入をためらわせる最大の壁でした。\n\nAPPREXは、その常識を覆します。デザインと仕様書はAIスタジオで無料、ノーコードなら初期費用15万円＋月額19,800円〜。従来の開発コストの“約1/10”で、しかも公開後の運用まで含まれています。\n\n「自社の場合はいくら？」は、1分で分かります。下のページで条件を選ぶだけです。\n{$est}\n\n画面を見ながら担当者と相談したい方は、無料のオンライン相談（60分）もご利用ください。\n{$meet}\n" ),
			20160 => array( 'subject' => '【APPREX】30日間、まるごと無料で“自分の手”で', 'body' => "{name} 様\n\nここまで資料・事例・料金をご覧いただきました。最後に残るのは、たった1つ——「実際の使い心地」です。\n\n百の説明より、一度の操作。APPREXは30日間、すべての機能を無料でお試しいただけます。クレジットカード登録も不要です。\n\nまずは触れてみて、「これなら自社でできる」を体感してください。\n{$ft}\n" ),
			43200 => array( 'subject' => '【APPREX】最後に、あなたの“あと一歩”を後押しさせてください', 'body' => "{name} 様\n\n資料請求から1ヶ月。ご検討の状況はいかがでしょうか。\n\n「やりたい気持ちはあるけれど、何から始めれば…」という段階でしたら、それを整理するお手伝いをさせてください。チャット・LINE・オンライン相談（無料）のどれでも構いません。このメールへのご返信でも結構です。\n{$meet}\n" ),
		),
		// 30日お試し：開始 → 使い方 → 公開 → 事例 → 終了前リマインド → 継続.
		'trial'    => array(
			1440  => array( 'subject' => '【APPREX】無料体験スタート！最初の5分でやること', 'body' => "{name} 様\n\n無料体験のお申し込み、ありがとうございます。ここから30日間、すべての機能をお使いいただけます。\n\n最初の一歩はとてもシンプルです。用意されたテンプレートを1つ選び、文字と画像を差し替えるだけ。たった5分で「アプリらしい画面」が立ち上がります。\n\n「いきなり完璧」を目指す必要はありません。まずは触って、動かす楽しさを味わってください。詰まったら、このメールにご返信を。すぐにお助けします。\n" ),
			4320  => array( 'subject' => '【APPREX】使うほど効く“3つの武器”の設定法', 'body' => "{name} 様\n\n体験は進んでいますか？ APPREXには集客と再来店を生む機能が揃っていますが、まず押さえたいのは3つです。\n\n「プッシュ通知」でお客様のスマホに直接お知らせ。「会員機能」でリピーターを見える化。「クーポン・スタンプカード」でもう一度の来店を後押し。——どれも数クリックで設定できます。\n\n使いこなすほど、アプリは“24時間働く営業マン”になります。設定でお困りなら、お気軽にご返信ください。\n" ),
			10080 => array( 'subject' => '【APPREX】「いつ公開できる？」最短2週間のリアル', 'body' => "{name} 様\n\n体験を続ける中で、「これ、本当に公開できるんだ」と感じていただけていたら嬉しいです。\n\n公開までの流れはシンプルです。①画面を整える ②App Store / Google Play へ申請 ③審査通過で公開。APPREXなら、最短2週間でこのゴールに到達できます。\n\n申請まわりの不安は、私たちがサポートします。「公開したい」と思ったタイミングで、いつでもご相談ください。\n" ),
			20160 => array( 'subject' => '【APPREX】体験を“成果”に変えた人たちの共通点', 'body' => "{name} 様\n\n無料体験から本番運用へ。実際に成果を出した企業には、ある共通点があります。それは「完璧を待たず、まず公開した」こと。\n\n公開後に改善していけるのが、アプリの強みです。会員200%増、再来店率アップ——そんな実例をまとめました。\n{$cases}\n" ),
			36000 => array( 'subject' => '【APPREX】無料体験はあと少し。作った内容はそのまま本番へ', 'body' => "{name} 様\n\n無料体験の期間終了が近づいてきました。ここまで触っていただき、ありがとうございます。\n\nもし「続けたい」と感じていただけたなら、体験で作った内容は、そのまま本番に引き継げます。本番にするときの初期費用は15万円（ノーコードの場合）で、仕上げ・ストア申請までAPPREXが行います。\n\n継続のお手続き・お見積りはこちらから。\n{$est}\n\n担当者と相談しながら決めたい方は、無料のオンライン相談をご予約ください。\n{$meet}\n" ),
			43200 => array( 'subject' => '【APPREX】体験お疲れさまでした。続きはいつでも', 'body' => "{name} 様\n\n無料体験の期間が終了しました。30日間、ありがとうございました。\n\n「もう少し考えたい」も、もちろん歓迎です。APPREXはいつでも再開でき、ご相談も無料です。タイミングが来たら、いつでもお声がけください。\n\n本番運用・お見積りはこちらからどうぞ。\n{$est}\n\n無料のオンライン相談：\n{$meet}\n" ),
		),
		// 見積もり・発注後：検討促進.
		'estimate' => array(
			1440  => array( 'subject' => '【APPREX】お見積り、ご不明点はありませんか？', 'body' => "{name} 様\n\nこのたびはお見積りをご利用いただき、ありがとうございます。\n\n金額や内容を見て、「ここはどういう意味？」「条件は調整できる？」と感じた点はありませんか。小さな疑問こそ、放っておくと検討が止まってしまう原因になりがちです。\n\nどんな細かいことでも構いません。このメールにご返信いただければ、担当が1つずつお答えします。条件のご相談も柔軟に承ります。\n\n画面を見ながら話したい方は、無料のオンライン相談（60分）をご予約ください。\n{$meet}\n" ),
			4320  => array( 'subject' => '【APPREX】ご発注後はこう進みます（最短2週間）', 'body' => "{name} 様\n\n「申し込んだあと、どう進むのか分からない」——これも、決断をためらわせる一因です。\n\nAPPREXの流れはシンプルです。①ヒアリングで要件整理 ②画面制作 ③申請・公開。専任の担当が伴走するので、初めての方でも迷いません。最短2週間で公開まで到達できます。\n\n進め方の詳細は、無料のオンライン相談でご説明します。ご都合のよい日時をお選びください。\n{$meet}\n" ),
			10080 => array( 'subject' => '【APPREX】初期費用を抑えて始める方法', 'body' => "{name} 様\n\nご検討ありがとうございます。費用を抑えて始める方法をご紹介します。\n\n・アプリのデザインと仕様書は、AIスタジオで無料で作れます\n・APPREXの基盤で作れる範囲（ノーコード）なら、初期費用は15万円だけ\n・月額はトライアル19,800円から。必要になったらプランを上げられます\n\nお見積りはこちらから確定できます。\n{$est}\n" ),
			20160 => array( 'subject' => '【APPREX】その投資、何ヶ月で回収できるか', 'body' => "{name} 様\n\n「コストはわかった。では、効果は？」——当然のご関心だと思います。\n\n同じ価格帯のお客様が、再来店・客単価・新規集客でどう成果を出しているか、事例で具体的に見られます。月額以上のリターンを生んでいるケースも少なくありません。\n{$cases}\n" ),
			43200 => array( 'subject' => '【APPREX】最後に、担当から直接ご提案させてください', 'body' => "{name} 様\n\nお見積りから1ヶ月。ご検討状況はいかがでしょうか。\n\nもし判断に迷う点が残っているなら、オンラインで直接お話しさせてください。貴社の状況に合わせて、プラン・予算・進め方を一緒に最適化します。\n\n押し売りはいたしません。「相談してよかった」と思っていただける時間をお約束します。ご都合のよい日時を、下のページからお選びください（このメールへのご返信でも結構です）。\n{$meet}\n" ),
		),
		// AIスタジオ会員登録後：デザイン → 仕様書 → 相談.
		'signup'   => array(
			1440  => array( 'subject' => '【APPREX】アプリのデザイン、もう作ってみましたか？', 'body' => "{name} 様\n\nAIスタジオへのご登録ありがとうございます。\n\n業種と店名を入れるだけで、ホーム・メニュー・クーポン・予約・会員証の5画面ができあがります。「予約ボタンを大きく」「緑で高級感を」のように言葉で頼めば、すぐに作り直せます。\n\nまずは1分、触ってみてください。\n" . ( function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : $home ) . "\n" ),
			4320  => array( 'subject' => '【APPREX】企画書と仕様書も、AIが作ります', 'body' => "{name} 様\n\nデザインができたら、次は欲しい機能を選ぶだけ。AIが企画書・仕様書・画面構成図と概算費用をまとめます。社内のご説明にもそのまま使えます。\n\nノーコードで作れるか、オリジナル開発が必要かもその場で分かります。\n" . ( function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : $home ) . "\n\n先に担当者と話したい方は、無料のオンライン相談（60分）もご予約いただけます。\n{$meet}\n" ),
			10080 => array( 'subject' => '【APPREX】作ったデザインのまま、制作を相談できます', 'body' => "{name} 様\n\nAIスタジオで作ったデザインと仕様書のまま、制作を相談できます。APPREXの基盤で作れる範囲なら、初期費用は150,000円です（基盤のカスタマイズは別途お見積もり）。\n\nミーティングでは作った画面を見ながら、正式なお見積りまでご案内します。相談・ミーティングは無料です。\n\n▼ ミーティングの予約（オンライン・60分）\n{$meet}\n\n▼ AIスタジオ\n" . ( function_exists( 'apprex_studio_url' ) ? apprex_studio_url() : $home ) . "\n" ),
		),
		// AIスタジオから相談後：ミーティング予約の後押し.
		'studio'   => array(
			1440 => array( 'subject' => '【APPREX】ミーティングのご予約はお済みですか？', 'body' => "{name} 様\n\n開発のご相談ありがとうございます。いただいたデザインと仕様書は担当者が確認済みです。\n\nオンラインミーティング（60分・無料）で、画面を見ながら細かいご要望を伺い、正式なお見積りをお出しします。まだの方は、下のページから日時をお選びください。\n{$meet}\n" ),
		),
		// 汎用（お問い合わせ）：10分後にお礼の1通目 → 翌日以降に長期ナーチャ.
		'contact'  => array(
			1440  => array( 'subject' => '【APPREX】「うちの業種でも作れる？」への答え', 'body' => "{name} 様\n\nお問い合わせありがとうございました。担当者からのご連絡とは別に、よくいただく疑問に1つお答えします。\n\n「アプリは飲食や美容みたいな“店舗系”のもの」と思われがちですが、APPREXは不動産・士業・教育・BtoB・コミュニティまで、業種を問わずお使いいただけます。会員管理・予約・プッシュ通知・電子カタログなど、必要な機能が最初からそろっているからです。\n\n{$try}\n「うちの場合は？」を直接聞きたい方は、無料のオンライン相談（60分）をどうぞ。\n{$meet}\n" ),
			4320  => array( 'subject' => '【APPREX】数字で見る、業種別のリアルな成果', 'body' => "{name} 様\n\n「本当に効果が出るの？」——一番気になるところだと思います。\n\n会員登録の増加、再来店率アップ、問い合わせ増など、導入事例を成果とあわせてまとめました。貴社に近いケースが、きっと見つかります。\n{$cases}\n" ),
			10080 => array( 'subject' => '【APPREX】アプリの費用、ここまで下げられます', 'body' => "{name} 様\n\nアプリ開発といえば数百万円——そう思って諦めてきた方は少なくありません。\n\nAPPREXなら、デザインと仕様書はAIスタジオで無料。APPREXの基盤で作れる範囲なら、初期費用15万円＋月額19,800円〜で公開できます。ホームページも初期費用0円・月額9,800円〜です。補助金のご相談もお受けしています。\n\n「自社の場合はいくら？」は、下のページで条件を選ぶだけで分かります。\n{$est}\n" ),
			43200 => array( 'subject' => '【APPREX】迷ったら、ひと言だけでも大丈夫です', 'body' => "{name} 様\n\nお問い合わせから1ヶ月。その後いかがでしょうか。\n\n「興味はあるけど、何から聞けばいいか分からない」——それで止まってしまうのは、もったいないことです。チャット・LINE・オンライン相談（無料）のどれでも、「自社の場合どう？」のひと言からご相談いただけます。\n{$meet}\n\nこのメールで、お問い合わせ後のご案内は最後です。ありがとうございました。\n" ),
		),
		// 代理店の申し込み後：説明会 → 売りやすい理由 → 代理店コード（金額は説明会でご説明する）.
		'partner'  => array(
			1440  => array( 'subject' => '【APPREX】代理店説明会のご予約はお済みですか？', 'body' => "{name} 様\n\n代理店へのお申し込みありがとうございます。\n\n報酬のしくみ・加盟金・代理店の始め方は、無料のオンライン説明会でくわしくご説明しています。LINEで日程を選ぶだけで予約でき、参加URLもLINEに届きます。\n{$sem}\n" ),
			4320  => array( 'subject' => '【APPREX】APPREXが売りやすい3つの理由', 'body' => "{name} 様\n\n代理店として紹介しやすい理由を3つお伝えします。\n\n1. その場で「アプリの形」を見せられる：AIスタジオ（無料）で、お客様の業種と店名から画面と仕様書がすぐにできます。\n2. 料金がわかりやすい：ノーコードなら初期費用15万円＋月額19,800円〜。カスタマイズはお見積もり。\n3. 報酬が積み上がる：初期費用だけでなく、月額利用料からも、お客様が契約を続けるかぎり毎月お支払いするストック型です。\n\n報酬率と加盟金は、説明会でご説明します。\n{$sem}\n" ),
			10080 => array( 'subject' => '【APPREX】代理店コードで、ご紹介がきちんと記録されます', 'body' => "{name} 様\n\n代理店契約のあと、あなた専用のURL（代理店コード）をお渡しします。そのURLから届いたお問い合わせ・AIスタジオの会員登録は、あなたのご紹介として記録されます。\n\nご紹介の状況と毎月の報酬は、代理店専用ページでいつでも確認できます。あわせて、営業資料・料金表と、AIスタジオを使った商談の進め方もご用意しています。説明会がまだの方は、LINEからご予約ください。\n{$sem}\n" ),
		),
	);

	$steps = isset( $sequences[ $type ] ) ? $sequences[ $type ] : $sequences['contact'];
	return apply_filters( 'apprex_step_mails', $steps, $type );
}

/**
 * Meeting reminders relative to the booked datetime.
 * offset in seconds (negative = before the meeting). {name}/{when} replaced.
 *
 * @return array<string,array{offset:int,subject:string,body:string}>
 */
function apprex_meeting_reminders() {
	$reminders = array(
		'before_1d' => array(
			'offset'  => -DAY_IN_SECONDS,
			'subject' => '【APPREX】明日はオンラインミーティングのお約束です',
			'body'    => "{name} 様\n\n明日 {when} にオンラインミーティングを予定しております。接続URLは別途ご案内いたします。ご都合が変わる場合はご返信ください。\n",
		),
		'before_1h' => array(
			'offset'  => -HOUR_IN_SECONDS,
			'subject' => '【APPREX】まもなくミーティング開始のお時間です',
			'body'    => "{name} 様\n\n本日 {when} よりミーティングを予定しております。お時間になりましたらご参加ください。\n",
		),
		'after_1d'  => array(
			'offset'  => DAY_IN_SECONDS,
			'subject' => '【APPREX】先日はありがとうございました',
			'body'    => "{name} 様\n\n先日はお時間をいただきありがとうございました。正式なお見積りは、担当者からお送りします。ご不明な点は、このメールにご返信ください。\n",
		),
	);
	return apply_filters( 'apprex_meeting_reminders', $reminders );
}

/**
 * Ensure the hourly cron is scheduled (hourly to support meeting reminders).
 */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'apprex_dripmail_cron' ) ) {
		wp_schedule_event( time() + MINUTE_IN_SECONDS * 5, 'hourly', 'apprex_dripmail_cron' );
	}
} );
add_action( 'apprex_dripmail_cron', 'apprex_process_dripmail' );

/**
 * Send a single step/reminder mail with footer + unsubscribe.
 *
 * @param int    $id      Subscriber post ID.
 * @param string $email   Recipient.
 * @param string $subject Subject.
 * @param string $body    Body (placeholders already replaced).
 * @param bool   $unsub   Append unsubscribe link.
 */
function apprex_send_drip_mail( $id, $email, $subject, $body, $unsub = true ) {
	$html = apprex_render_email(
		$subject,
		$body,
		array(
			'heading'   => apprex_email_heading_from_subject( $subject ),
			'unsub_url' => $unsub ? apprex_unsubscribe_url( $id, $email ) : '',
		)
	);
	wp_mail( $email, $subject, $html, apprex_mail_headers() );
}

/**
 * Process the drip/reminder queue across inquiries and orders (type-aware).
 */
function apprex_process_dripmail() {
	if ( ! get_option( 'apprex_drip_enabled', 1 ) ) {
		return;
	}
	$subscribers = get_posts(
		array(
			'post_type'      => array( 'apprex_inquiry', 'apprex_order' ),
			// Explicit list: orders use the custom 'apprex_new' status which 'any' excludes.
			'post_status'    => array( 'publish', 'apprex_new' ),
			'posts_per_page' => 300,
			'meta_key'       => 'apprex_drip_active',
			'meta_value'     => '1',
			'fields'         => 'ids',
		)
	);
	if ( empty( $subscribers ) ) {
		return;
	}
	$now = time();

	foreach ( $subscribers as $id ) {
		$type  = get_post_meta( $id, 'apprex_drip_type', true );
		$type  = $type ? $type : 'contact';
		$email = get_post_meta( $id, 'apprex_email', true );
		$name  = get_post_meta( $id, 'apprex_name', true );
		$sent  = (array) get_post_meta( $id, 'apprex_drip_sent', true );

		if ( ! is_email( $email ) ) {
			update_post_meta( $id, 'apprex_drip_active', 0 );
			continue;
		}

		if ( 'meeting' === $type ) {
			apprex_run_meeting_reminders( $id, $email, $name, $sent, $now );
			continue;
		}

		// 契約・お見積りまで進んだお客様、配信停止した人には案内を送らない（代理店向けは除く）。
		if ( 'partner' !== $type && ( apprex_drip_is_client( $email ) || apprex_drip_unsubscribed( $email ) ) ) {
			update_post_meta( $id, 'apprex_drip_active', 0 );
			update_post_meta( $id, 'apprex_drip_stopped', 'client_or_unsub' );
			continue;
		}

		$start = (int) get_post_meta( $id, 'apprex_drip_start', true );
		if ( ! $start ) {
			update_post_meta( $id, 'apprex_drip_active', 0 );
			continue;
		}
		$steps = apprex_step_mails( $type );
		ksort( $steps );
		if ( empty( $steps ) ) {
			update_post_meta( $id, 'apprex_drip_active', 0 );
			continue;
		}
		$max_offset = max( array_keys( $steps ) );

		// オフセットは「分」単位。テストモード時は 1日(1440分)→1分 に圧縮（管理画面で切替）。
		$sec_per_unit = get_option( 'apprex_drip_test_mode' ) ? ( MINUTE_IN_SECONDS / 1440 ) : MINUTE_IN_SECONDS;

		foreach ( $steps as $offset => $mail ) {
			if ( in_array( $offset, $sent, true ) ) {
				continue;
			}
			if ( $now >= $start + ( $offset * $sec_per_unit ) ) {
				apprex_send_drip_mail( $id, $email, $mail['subject'], str_replace( '{name}', $name, $mail['body'] ) );
				$sent[] = $offset;
				update_post_meta( $id, 'apprex_drip_sent', $sent );
			}
		}

		if ( in_array( $max_offset, $sent, true ) || $now > $start + ( 366 * DAY_IN_SECONDS ) ) {
			update_post_meta( $id, 'apprex_drip_active', 0 );
		}
	}
}

/**
 * Send due meeting reminders for one booking.
 *
 * @param int    $id    Inquiry ID.
 * @param string $email Recipient.
 * @param string $name  Name.
 * @param array  $sent  Already-sent reminder keys.
 * @param int    $now   Current timestamp.
 */
function apprex_run_meeting_reminders( $id, $email, $name, $sent, $now ) {
	// Google カレンダーに一本化している場合は WordPress からは送らない（サイトで予約を受け付けるときは送る）。
	$apprex_mb = function_exists( 'apprex_mb_enabled' ) && apprex_mb_enabled();
	if ( ! get_option( 'apprex_wp_meeting_reminders', 0 ) && ! $apprex_mb ) {
		update_post_meta( $id, 'apprex_drip_active', 0 );
		return;
	}
	$meeting_at = (int) get_post_meta( $id, 'apprex_meeting_at', true );
	if ( ! $meeting_at ) {
		update_post_meta( $id, 'apprex_drip_active', 0 );
		return;
	}
	$when = wp_date( 'Y年n月j日(D) H:i', $meeting_at );

	foreach ( apprex_meeting_reminders() as $key => $r ) {
		if ( in_array( $key, $sent, true ) ) {
			continue;
		}
		$is_before = $r['offset'] < 0;
		// Don't fire a pre-meeting reminder once the meeting time has passed.
		if ( $is_before && $now >= $meeting_at ) {
			$sent[] = $key;
			update_post_meta( $id, 'apprex_drip_sent', $sent );
			continue;
		}
		if ( $now >= $meeting_at + (int) $r['offset'] ) {
			if ( get_post_meta( $id, 'apprex_mb_cancel', true ) ) {
				update_post_meta( $id, 'apprex_drip_active', 0 );
				return;
			}
			$body = str_replace( array( '{name}', '{when}' ), array( $name, $when ), $r['body'] );
			$murl = $apprex_mb ? ( function_exists( 'apprex_mj_link' ) ? apprex_mj_link( $id ) : (string) apprex_mb_settings()['url'] ) : '';
			if ( $murl && $is_before ) {
				$body = str_replace( '接続URLは別途ご案内いたします。', '', $body ) . "\nお時間になりましたら、下のボタンからご参加ください（Google Meet）。\n{$murl}\n";
			}
			apprex_send_drip_mail( $id, $email, $r['subject'], $body, false );
			if ( $apprex_mb ) {
				apprex_mb_line( $id, $key );
			}
			$sent[] = $key;
			update_post_meta( $id, 'apprex_drip_sent', $sent );
		}
	}

	// Complete two days after the meeting.
	if ( $now > $meeting_at + ( 2 * DAY_IN_SECONDS ) ) {
		update_post_meta( $id, 'apprex_drip_active', 0 );
	}
}

/**
 * Unsubscribe URL with a token.
 *
 * @param int    $id    Inquiry ID.
 * @param string $email Email.
 * @return string
 */
function apprex_unsubscribe_url( $id, $email ) {
	$token = wp_hash( $id . '|' . $email );
	return add_query_arg(
		array(
			'apprex_unsub' => $id,
			'token'        => $token,
		),
		home_url( '/' )
	);
}

/**
 * Handle unsubscribe requests.
 */
add_action( 'template_redirect', function () {
	if ( empty( $_GET['apprex_unsub'] ) || empty( $_GET['token'] ) ) {
		return;
	}
	$id    = absint( $_GET['apprex_unsub'] );
	$email = get_post_meta( $id, 'apprex_email', true );
	$token = sanitize_text_field( wp_unslash( $_GET['token'] ) );
	if ( $email && hash_equals( wp_hash( $id . '|' . $email ), $token ) ) {
		// このメールアドレス宛ての案内をすべて止め、今後も送らない。
		update_post_meta( $id, 'apprex_drip_active', 0 );
		foreach ( apprex_drip_active_for( $email ) as $other ) {
			update_post_meta( $other, 'apprex_drip_active', 0 );
		}
		$list   = (array) get_option( 'apprex_drip_unsub_list', array() );
		$list[] = wp_hash( strtolower( (string) $email ) );
		update_option( 'apprex_drip_unsub_list', array_values( array_unique( $list ) ), false );
		wp_die( 'メール配信を停止しました。ご利用ありがとうございました。', '配信停止', array( 'response' => 200 ) );
	}
	wp_die( 'リンクが無効です。', '配信停止', array( 'response' => 400 ) );
} );

/**
 * Clear the cron on theme switch.
 */
add_action( 'switch_theme', function () {
	$ts = wp_next_scheduled( 'apprex_dripmail_cron' );
	if ( $ts ) {
		wp_unschedule_event( $ts, 'apprex_dripmail_cron' );
	}
} );

/* -------------------------------------------------------------------------
 * Admin: show inquiry details
 * ---------------------------------------------------------------------- */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'apprex_inquiry_detail', 'お問い合わせ詳細', 'apprex_inquiry_detail_box', 'apprex_inquiry', 'normal', 'high' );
} );

/**
 * Render inquiry detail meta box.
 *
 * @param WP_Post $post Inquiry.
 */
function apprex_inquiry_detail_box( $post ) {
	$keys = array(
		'apprex_type'    => '種別',
		'apprex_name'    => 'お名前',
		'apprex_company' => '会社名',
		'apprex_email'   => 'メール',
		'apprex_phone'   => '電話',
		'apprex_message' => '内容',
	);
	echo '<table class="form-table">';
	foreach ( $keys as $k => $label ) {
		echo '<tr><th>' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( (string) get_post_meta( $post->ID, $k, true ) ) ) . '</td></tr>';
	}
	$sent   = (array) get_post_meta( $post->ID, 'apprex_drip_sent', true );
	$active = (int) get_post_meta( $post->ID, 'apprex_drip_active', true );
	$dtype  = get_post_meta( $post->ID, 'apprex_drip_type', true );
	$mt     = (int) get_post_meta( $post->ID, 'apprex_meeting_at', true );
	if ( $mt ) {
		echo '<tr><th>予約日時</th><td>' . esc_html( wp_date( 'Y-m-d H:i', $mt ) ) . '</td></tr>';
	}
	$kind = ( 'meeting' === $dtype ) ? 'リマインダー' : 'ステップメール';
	echo '<tr><th>' . esc_html( $kind ) . '</th><td>' . ( $active ? '配信中' : '停止/完了' ) . '（種別: ' . esc_html( $dtype ? $dtype : '-' ) . ' ／ 送信済み: ' . esc_html( $sent ? implode( ', ', $sent ) : 'なし' ) . '）</td></tr>';
	echo '</table>';
}
