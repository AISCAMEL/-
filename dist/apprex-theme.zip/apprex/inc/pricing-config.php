<?php
/**
 * 料金の単一ソース（APPREX仕様）。
 * 見積もり計算・料金ページ・チャット回答・GAS連携が全てここを参照。
 *
 * 方針：
 * - アプリの作り方は3つ。
 *   ノーコード（APPREXの基盤で作れる範囲）：初期費用（諸経費）150,000円＋月額。デザイン・仕様書はAIスタジオで無料。
 *   カスタマイズ（基盤をカスタマイズ）：内容と最初のロットで変わるため、別途お見積もり。
 *   フルスクラッチ：用途に応じて相談し、すべてお見積もり。
 * - 仕様書ができたら、ホームページ制作やオプションもあわせて提案する（AIスタジオの「ご提案」）。
 * - チャット・GPS等は一回限りのオプション。
 * - マッチング/カスタム/オンプレミスは個別見積（要相談）として別掲。
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * アプリ基本機能の一覧（トライアル）。
 *
 * @return string[]
 */
function apprex_app_basic_features() {
	return array(
		'簡単作成CMS', 'TOPデザインテンプレート', 'デザイン編集機能', 'ページ作成機能',
		'プッシュ通知（6種類）', '予約機能', 'スタンプカード', 'クーポン', 'ポイント機能',
		'スタンプラリー', '会員機能', '会員証機能', 'アンケート', 'ブログ機能', '動画機能',
		'LINEで友達紹介', 'HTML編集', '申し込みフォーム作成', 'DL分析', 'フォトギャラリー',
		'SNS連動', 'ウェブビュー機能', '各種ページ作成',
	);
}

/**
 * 見積もりで選べるオプション。
 *
 * @param string $svc app / hp。
 * @return array key => [label, price, billing, group, desc, qty, unit, exclusive, quote]
 */
function apprex_pricing_extra_options( $svc ) {
	$g_fn  = 'アプリに機能を足す（一回）';
	$g_mk  = 'Googleマップ集客 AIMEO（月額）';
	$g_hp  = 'ホームページも作る（月額・初期0円）';
	$g_q   = 'ご相談・お見積り（選ぶと相談内容に入ります）';
	$aimeo = array(
		'aimeo_l' => array( 'label' => 'AIMEO ライト', 'price' => 15000, 'billing' => 'monthly', 'group' => $g_mk, 'exclusive' => 'aimeo', 'desc' => 'AIが投稿・口コミ返信の下書きを作り、担当者が確認して載せる' ),
		'aimeo_s' => array( 'label' => 'AIMEO スタンダード', 'price' => 30000, 'billing' => 'monthly', 'group' => $g_mk, 'exclusive' => 'aimeo', 'desc' => '毎週の投稿まで運用' ),
		'aimeo_p' => array( 'label' => 'AIMEO プロ', 'price' => 50000, 'billing' => 'monthly', 'group' => $g_mk, 'exclusive' => 'aimeo', 'desc' => '複数店舗の運用' ),
	);
	$quote = array(
		'line'    => array( 'label' => 'LINE公式アカウントの構築', 'desc' => 'リッチメニュー・ステップ配信・アプリとの連携' ),
		'llmo'    => array( 'label' => 'LLMO（AI検索対策）', 'desc' => 'ChatGPTなどのAIに紹介されやすくする' ),
		'banner'  => array( 'label' => 'バナー・画像の制作', 'desc' => 'アプリ内・SNS・広告用の画像' ),
		'seo'     => array( 'label' => '構造化データ（SEO）', 'desc' => '検索結果に詳しく表示されるように' ),
		'api'     => array( 'label' => '外部サービスとの連動（API）', 'desc' => '予約・POS・決済などのシステムとつなぐ' ),
		'kikan'   => array( 'label' => '基幹システムとの連動', 'desc' => '社内の顧客・在庫システムなどとつなぐ' ),
		'custom'  => array( 'label' => '機能のカスタマイズ', 'desc' => '基盤にない機能を足す・変える' ),
		'subsidy' => array( 'label' => '補助金の申請サポート', 'desc' => '使える制度の確認・企画書と見積書の用意' ),
	);
	$out = array();
	if ( 'app' === $svc ) {
		$out['chat'] = array( 'label' => 'チャット機能', 'price' => 300000, 'billing' => 'once', 'group' => $g_fn, 'desc' => '予約や質問に、アプリの中で個別に対応' );
		$out['gps']  = array( 'label' => '位置情報プッシュ（GPS）', 'price' => 20000, 'billing' => 'once', 'group' => $g_fn, 'qty' => 10, 'unit' => 'カ所', 'desc' => 'お店の近くに来た人にお知らせ（1カ所ごと）' );
		$out        += $aimeo;
		$hp_plans    = array(
			'hp_light'    => array( 'Light', 9800, '〜5ページ・月1回の更新サポート' ),
			'hp_standard' => array( 'Standard', 19800, '〜10ページ＋LP1本・月2回の更新サポート' ),
			'hp_premium'  => array( 'Premium', 39800, '〜20ページ・EC・会員機能・月3回の更新サポート' ),
		);
		foreach ( $hp_plans as $k => $v ) {
			$out[ $k ] = array( 'label' => 'ホームページ制作 ' . $v[0], 'price' => $v[1], 'billing' => 'monthly', 'group' => $g_hp, 'exclusive' => 'hp', 'desc' => $v[2] );
		}
		$keys = array( 'line', 'llmo', 'banner', 'seo', 'api', 'kikan', 'custom', 'subsidy' );
	} else {
		$out += $aimeo;
		$keys = array( 'banner', 'seo', 'line', 'llmo', 'subsidy' );
	}
	foreach ( $keys as $k ) {
		$out[ $k ] = $quote[ $k ] + array( 'price' => 0, 'billing' => 'once', 'group' => $g_q, 'quote' => true );
	}
	return $out;
}

/**
 * 価格モデル。
 *
 * @return array
 */
function apprex_pricing_config() {
	$config = array(
		'currency' => 'JPY',
		'campaign' => array(
			'label'           => 'AIスタジオは無料。ノーコードなら初期費用15万円＋月額',
			'initial_to_zero' => true, // ホームページ制作の初期費用0円。
		),
		'services' => array(
			'app' => array(
				'label'      => 'アプリ開発（月額制）',
				'billing'    => 'monthly',
				'min_months' => 12, // 1年契約。
				// アプリ登録時に別途必要（iOS/Android 一律）。キャンペーン対象外。
				'registration_fee'   => 55000,
				'registration_label' => 'アプリ登録費（iOS/Android）',
				'plans'      => array(
					'trial'    => array(
						'label'           => 'トライアル（基本機能）',
						'monthly'         => 19800,
						'monthly_regular' => 19800,
						'initial'         => 100000,
						'desc'            => '基本機能・1年契約。まずはここから。',
						'note'            => '',
					),
					'start'    => array(
						'label'           => 'スタート（電子カタログ）',
						'monthly'         => 39800,
						'monthly_regular' => 39800,
						'initial'         => 200000,
						'desc'            => 'トライアル＋電子カタログ機能。',
						'note'            => '電子カタログ11冊以上は別途。',
					),
					'business' => array(
						'label'           => 'ビジネス（多店舗）',
						'monthly'         => 59800,
						'monthly_regular' => 59800,
						'initial'         => 300000,
						'desc'            => 'スタート＋多店舗の展開・運用。店舗一覧、いつもの店舗、店舗ごとの配信。本部・店舗の管理は専用システムをご案内。',
						'note'            => '20店舗まで月額に含まれます。21店舗目からは1店舗ごとに月額+1万円。',
					),
				),
				// 初期費用（作り方で選ぶ）。quote のものは金額を出さず、個別見積（apprex_quote_plans のキー）へ。
				'setup'      => array(
					'ai'      => array( 'label' => 'ノーコード（APPREXの基盤で作れる範囲）', 'price' => 150000, 'desc' => 'APPREXの基盤の機能で作るアプリです。初期費用（諸経費）15万円＋月額。初期設定・サーバー設定・制作・ストア申請を含みます。デザインと仕様書はAIスタジオで無料で作れます。' ),
					'custom'  => array( 'label' => 'カスタマイズ（基盤をカスタマイズ）', 'price' => 0, 'quote' => 'original', 'price_label' => 'お見積もり', 'desc' => '基盤に機能を足す・変えるなどのカスタマイズです。初期費用は内容と最初のロットによって変わるため、お見積もりします。' ),
					'scratch' => array( 'label' => 'フルスクラッチ（ゼロから開発）', 'price' => 0, 'quote' => 'custom', 'price_label' => '要相談', 'desc' => '用途に合わせてゼロから開発します。金額はすべてお見積もり。用途をお聞きしてご提案します。' ),
				),
				// オプション。billing：once＝一回／monthly＝毎月。quote＝お見積り（選ぶと相談内容に入る）。
				// qty＝数を選べる（上限）。exclusive＝同じグループから1つだけ。
				'options'    => apprex_pricing_extra_options( 'app' ),
				// 要相談オプション（金額は個別見積）。
				'quote_options' => array(
					'API連動', '基幹システム連動', 'オンプレミス', '機能カスタマイズ', '補助金サポート',
				),
			),
			'hp'  => array(
				'label'      => 'ホームページ制作（月額制・初期費用0円）',
				'billing'    => 'monthly',
				'min_months' => 12,
				'plans'      => array(
					'light'    => array(
						'label' => 'Light', 'monthly' => 9800, 'monthly_regular' => 9800, 'initial' => 0,
						'desc' => '基本的なコーポレートサイト',
						'support' => array( '〜5ページ', '月1回までの更新サポート', 'お問い合わせフォーム', '常時SSL', '基本SEO設定' ),
					),
					'standard' => array(
						'label' => 'Standard', 'monthly' => 19800, 'monthly_regular' => 19800, 'initial' => 0,
						'desc' => 'LP付き・問い合わせ充実',
						'support' => array( '〜10ページ＋LP1本', '月2回までの更新サポート', '予約・問い合わせ強化', '構造化データ（基本）' ),
					),
					'premium'  => array(
						'label' => 'Premium', 'monthly' => 39800, 'monthly_regular' => 39800, 'initial' => 0,
						'desc' => 'EC・会員機能付き',
						'support' => array( '〜20ページ', '月3回までの更新サポート', 'EC・会員機能', '優先サポート' ),
					),
				),
				// HPのオプション（AIMEOは月額、そのほかはお見積り）。
				'options'       => apprex_pricing_extra_options( 'hp' ),
				'quote_options' => array(
					'バナー制作', '構造化（SEO）', 'LINE構築', 'AIMEO（AIで運用するMEO）', 'LLMO構築',
				),
			),
		),
	);

	return apply_filters( 'apprex_pricing_config', $config );
}

/**
 * 個別見積（要相談）の上位プラン。料金ページ・チャットで案内。
 *
 * @return array
 */
function apprex_quote_plans() {
	return apply_filters(
		'apprex_quote_plans',
		array(
			'original' => array(
				'label'    => 'カスタマイズ（基盤をカスタマイズ）',
				'lead'     => 'APPREXの基盤をベースに、ご要望の機能・デザインを足したり変えたりするカスタマイズ案件です。初期費用は内容と最初のロットによって変わるため、お見積もりします。',
				'rows'     => array(
					'初期費用'   => 'お見積もり（内容と最初のロットにより変わります）',
					'月額'       => 'お見積もり',
					'納期'       => '要件により算出',
					'仕様定義'   => '無料オンライン相談で要件をヒアリング',
				),
				'examples' => array( '基盤カスタマイズ', '機能追加', '独自デザイン', '業務アプリ' ),
			),
			'custom'   => array(
				'label' => 'フルスクラッチ（ゼロから開発）',
				'lead'  => '用途に合わせて、ゼロから開発します。金額はすべてお見積もり。まずは用途をお聞きしてご提案します。',
				'rows'  => array(
					'開発費'     => '要相談（用途に応じてお見積もり）',
					'月額保守'   => '要相談',
					'仕様定義'   => '1週間〜',
					'開発期間'   => '3ヶ月〜',
					'用途'       => 'マッチング・業務用・課金アプリ等あらゆるアプリ',
				),
			),
			'matching' => array(
				'label'    => 'マッチングアプリ開発',
				'lead'     => 'スキルマッチング／ビジネスマッチング／出会い系／フリマ等。Flutterスクラッチ開発でカスタマイズ自由。',
				'rows'     => array(
					'開発費用（iOS/Android）' => '300万円〜',
					'月額保守・サーバ代'      => '7万円〜',
					'制作期間'                => '3ヶ月〜',
					'開発言語'                => 'アプリ：Flutter／管理：PHP',
					'サーバ'                  => 'AWS無料提供',
					'決済'                    => 'iOS/Android 内部課金 または Square等の外部課金',
					'最低利用期間'            => '1年契約（12ヶ月）',
				),
				'examples' => array( 'スキルマッチング', 'ビジネスマッチング', '出会い系マッチング', 'フリマアプリ' ),
				'cta'      => 'matching-appli.net も参照',
			),
			'onprem'   => array(
				'label' => 'オンプレミスプラン',
				'lead'  => 'プログラムソース買取。自社で改造可能。',
				'rows'  => array(
					'ライセンス' => '1ライセンス',
					'サーバ'     => '自社サーバー または 弊社サーバー',
					'価格'       => '2,000万円〜',
					'月額管理費' => '20万円〜',
				),
			),
		)
	);
}

/**
 * 今月のキャンペーン後・初期費用（0円 or 通常）。
 *
 * @param int $regular 通常初期費用。
 * @return int
 */
function apprex_campaign_initial( $regular ) {
	$c = apprex_pricing_config();
	return ! empty( $c['campaign']['initial_to_zero'] ) ? 0 : (int) $regular;
}

/**
 * サーバー側で見積りを再計算（改ざん防止）。
 *
 * @param string   $service Service key.
 * @param string   $plan    Plan key.
 * @param string[] $options Option keys.
 * @param string   $setup   初期費用の種類（ai。金額の出ないカスタマイズ・フルスクラッチは使えない）。
 * @return array|WP_Error
 */
function apprex_calculate_estimate( $service, $plan, $options = array(), $setup = '', $qtys = array() ) {
	$qtys   = is_array( $qtys ) ? $qtys : array();
	$config = apprex_pricing_config();
	if ( empty( $config['services'][ $service ] ) ) {
		return new WP_Error( 'invalid_service', 'サービスの指定が正しくありません。' );
	}
	$svc = $config['services'][ $service ];
	if ( empty( $svc['plans'][ $plan ] ) ) {
		return new WP_Error( 'invalid_plan', 'プランの指定が正しくありません。' );
	}
	$p = $svc['plans'][ $plan ];

	$monthly         = (int) $p['monthly'];
	$monthly_regular = (int) ( $p['monthly_regular'] ?? $p['monthly'] );
	$initial_regular = (int) ( $p['initial'] ?? 0 );

	$options = array_values( array_unique( (array) $options ) );
	// 以前の形式（制作代行をオプションで送る）も受け付ける。
	if ( '' === $setup ) {
		$setup = in_array( 'seisaku', $options, true ) ? 'full' : 'ai';
	}
	$options = array_values( array_diff( $options, array( 'seisaku_ai', 'seisaku' ) ) );

	// 初期費用：作り方ごとの金額（初期設定・制作を含む）。
	$setups = isset( $svc['setup'] ) ? $svc['setup'] : array();
	if ( $setups ) {
		$setup       = isset( $setups[ $setup ] ) && empty( $setups[ $setup ]['quote'] ) ? $setup : 'ai';
		$setup_label = $setups[ $setup ]['label'];
		$initial     = (int) $setups[ $setup ]['price'];
	} else {
		$setup       = '';
		$setup_label = '';
		$initial     = apprex_campaign_initial( $initial_regular );
	}

	$opt_total   = 0; // 一回のオプション。
	$opt_monthly = 0; // 毎月のオプション（AIMEO・ホームページなど）。
	$opt_lines   = array();
	$excl        = array();
	foreach ( $options as $opt_key ) {
		if ( empty( $svc['options'][ $opt_key ] ) ) {
			continue;
		}
		$o = $svc['options'][ $opt_key ];
		if ( ! empty( $o['exclusive'] ) ) {
			if ( isset( $excl[ $o['exclusive'] ] ) ) {
				continue; // 同じグループからは1つだけ。
			}
			$excl[ $o['exclusive'] ] = 1;
		}
		$qty   = ! empty( $o['qty'] ) ? max( 1, min( (int) $o['qty'], (int) ( $qtys[ $opt_key ] ?? 1 ) ) ) : 1;
		$price = (int) ( $o['price'] ?? 0 ) * $qty;
		$bill  = (string) ( $o['billing'] ?? 'once' );
		if ( empty( $o['quote'] ) ) {
			if ( 'monthly' === $bill ) {
				$opt_monthly += $price;
			} else {
				$opt_total += $price;
			}
		}
		$opt_lines[] = array(
			'key'     => $opt_key,
			'label'   => $o['label'] . ( $qty > 1 ? '（' . $qty . ( $o['unit'] ?? '' ) . '）' : '' ),
			'price'   => $price,
			'billing' => $bill,
			'quote'   => ! empty( $o['quote'] ),
			'qty'     => $qty,
		);
	}

	$initial_total = $initial + $opt_total; // 一回のオプションは初期にまとめて。

	// アプリ登録費（iOS/Android）はキャンペーン対象外で別途必要。
	$registration       = (int) ( $svc['registration_fee'] ?? 0 );
	$registration_label = (string) ( $svc['registration_label'] ?? 'アプリ登録費' );
	$initial_total     += $registration;

	$annual_est = ( $monthly + $opt_monthly ) * 12 + $initial_total;

	return array(
		'service'            => $service,
		'service_label'      => $svc['label'],
		'plan'               => $plan,
		'plan_label'         => $p['label'],
		'billing'            => 'monthly',
		'monthly'            => $monthly,
		'monthly_regular'    => $monthly_regular,
		'initial'            => $initial,
		'initial_regular'    => $initial_regular,
		'setup'              => $setup,
		'setup_label'        => $setup_label,
		'registration'       => $registration,
		'registration_label' => $registration_label,
		'options'            => $opt_lines,
		'options_total'      => $opt_total,
		'options_monthly'    => $opt_monthly,
		'initial_total'      => $initial_total,
		'annual_est'         => $annual_est,
		'min_months'         => (int) $svc['min_months'],
	);
}

/**
 * チャット用の料金要約（自動でAIに渡る）。
 *
 * @return string
 */
function apprex_pricing_summary_text() {
	$c     = apprex_pricing_config();
	$lines = array();

	$app = $c['services']['app'];
	$lines[] = '【アプリ開発（月額制・1年契約）】';
	$lines[] = '- AIスタジオ（無料会員登録）でのデザイン・試作・仕様定義書づくりと相談は無料。';
	$lines[] = '- 代理店（紹介・販売・OEM）：報酬は初期費用と月額利用料からのストック型、加盟金は種類ごとに決まっている。報酬率・加盟金の金額は公開しておらず、無料のオンライン説明会（LINEで予約：' . ( function_exists( 'apprex_seminar_url' ) ? apprex_seminar_url() : home_url( '/partner/' ) ) . '）でご説明する。チャットでは金額を答えず、説明会へご案内する。月額費用・ノルマなし。詳しくは代理店募集ページ（/partner/）。';
	$lines[] = '- ビジネスプラン（多店舗）で制作するもの：店舗一覧・店舗ページ、いつもの店舗（お気に入り）、店舗ごとの配信（全店／店舗／エリア）、全店共通または店舗ごとのポイント・会員証、店舗を選ぶ予約・ネットショップ、新店舗の追加手順と店舗スタッフ向けの説明。本部と店舗の権限分け・店舗別の集計は、多店舗管理の別システムを案内する。20店舗まで月額に含み、21店舗目から1店舗ごとに月額+1万円。';
	$lines[] = '- ホームページはAIプランナー（AIスタジオ ホームページ版）を使うと制作費0円、月々の費用（月額9,800円〜）だけで持てる。AIプランナーが業種と要望から、ホームページの試作（ページ構成・文章・色）とサイトマップ・仕様書を作り、そのまま制作を相談できる。';
	$lines[] = '- アプリの作り方と初期費用は3つ。(1)ノーコード（APPREXの基盤で作れる範囲）：初期費用（諸経費）150,000円＋月額。初期設定・制作・ストア申請を含む。デザイン・仕様書はAIスタジオで無料。(2)カスタマイズ（基盤をカスタマイズ）：初期費用は内容と最初のロットで変わるため別途お見積もり。(3)フルスクラッチ：用途に応じて相談し、すべてお見積もり。カスタマイズ・フルスクラッチの金額は推測で答えず、無料のオンライン相談へ案内する。自分で設定する0円のプランはない。「制作代行費」ではなく「初期費用」と呼ぶ。';
	$lines[] = '- 仕様書ができたら、ホームページ制作・オプション・集客施策（LINE構築・AIMEOなど）もあわせて提案する。';
	$lines[] = '- AIMEO：AIで運用するMEO（Googleマップ対策）。投稿・口コミ返信・ビジネスの説明文の下書きをAIが作り、担当者が確認してGoogleビジネスプロフィールに載せる。ライト月15,000円／スタンダード月30,000円（毎週の投稿運用）／プロ月50,000円（複数店舗）。順位の保証はしない。';
	$lines[] = '- 補助金：小規模事業者持続化補助金や自治体の補助金を案内し、申請に使う企画書・見積書の用意と、交付決定に合わせたスケジュールをサポート。APPREXはIT導入補助金の支援事業者ではないので、IT導入補助金は対象外。申請書の作成代行はしない（作成・提出はお客様、必要なら商工会・商工会議所や行政書士に相談）。補助率・上限は回ごとに変わるので断定しない。' . ( function_exists( 'apprex_rn_public' ) && apprex_rn_public() ? '案内ページ：' . home_url( '/subsidy/' ) : '' );
	foreach ( $app['plans'] as $p ) {
		$lines[] = sprintf( '- %s：月額%s円', $p['label'], number_format( $p['monthly'] ) );
	}
	$opts = array();
	foreach ( $app['options'] as $o ) {
		if ( empty( $o['quote'] ) && 'monthly' !== ( $o['billing'] ?? 'once' ) ) {
			$opts[] = sprintf( '%s(%s円%s)', $o['label'], number_format( $o['price'] ), ! empty( $o['unit'] ) ? '／1' . $o['unit'] : '' );
		}
	}
	$lines[] = '  オプション：' . implode( ' / ', $opts ) . '。1年契約・DL課金なし・プッシュ無制限。';
	if ( ! empty( $app['registration_fee'] ) ) {
		$lines[] = '  ' . $app['registration_label'] . '：一律' . number_format( $app['registration_fee'] ) . '円（iOS/Android、アプリ登録時に別途必要）。';
	}

	$lines[] = '【ホームページ制作（初期費用0円・月額）】Light 9,800円／Standard 19,800円／Premium 39,800円。プラン毎にサポート範囲あり。追加項目（バナー制作・構造化・LINE構築・AIMEO（AIで運用するMEO）・LLMO構築）はすべて別途見積もり。';

	$lines[] = '【個別見積（要相談）】';
	foreach ( apprex_quote_plans() as $q ) {
		$lines[] = '- ' . $q['label'] . '：' . $q['lead'];
	}
	$lines[] = 'マッチングアプリ開発：開発費 300万円〜、月額保守7万円〜、Flutterスクラッチ、期間3ヶ月〜。オリジナル開発も期間3ヶ月〜。';
	$lines[] = '30日間の管理画面体験は無料。詳しい見積りは /estimate、上位プランはお問い合わせへ。';
	return implode( "\n", $lines );
}

/**
 * 見積りの初期費用の説明（メール・画面で共通）。
 *
 * @param array $e Estimate.
 * @return string 例：「150,000円（ノーコード（APPREXの基盤で作れる範囲））」
 */
/** オプション1行の文（メール・画面用）。 */
function apprex_estimate_option_text( $o ) {
	if ( ! empty( $o['quote'] ) ) {
		return $o['label'] . '（お見積り）';
	}
	return $o['label'] . '（' . ( 'monthly' === ( $o['billing'] ?? 'once' ) ? '月額 ' : '一回 ' ) . number_format( (int) $o['price'] ) . '円）';
}

function apprex_estimate_initial_text( $e ) {
	$yen = number_format( (int) $e['initial'] ) . '円';
	if ( ! empty( $e['setup_label'] ) ) {
		return $yen . '（' . $e['setup_label'] . '）';
	}
	if ( (int) $e['initial_regular'] > (int) $e['initial'] ) {
		return $yen . '（通常 ' . number_format( (int) $e['initial_regular'] ) . '円→1年契約で0円）';
	}
	return $yen;
}
