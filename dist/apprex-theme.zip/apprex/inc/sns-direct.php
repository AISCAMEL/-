<?php
/**
 * SNS 直接投稿（GAS不要）：Facebookページ / X(Twitter) / Instagram。
 *
 * 記事公開時に各SNSへ直接投稿する。各SNSの認証情報が設定されている場合のみ動作し、
 * 投稿失敗してもWordPressの公開処理はブロックしない（ログのみ）。
 *
 * 設定：設定 → APPREX 配信(SNS)
 * 各記事：「📣 SNS配信」ボックスで媒体ごとにON/OFF＋「今すぐ投稿」。
 *
 * ※ 外部API依存のため、設定後は各媒体で実際の投稿テストを行ってください。
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================================
 * 設定アクセサ
 * ====================================================================== */
function apprex_fb_ready() {
	return get_option( 'apprex_fb_enabled' ) && get_option( 'apprex_fb_page_id' ) && get_option( 'apprex_fb_token' );
}
function apprex_x_ready() {
	return get_option( 'apprex_x_enabled' ) && get_option( 'apprex_x_api_key' ) && get_option( 'apprex_x_api_secret' )
		&& get_option( 'apprex_x_token' ) && get_option( 'apprex_x_token_secret' );
}
function apprex_ig_ready() {
	return get_option( 'apprex_ig_enabled' ) && get_option( 'apprex_ig_user_id' ) && get_option( 'apprex_ig_token' );
}

/** 投稿テキスト（タイトル＋短縮URL、必要なら抜粋）。$max でX用に制限。 */
function apprex_sns_text( $post, $max = 0, $with_url = true, $net = '' ) {
	$title = trim( wp_strip_all_tags( get_the_title( $post ) ) );
	// 媒体ごとの専用リンク（クリックと、その後 LINE・予約まで進んだかを数える。inc/sns-track.php）。
	$url = ( '' !== $net && function_exists( 'apprex_trk_url' ) ) ? apprex_trk_url( $net, $post->ID ) : wp_get_shortlink( $post->ID );
	if ( ! $url ) {
		$url = get_permalink( $post );
	}
	$text = $title;
	if ( $with_url ) {
		$text .= "\n" . $url;
	}
	if ( $max > 0 && mb_strlen( $text ) > $max ) {
		// URL分を確保してタイトルを詰める。
		$reserve = $with_url ? ( mb_strlen( $url ) + 2 ) : 0;
		$text    = mb_substr( $title, 0, max( 1, $max - $reserve - 1 ) ) . '…' . ( $with_url ? "\n" . $url : '' );
	}
	return $text;
}

/* =========================================================================
 * Facebook ページ投稿（Graph API）
 * ====================================================================== */
function apprex_fb_post_article( $post ) {
	$page = get_option( 'apprex_fb_page_id' );
	$tok  = get_option( 'apprex_fb_token' );
	$res  = wp_remote_post(
		'https://graph.facebook.com/v23.0/' . rawurlencode( $page ) . '/feed',
		array(
			'timeout' => 20,
			'body'    => array(
				'message'      => apprex_sns_text( $post, 0, false ) . "\n" . wp_trim_words( wp_strip_all_tags( $post->post_content ), 40 ),
				'link'         => function_exists( 'apprex_trk_url' ) ? apprex_trk_url( 'fb', $post->ID ) : get_permalink( $post ),
				'access_token' => $tok,
			),
		)
	);
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$b = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( empty( $b['id'] ) ) {
		return new WP_Error( 'fb', isset( $b['error']['message'] ) ? $b['error']['message'] : 'Facebook投稿に失敗' );
	}
	return true;
}

/* =========================================================================
 * X (Twitter) 投稿（API v2 + OAuth1.0a）
 * ====================================================================== */
function apprex_x_oauth_header( $url, $params ) {
	$oauth = array(
		'oauth_consumer_key'     => get_option( 'apprex_x_api_key' ),
		'oauth_nonce'            => wp_generate_password( 32, false ),
		'oauth_signature_method' => 'HMAC-SHA1',
		'oauth_timestamp'        => (string) time(),
		'oauth_token'            => get_option( 'apprex_x_token' ),
		'oauth_version'          => '1.0',
	);
	$base_params = array_merge( $oauth, $params );
	ksort( $base_params );
	$pairs = array();
	foreach ( $base_params as $k => $v ) {
		$pairs[] = rawurlencode( $k ) . '=' . rawurlencode( $v );
	}
	$base = 'POST&' . rawurlencode( $url ) . '&' . rawurlencode( implode( '&', $pairs ) );
	$key  = rawurlencode( get_option( 'apprex_x_api_secret' ) ) . '&' . rawurlencode( get_option( 'apprex_x_token_secret' ) );
	$oauth['oauth_signature'] = base64_encode( hash_hmac( 'sha1', $base, $key, true ) );

	$header = 'OAuth ';
	$parts  = array();
	foreach ( $oauth as $k => $v ) {
		$parts[] = rawurlencode( $k ) . '="' . rawurlencode( $v ) . '"';
	}
	return $header . implode( ', ', $parts );
}

function apprex_x_post_article( $post ) {
	$url  = 'https://api.twitter.com/2/tweets';
	$text = apprex_sns_text( $post, 120, true, 'x' ); // 日本語は1文字を2と数えるため、140文字以内に。
	// /2/tweets は JSON ボディ。OAuth1.0a 署名はボディを含めない（クエリ無し）。
	$auth = apprex_x_oauth_header( $url, array() );
	$res  = wp_remote_post(
		$url,
		array(
			'timeout' => 20,
			'headers' => array(
				'Authorization' => $auth,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode( array( 'text' => $text ) ),
		)
	);
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$code = wp_remote_retrieve_response_code( $res );
	$b    = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( $code < 200 || $code >= 300 || empty( $b['data']['id'] ) ) {
		$msg = isset( $b['detail'] ) ? $b['detail'] : ( isset( $b['title'] ) ? $b['title'] : ( 'HTTP ' . $code ) );
		return new WP_Error( 'x', $msg );
	}
	return true;
}

/* =========================================================================
 * Instagram 投稿（Graph API・画像必須・2段階）
 * ====================================================================== */
function apprex_ig_post_article( $post ) {
	$igid  = get_option( 'apprex_ig_user_id' );
	$tok   = get_option( 'apprex_ig_token' );
	$image = get_the_post_thumbnail_url( $post, 'large' );
	if ( ! $image || 0 !== strpos( $image, 'https://' ) ) {
		return new WP_Error( 'ig', 'Instagramはアイキャッチ画像（https）が必須です。記事に画像を設定してください。' );
	}
	$caption = apprex_sns_text( $post, 0, true ) . "\n" . wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );

	// 1) メディアコンテナ作成
	$c = wp_remote_post(
		'https://graph.facebook.com/v23.0/' . rawurlencode( $igid ) . '/media',
		array(
			'timeout' => 25,
			'body'    => array(
				'image_url'    => $image,
				'caption'      => $caption,
				'access_token' => $tok,
			),
		)
	);
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	$cb = json_decode( wp_remote_retrieve_body( $c ), true );
	if ( empty( $cb['id'] ) ) {
		return new WP_Error( 'ig', isset( $cb['error']['message'] ) ? $cb['error']['message'] : 'IGコンテナ作成に失敗' );
	}

	// 2) 公開
	$p = wp_remote_post(
		'https://graph.facebook.com/v23.0/' . rawurlencode( $igid ) . '/media_publish',
		array(
			'timeout' => 25,
			'body'    => array(
				'creation_id'  => $cb['id'],
				'access_token' => $tok,
			),
		)
	);
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	$pb = json_decode( wp_remote_retrieve_body( $p ), true );
	if ( empty( $pb['id'] ) ) {
		return new WP_Error( 'ig', isset( $pb['error']['message'] ) ? $pb['error']['message'] : 'IG公開に失敗' );
	}
	return true;
}

/* =========================================================================
 * 公開時の自動投稿
 * ====================================================================== */
function apprex_sns_networks() {
	return array(
		'fb' => array( 'label' => 'Facebookページ', 'ready' => 'apprex_fb_ready', 'send' => 'apprex_fb_post_article' ),
		'x'  => array( 'label' => 'X（Twitter）', 'ready' => 'apprex_x_ready', 'send' => 'apprex_x_post_article' ),
		'ig' => array( 'label' => 'Instagram', 'ready' => 'apprex_ig_ready', 'send' => 'apprex_ig_post_article' ),
	);
}

/** 1記事を指定ネットワークへ投稿。 */
function apprex_sns_send( $post_id, $net ) {
	$nets = apprex_sns_networks();
	if ( ! isset( $nets[ $net ] ) || ! call_user_func( $nets[ $net ]['ready'] ) ) {
		return new WP_Error( 'sns', $net . ' は未設定です。' );
	}
	$post = get_post( $post_id );
	if ( ! $post ) {
		return new WP_Error( 'sns', '記事が見つかりません。' );
	}
	$r = call_user_func( $nets[ $net ]['send'], $post );
	if ( ! is_wp_error( $r ) ) {
		update_post_meta( $post_id, 'apprex_' . $net . '_sent', current_time( 'mysql' ) );
	}
	return $r;
}

add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'publish' !== $new || 'publish' === $old || 'post' !== $post->post_type ) {
		return;
	}
	foreach ( apprex_sns_networks() as $net => $info ) {
		if ( ! call_user_func( $info['ready'] ) ) {
			continue;
		}
		$flag = get_post_meta( $post->ID, 'apprex_dist_' . $net, true );
		$on   = ( '' === $flag ) ? true : ( '1' === $flag ); // 既定ON（設定済み媒体のみ）。
		if ( ! $on || get_post_meta( $post->ID, 'apprex_' . $net . '_sent', true ) ) {
			continue;
		}
		// Instagram：記事から画像6枚（カルーセル）とキャプションを作って投稿（時間がかかるので2分後に別で）。
		if ( 'ig' === $net && function_exists( 'apprex_ig_use_carousel' ) && apprex_ig_use_carousel() ) {
			wp_schedule_single_event( time() + 2 * MINUTE_IN_SECONDS, 'apprex_ig_auto', array( $post->ID ) );
			continue;
		}
		$r = apprex_sns_send( $post->ID, $net );
		if ( is_wp_error( $r ) ) {
			error_log( '[APPREX SNS ' . $net . '] ' . $r->get_error_message() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}
}, 11, 3 );

/* =========================================================================
 * 記事編集：SNS配信ボックス
 * ====================================================================== */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'apprex_sns_box', '📣 SNS配信', 'apprex_sns_box', 'post', 'side', 'high' );
} );

function apprex_sns_box( $post ) {
	wp_nonce_field( 'apprex_sns_box', 'apprex_sns_box_nonce' );
	$any = false;
	foreach ( apprex_sns_networks() as $net => $info ) {
		$ready = call_user_func( $info['ready'] );
		if ( ! $ready ) {
			continue;
		}
		$any  = true;
		$flag = get_post_meta( $post->ID, 'apprex_dist_' . $net, true );
		$on   = ( '' === $flag ) ? true : ( '1' === $flag );
		$sent = get_post_meta( $post->ID, 'apprex_' . $net . '_sent', true );
		echo '<p style="margin:4px 0;"><label><input type="checkbox" name="apprex_dist_' . esc_attr( $net ) . '" value="1" ' . checked( $on, true, false ) . '> ' . esc_html( $info['label'] ) . '</label>';
		echo $sent ? ' <span style="color:#15803d;font-size:11px;">✅' . esc_html( $sent ) . '</span>' : ' <span style="color:#9ca3af;font-size:11px;">未投稿</span>';
		echo '</p>';
	}
	if ( ! $any ) {
		echo '<p style="color:#b91c1c;">SNSが未設定です。<br><a href="' . esc_url( admin_url( 'options-general.php?page=apprex-sns' ) ) . '">設定はこちら</a></p>';
		return;
	}
	echo '<p class="description">公開時、チェックした媒体へ自動投稿します。</p>';
	if ( 'publish' === $post->post_status ) {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=apprex_sns_send&post=' . $post->ID ), 'apprex_sns_send_' . $post->ID );
		echo '<a class="button button-primary" style="width:100%;text-align:center;" href="' . esc_url( $url ) . '">📣 今すぐSNSに投稿</a>';
	}
}

add_action( 'save_post_post', function ( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['apprex_sns_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['apprex_sns_box_nonce'] ) ), 'apprex_sns_box' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( array_keys( apprex_sns_networks() ) as $net ) {
		update_post_meta( $post_id, 'apprex_dist_' . $net, isset( $_POST[ 'apprex_dist_' . $net ] ) ? '1' : '0' );
	}
} );

add_action( 'admin_post_apprex_sns_send', function () {
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
		wp_die( '権限がありません。' );
	}
	check_admin_referer( 'apprex_sns_send_' . $post_id );
	$done = array();
	$errs = array();
	foreach ( apprex_sns_networks() as $net => $info ) {
		if ( ! call_user_func( $info['ready'] ) || '1' !== get_post_meta( $post_id, 'apprex_dist_' . $net, true ) ) {
			continue;
		}
		$r = apprex_sns_send( $post_id, $net );
		if ( is_wp_error( $r ) ) {
			$errs[] = $info['label'] . '：' . $r->get_error_message();
		} else {
			$done[] = $info['label'];
		}
	}
	$back = get_edit_post_link( $post_id, 'url' );
	$msg  = ( $done ? '投稿成功：' . implode( '・', $done ) . '。' : '' ) . ( $errs ? ' 失敗：' . implode(' / ', $errs ) : '' );
	if ( '' === trim( $msg ) ) {
		$msg = 'チェックされた媒体がありません。';
	}
	wp_safe_redirect( add_query_arg( 'apprex_sns_msg', rawurlencode( $msg ), $back ) );
	exit;
} );

add_action( 'admin_notices', function () {
	if ( ! isset( $_GET['apprex_sns_msg'] ) ) {
		return;
	}
	echo '<div class="notice notice-info is-dismissible"><p>SNS配信：' . esc_html( rawurldecode( wp_unslash( $_GET['apprex_sns_msg'] ) ) ) . '</p></div>';
} );

/* =========================================================================
 * 設定ページ
 * ====================================================================== */
add_action( 'admin_menu', function () {
	add_options_page( 'APPREX 配信(SNS)', 'APPREX 配信(SNS)', 'manage_options', 'apprex-sns', 'apprex_sns_settings_page' );
} );
add_action( 'admin_init', function () {
	foreach ( array(
		'apprex_fb_enabled'    => 'absint',
		'apprex_fb_page_id'    => 'sanitize_text_field',
		'apprex_fb_token'      => 'sanitize_text_field',
		'apprex_x_enabled'     => 'absint',
		'apprex_x_api_key'     => 'sanitize_text_field',
		'apprex_x_api_secret'  => 'sanitize_text_field',
		'apprex_x_token'       => 'sanitize_text_field',
		'apprex_x_token_secret' => 'sanitize_text_field',
		'apprex_ig_enabled'    => 'absint',
		'apprex_ig_user_id'    => 'sanitize_text_field',
		'apprex_ig_token'      => 'sanitize_text_field',
		'apprex_ig_per_day'    => 'absint',
		'apprex_ig_carousel'   => function ( $v ) {
			return 'off' === $v ? 'off' : 'on';
		},
		'apprex_ig_pattern'    => function ( $v ) {
			return ( function_exists( 'apprex_ig_patterns' ) && isset( apprex_ig_patterns()[ $v ] ) ) || 'rotate' === $v ? $v : 'rotate_impact';
		},
		'apprex_ig_reel'       => function ( $v ) {
			return 'off' === $v ? 'off' : 'on';
		},
	) as $opt => $cb ) {
		register_setting( 'apprex_sns_dist', $opt, array( 'sanitize_callback' => $cb ) );
	}
} );

function apprex_sns_field( $opt, $ph = '' ) {
	// トークン・秘密の値は、画面では伏せ字にする（スクリーンショットに写らないように）。
	$secret = (bool) preg_match( '/token|secret|api_key/', $opt );
	echo '<input type="' . ( $secret ? 'password' : 'text' ) . '" name="' . esc_attr( $opt ) . '" class="regular-text" value="' . esc_attr( get_option( $opt, '' ) ) . '" placeholder="' . esc_attr( $ph ) . '" autocomplete="off"' . ( $secret ? ' onfocus="this.type=\'text\'" onblur="this.type=\'password\'"' : '' ) . '>';
}

function apprex_sns_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1>APPREX 配信（SNS・GAS不要）</h1>
		<p>記事公開時に各SNSへ直接投稿します。各媒体の認証情報を入れ、媒体ごとに有効化してください。設定後は実際の投稿テストを推奨します。</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'apprex_sns_dist' ); ?>

			<h2>Facebook ページ</h2>
			<table class="form-table" role="presentation"><tbody>
				<tr><th>有効化</th><td><label><input type="checkbox" name="apprex_fb_enabled" value="1" <?php checked( 1, (int) get_option( 'apprex_fb_enabled', 0 ) ); ?>> Facebookページへ投稿する</label></td></tr>
				<tr><th>ページID</th><td><?php apprex_sns_field( 'apprex_fb_page_id', '例）1234567890' ); ?></td></tr>
				<tr><th>ページアクセストークン（長期）</th><td><?php apprex_sns_field( 'apprex_fb_token' ); ?><p class="description">下の「Instagramをかんたん連携」をすると、ページIDとトークンも自動で入ります。</p></td></tr>
			</tbody></table>

			<h2>X（Twitter）</h2>
			<table class="form-table" role="presentation"><tbody>
				<tr><th>有効化</th><td><label><input type="checkbox" name="apprex_x_enabled" value="1" <?php checked( 1, (int) get_option( 'apprex_x_enabled', 0 ) ); ?>> Xへ投稿する</label><p class="description">X の API は使った分だけの支払い（前払いのクレジット）です。1投稿あたり数円〜数十円ほど（リンク付きは高め）。X の開発者ポータルでクレジットを入れ、使いすぎ防止の上限も決めておきます。</p></td></tr>
				<tr><th>API Key</th><td><?php apprex_sns_field( 'apprex_x_api_key' ); ?></td></tr>
				<tr><th>API Secret</th><td><?php apprex_sns_field( 'apprex_x_api_secret' ); ?></td></tr>
				<tr><th>Access Token</th><td><?php apprex_sns_field( 'apprex_x_token' ); ?></td></tr>
				<tr><th>Access Token Secret</th><td><?php apprex_sns_field( 'apprex_x_token_secret' ); ?><p class="description">開発者ポータルでアプリ権限を「Read and Write」にしてトークンを発行。</p></td></tr>
			</tbody></table>

			<h2>Instagram</h2>
			<table class="form-table" role="presentation"><tbody>
				<tr><th>有効化</th><td><label><input type="checkbox" name="apprex_ig_enabled" value="1" <?php checked( 1, (int) get_option( 'apprex_ig_enabled', 0 ) ); ?>> Instagramへ投稿する</label><p class="description">ビジネスアカウント＋アイキャッチ画像が必須です。</p></td></tr>
				<tr><th>IGビジネスアカウントID</th><td><?php apprex_sns_field( 'apprex_ig_user_id' ); ?></td></tr>
				<tr><th>アクセストークン</th><td><?php apprex_sns_field( 'apprex_ig_token' ); ?><p class="description">instagram_content_publish 権限付きのトークン（FBページ連携）。</p></td></tr>
				<tr><th>投稿の形</th><td>
					<select name="apprex_ig_carousel">
						<option value="on" <?php selected( 'off' !== get_option( 'apprex_ig_carousel', 'on' ) ); ?>>記事から画像6枚（カルーセル）とキャプションをAIで作って投稿（おすすめ）</option>
						<option value="off" <?php selected( 'off' === get_option( 'apprex_ig_carousel', 'on' ) ); ?>>アイキャッチ1枚とタイトルだけ（今まで）</option>
					</select>
					<?php if ( function_exists( 'apprex_ig_can_draw' ) && ! apprex_ig_can_draw() ) : ?><p class="description" style="color:#b91c1c">このサーバーでは画像に文字を入れられない（GD・FreeType がない）ため、1枚の投稿になります。</p><?php endif; ?>
				</td></tr>
				<?php if ( function_exists( 'apprex_ig_patterns' ) ) : ?>
				<tr><th>画像のデザイン</th><td>
					<select name="apprex_ig_pattern">
						<option value="rotate_impact" <?php selected( 'rotate_impact', get_option( 'apprex_ig_pattern', 'rotate_impact' ) ); ?>>記事ごとに順番に変える：インパクト系★だけ（おすすめ・4種類）</option>
						<option value="rotate" <?php selected( 'rotate', get_option( 'apprex_ig_pattern', 'rotate_impact' ) ); ?>>記事ごとに順番に変える：全部（9種類）</option>
						<?php foreach ( apprex_ig_patterns() as $k => $pt ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $k, get_option( 'apprex_ig_pattern', 'rotate_impact' ) ); ?>>いつも「<?php echo esc_html( $pt['label'] ); ?>」</option>
						<?php endforeach; ?>
					</select>
					<p class="description">記事の編集画面の「インスタグラム」欄でも、記事ごとにデザインを選んで作り直せます。</p>
				</td></tr>
				<?php endif; ?>
				<tr><th>リール動画</th><td>
					<select name="apprex_ig_reel">
						<option value="on" <?php selected( 'off' !== get_option( 'apprex_ig_reel', 'on' ) ); ?>>カルーセルと一緒に、6枚をつないだリール動画も投稿する</option>
						<option value="off" <?php selected( 'off' === get_option( 'apprex_ig_reel', 'on' ) ); ?>>投稿しない</option>
					</select>
					<p class="description"><?php echo function_exists( 'apprex_ig_ffmpeg' ) && '' !== apprex_ig_ffmpeg() ? 'このサーバーは動画を作れます（自動で投稿します）。' : 'このサーバーでは動画を自動で作れません。記事の編集画面の「インスタグラム」欄の「リール動画を作る」ボタンで、ブラウザが動画を作って投稿します。'; ?></p>
				</td></tr>
				<tr><th>1日の投稿数の上限</th><td><input type="number" min="1" max="10" name="apprex_ig_per_day" value="<?php echo esc_attr( max( 1, (int) get_option( 'apprex_ig_per_day', 2 ) ) ); ?>" class="small-text"> 件（記事の公開による自動投稿）</td></tr>
			</tbody></table>

			<?php submit_button( '保存する' ); ?>
		</form>

		<hr>
		<h2 id="ig-connect">Instagramをかんたん連携（トークンを貼るだけ）</h2>
		<?php $apprex_ign = get_transient( 'apprex_ig_connect_notice' ); delete_transient( 'apprex_ig_connect_notice' ); ?>
		<?php if ( is_array( $apprex_ign ) ) : ?><div class="notice notice-<?php echo esc_attr( $apprex_ign[0] ); ?>"><p><?php echo esc_html( $apprex_ign[1] ); ?></p></div><?php endif; ?>
		<p>グラフAPIエクスプローラの「Generate Access Token」で出たトークンを貼ると、<b>長く使えるトークンへの切り替え・ページのトークンの取得・InstagramのIDの確認・上の欄への入力</b>まで、サイトが自動で行います。</p>
		<ol>
			<li>Meta for Developers →「APPREX 自動投稿」→ 左の「アプリの設定」→「ベーシック」で、<b>アプリID</b> と <b>app secret</b>（「表示」を押す）をコピーして下に貼ります。</li>
			<li><a href="https://developers.facebook.com/tools/explorer" target="_blank" rel="noopener">グラフAPIエクスプローラ</a>で、Metaアプリ「APPREX 自動投稿」・許可（pages_show_list／instagram_basic／instagram_content_publish／instagram_manage_insights／pages_manage_posts／pages_read_engagement／business_management）を選んで「Generate Access Token」→ ページ apprex とインスタ apprex1173 を許可 → 出たトークンをコピーして下に貼ります。</li>
			<li>「連携する」を押します。</li>
		</ol>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'apprex_ig_connect' ); ?>
			<input type="hidden" name="action" value="apprex_ig_connect">
			<table class="form-table" role="presentation"><tbody>
				<tr><th>アプリID</th><td><input type="text" name="app_id" class="regular-text" value="<?php echo esc_attr( get_option( 'apprex_meta_app_id', '' ) ); ?>" autocomplete="off"></td></tr>
				<tr><th>app secret</th><td><input type="password" name="app_secret" class="regular-text" value="" placeholder="<?php echo get_option( 'apprex_meta_app_secret' ) ? '保存済み（変えるときだけ入力）' : ''; ?>" autocomplete="off"></td></tr>
				<tr><th>エクスプローラのトークン</th><td><textarea name="token" rows="3" class="large-text" autocomplete="off" placeholder="EAA..."></textarea><p class="description">1〜2時間で切れる短いトークンで大丈夫です。</p></td></tr>
			</tbody></table>
			<input type="hidden" name="ig_token_above" value="">
			<?php submit_button( '連携する', 'primary', 'submit', false, array( 'onclick' => "var t=document.querySelector('input[name=apprex_ig_token]');this.form.ig_token_above.value=t?t.value:'';" ) ); ?>
		</form>
	</div>
	<?php
}

/* かんたん連携：短いトークン → 長いユーザートークン → ページのトークン（期限なし）と InstagramのID。 */
add_action(
	'admin_post_apprex_ig_connect',
	function () {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'apprex_ig_connect' ) ) {
			wp_die( '権限がありません。' );
		}
		$app_id = isset( $_POST['app_id'] ) ? preg_replace( '/\D/', '', wp_unslash( $_POST['app_id'] ) ) : '';
		$secret = isset( $_POST['app_secret'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['app_secret'] ) ) ) : '';
		$short  = isset( $_POST['token'] ) ? preg_replace( '/\s+/', '', wp_unslash( $_POST['token'] ) ) : '';
		if ( '' !== $app_id ) {
			update_option( 'apprex_meta_app_id', $app_id, false );
		}
		if ( '' !== $secret ) {
			update_option( 'apprex_meta_app_secret', $secret, false );
		}
		$app_id = get_option( 'apprex_meta_app_id', '' );
		$secret = get_option( 'apprex_meta_app_secret', '' );
		$done   = function ( $type, $msg ) {
			set_transient( 'apprex_ig_connect_notice', array( $type, $msg ), 120 );
			wp_safe_redirect( admin_url( 'options-general.php?page=apprex-sns#ig-connect' ) );
			exit;
		};
		// 下の欄が空なら、上の「アクセストークン」欄に貼ったトークンを使う。
		if ( '' === $short ) {
			$short = isset( $_POST['ig_token_above'] ) ? preg_replace( '/\s+/', '', wp_unslash( $_POST['ig_token_above'] ) ) : '';
		}
		if ( '' === $short ) {
			$short = preg_replace( '/\s+/', '', (string) get_option( 'apprex_ig_token', '' ) );
		}
		$miss = array();
		if ( '' === $app_id ) {
			$miss[] = 'アプリID';
		}
		if ( '' === $secret ) {
			$miss[] = 'app secret';
		}
		if ( '' === $short ) {
			$miss[] = 'エクスプローラのトークン';
		}
		if ( $miss ) {
			$done( 'error', '「' . implode( '」「', $miss ) . '」が空です。入れてから「連携する」を押してください。' );
		}
		$get = function ( $path, $q ) {
			$r = wp_remote_get( 'https://graph.facebook.com/v23.0/' . $path . '?' . http_build_query( $q ), array( 'timeout' => 30 ) );
			if ( is_wp_error( $r ) ) {
				return new WP_Error( 'net', 'Metaに接続できませんでした（' . $r->get_error_message() . '）。' );
			}
			$b = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( ! is_array( $b ) || isset( $b['error'] ) ) {
				return new WP_Error( 'api', isset( $b['error']['message'] ) ? $b['error']['message'] : 'Metaからの応答が読めませんでした。' );
			}
			return $b;
		};
		// 1) 長く使えるユーザートークンに。
		$long = $get( 'oauth/access_token', array( 'grant_type' => 'fb_exchange_token', 'client_id' => $app_id, 'client_secret' => $secret, 'fb_exchange_token' => $short ) );
		if ( is_wp_error( $long ) ) {
			$done( 'error', 'トークンを切り替えられませんでした：' . $long->get_error_message() . '（アプリID・app secret が「APPREX 自動投稿」のものか、トークンが切れていないかご確認ください）' );
		}
		// 2) ページの一覧（ページのトークンと、つながっているInstagram）。
		$pages = $get( 'me/accounts', array( 'fields' => 'id,name,access_token,instagram_business_account{id,username}', 'access_token' => $long['access_token'] ) );
		if ( is_wp_error( $pages ) ) {
			$done( 'error', 'ページを読み込めませんでした：' . $pages->get_error_message() );
		}
		$hit = null;
		foreach ( isset( $pages['data'] ) ? (array) $pages['data'] : array() as $pg ) {
			if ( ! empty( $pg['instagram_business_account']['id'] ) ) {
				$hit = $pg;
				if ( false !== stripos( (string) $pg['name'], 'apprex' ) ) {
					break; // APPREX のページを優先。
				}
			}
		}
		if ( ! $hit ) {
			$done( 'error', 'Instagramとつながったページが見つかりませんでした。トークンを作るときに、ページ「apprex」とインスタ「apprex1173」を選んで許可したかご確認ください。' );
		}
		update_option( 'apprex_ig_user_id', $hit['instagram_business_account']['id'] );
		update_option( 'apprex_ig_token', $hit['access_token'] );
		update_option( 'apprex_ig_enabled', 1 );
		// 同じページのトークンで、Facebookページにも投稿できる（pages_manage_posts の許可が必要）。
		if ( ! empty( $hit['id'] ) ) {
			update_option( 'apprex_fb_page_id', (string) $hit['id'] );
			update_option( 'apprex_fb_token', $hit['access_token'] );
			update_option( 'apprex_fb_enabled', 1 );
		}
		$name = isset( $hit['instagram_business_account']['username'] ) ? '@' . $hit['instagram_business_account']['username'] : $hit['instagram_business_account']['id'];
		$done( 'success', 'Instagram（' . $name . '／ページ「' . $hit['name'] . '」）と連携しました。Facebookページ「' . $hit['name'] . '」への投稿もオンにしました。トークンは期限なしのページのトークンです。記事の編集画面の「インスタグラム」「SNS配信」欄から試せます。' );
	}
);
