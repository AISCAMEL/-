<?php
/**
 * LINE AI 自動応答。
 *
 * LINE公式アカウントに届いたテキストメッセージへ、サイトのAIチャットと同じ頭脳
 * （OpenRouter＋APPREXシステムプロンプト）で自動返信する。
 *
 * 連携：
 *  - 受信：inc/line-steps.php の Webhook が発火する 'apprex_line_event' フック。
 *  - 返信：LINE reply API（replyToken）。
 *  - 頭脳：inc/openrouter-chat.php の apprex_openrouter_complete() / apprex_chat_system_prompt()。
 *  - 送信認証：inc/line-direct.php の apprex_line_channel_token()。
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apprex_line_ai_enabled() {
	return (bool) get_option( 'apprex_line_ai_enabled', 0 );
}

/** LINE reply API（replyTokenへ返信）。 */
function apprex_line_reply( $reply_token, $messages ) {
	$token = function_exists( 'apprex_line_channel_token' ) ? apprex_line_channel_token() : '';
	if ( '' === $token || '' === $reply_token ) {
		return new WP_Error( 'line', 'トークン/replyTokenがありません。' );
	}
	$res = wp_remote_post(
		'https://api.line.me/v2/bot/message/reply',
		array(
			'timeout' => 25,
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
			'body'    => wp_json_encode(
				array(
					'replyToken' => $reply_token,
					'messages'   => array_values( $messages ),
				)
			),
		)
	);
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$code = wp_remote_retrieve_response_code( $res );
	if ( $code < 200 || $code >= 300 ) {
		$b = json_decode( wp_remote_retrieve_body( $res ), true );
		return new WP_Error( 'line', isset( $b['message'] ) ? $b['message'] : ( 'HTTP ' . $code ) );
	}
	return true;
}

/** メッセージイベントを受けてAIで返信。 */
add_action( 'apprex_line_event', function ( $ev, $uid, $type ) {
	if ( 'message' !== $type ) {
		return;
	}
	if ( ! apprex_line_ai_enabled() || ! empty( $GLOBALS['apprex_line_replied'] ) ) {
		return; // ほかの機能（説明会の案内など）がすでに返信した。
	}
	if ( empty( $ev['message']['type'] ) || 'text' !== $ev['message']['type'] ) {
		return; // テキスト以外（画像・スタンプ等）は対象外。
	}
	$reply_token = isset( $ev['replyToken'] ) ? sanitize_text_field( $ev['replyToken'] ) : '';
	$user_text   = isset( $ev['message']['text'] ) ? trim( (string) $ev['message']['text'] ) : '';
	if ( '' === $reply_token || '' === $user_text ) {
		return;
	}
	if ( ! function_exists( 'apprex_openrouter_complete' ) || ! apprex_ai_text_ready( true ) ) {
		update_option( 'apprex_line_ai_last', array( 't' => time(), 's' => 'err', 'n' => 'AIのAPIキーが未設定（APPREX チャット）' ), false );
		return;
	}

	// サイトのAIと同じ頭脳＋LINE向けの簡潔指示。
	$system = function_exists( 'apprex_chat_system_prompt' ) ? apprex_chat_system_prompt() : 'あなたはAPPREXのアシスタントです。';
	$line_rule = "# LINE応答ルール\n- 公式LINEでの会話です（相手はすでに友だち）。「友だち追加してください」とは言わない。1〜3文で簡潔に、絵文字は控えめに。\n"
		. "- アプリに興味がある人には、トーク画面下のメニューの「AIでお店のアプリ画面を作る（APPREX LABO）」を勧める（無料・業種と店名を入れるだけ）。\n"
		. "- 相談・見積もりの希望には、メニューの「無料相談」から日時を選んで予約できると伝える（予約の確認とお知らせはこのLINEに届く）。\n"
		. "- 代理店に興味がある人には、メニューの「代理店説明会」から予約できると伝える。金額は答えない。\n"
		. "- URLを送るときは、システムの指示の「主なページ」のURLだけを使う。\n"
		. "- 分からないことは無理に答えず、担当者から返信する旨を伝える（担当者の対応は平日10:00〜18:00）。";

	// 毎回同じ指示と、LINE向けの指示を分けて渡す（Claude の使い回しのため）。
	$messages = array(
		array( 'role' => 'system', 'content' => $system ),
		array( 'role' => 'system', 'content' => $line_rule ),
		array( 'role' => 'user', 'content' => mb_substr( $user_text, 0, 2000 ) ),
	);
	$reply = apprex_openrouter_complete( $messages, array( 'temperature' => 0.4, 'max_tokens' => 500, 'timeout' => 25, 'chat' => true ) );
	// 設定モデルが利用不可（404等）の場合、安全な既定モデルで自動再試行（サイトのAIチャットと同じ挙動）。
	if ( is_wp_error( $reply ) && function_exists( 'apprex_openrouter_model' ) && apprex_openrouter_model() !== APPREX_OPENROUTER_DEFAULT_MODEL ) {
		$reply = apprex_openrouter_complete( $messages, array( 'model' => APPREX_OPENROUTER_DEFAULT_MODEL, 'temperature' => 0.4, 'max_tokens' => 500, 'timeout' => 25, 'chat' => true ) );
	}
	if ( is_wp_error( $reply ) || '' === trim( (string) $reply ) ) {
		$note = is_wp_error( $reply ) ? $reply->get_error_message() : 'AIの返答が空でした';
		update_option( 'apprex_line_ai_last', array( 't' => time(), 's' => 'err', 'n' => 'AI生成エラー：' . $note ), false );
		error_log( '[APPREX LINE AI] ' . $note ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		return;
	}
	$sent = apprex_line_reply( $reply_token, array( array( 'type' => 'text', 'text' => mb_substr( (string) $reply, 0, 4900 ) ) ) );
	if ( is_wp_error( $sent ) ) {
		update_option( 'apprex_line_ai_last', array( 't' => time(), 's' => 'err', 'n' => 'LINE返信エラー：' . $sent->get_error_message() ), false );
	} else {
		update_option( 'apprex_line_ai_last', array( 't' => time(), 's' => 'ok', 'n' => mb_substr( $user_text, 0, 30 ) ), false );
	}
}, 10, 3 );

/** 設定（APPREX 配信(LINE) ページのグループに相乗り）。 */
add_action( 'admin_init', function () {
	register_setting( 'apprex_line_dist', 'apprex_line_ai_enabled', array( 'sanitize_callback' => 'absint' ) );
} );

/** AI単体テスト：LINEを介さずOpenRouterだけを直接叩いて結果を表示。 */
add_action( 'admin_post_apprex_line_ai_test', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( '権限がありません。' );
	}
	check_admin_referer( 'apprex_line_ai_test' );
	$back = admin_url( 'options-general.php?page=apprex-line' );

	if ( ! function_exists( 'apprex_openrouter_complete' ) || ! apprex_ai_text_ready( true ) ) {
		wp_safe_redirect( add_query_arg( 'apprex_ai_test', rawurlencode( 'AIのAPIキーが未設定です（APPREX チャット）' ), $back ) );
		exit;
	}
	$msgs = array(
		array( 'role' => 'system', 'content' => 'あなたはテスト用アシスタントです。1文で短く挨拶してください。' ),
		array( 'role' => 'user', 'content' => 'こんにちは' ),
	);
	$model = function_exists( 'apprex_ai_text_label' ) ? apprex_ai_text_label() : apprex_openrouter_model();
	$r = apprex_openrouter_complete( $msgs, array( 'max_tokens' => 60, 'timeout' => 25, 'chat' => true ) );
	if ( is_wp_error( $r ) && $model !== APPREX_OPENROUTER_DEFAULT_MODEL ) {
		$r = apprex_openrouter_complete( $msgs, array( 'model' => APPREX_OPENROUTER_DEFAULT_MODEL, 'max_tokens' => 60, 'timeout' => 25, 'chat' => true ) );
		if ( ! is_wp_error( $r ) ) {
			$model = APPREX_OPENROUTER_DEFAULT_MODEL . '（フォールバック）';
		}
	}
	if ( is_wp_error( $r ) ) {
		$msg = 'NG（モデル：' . $model . '）：' . $r->get_error_message();
	} else {
		$msg = 'OK（モデル：' . $model . '）：' . mb_substr( (string) $r, 0, 80 );
	}
	wp_safe_redirect( add_query_arg( 'apprex_ai_test', rawurlencode( $msg ), $back ) );
	exit;
} );
