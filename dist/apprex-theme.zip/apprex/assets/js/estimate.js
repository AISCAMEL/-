/**
 * APPREX 見積もり → 発注 calculator（APPREX仕様）。
 * 初期費用は作り方で選ぶ（ノーコード15万円／カスタマイズ・フルスクラッチは個別見積へ）。
 * 月額は通常価格を取り消し線で表示、オプションは一回費用として加算。
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var root = document.getElementById('apprex-estimate');
		if (!root || !window.APPREX_PRICING) { return; }
		var cfg = APPREX_PRICING.config;
		var rest = APPREX_PRICING.rest || {};
		var services = cfg.services;
		var toZero = !!(cfg.campaign && cfg.campaign.initial_to_zero);
		var quotePlans = APPREX_PRICING.quotePlans || {};
		var meetingUrl = APPREX_PRICING.meetingUrl || '';
		var contactUrl = APPREX_PRICING.contactUrl || '';

		var elServices = document.getElementById('est-services');
		var elPlans = document.getElementById('est-plans');
		var elOptions = document.getElementById('est-options');
		var elSetup = document.getElementById('est-setup');
		var elTotal = document.getElementById('est-total');
		var orderForm = document.getElementById('est-order');
		var doneBox = document.getElementById('est-done');

		// 初期費用はノーコード（ai）で計算。カスタマイズ・フルスクラッチは個別見積へ切り替える。
		var state = { service: null, plan: null, options: [], quote: null, setup: 'ai', qty: {} };
		function yen(n) { return '¥' + Number(n).toLocaleString('ja-JP'); }
		function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

		function chip(label, active, sub) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'est-chip' + (active ? ' is-active' : '');
			b.innerHTML = '<span class="est-chip__label">' + label + '</span>' + (sub ? '<span class="est-chip__sub">' + sub + '</span>' : '');
			return b;
		}

		function renderServices() {
			elServices.innerHTML = '';
			Object.keys(services).forEach(function (key) {
				var svc = services[key];
				var b = chip(svc.label, state.service === key && !state.quote, (svc.setup ? '月額制・初期費用15万円（ノーコード）' : '月額制・初期費用0円（1年契約）'));
				b.addEventListener('click', function () {
					state.service = key; state.plan = null; state.options = []; state.quote = null; state.qty = {};
					renderServices(); renderPlans(); renderSetup(); renderOptions(); renderTotal();
				});
				elServices.appendChild(b);
			});
			// 要相談メニュー（オリジナルアプリ開発など）→ 価格は出さず、ミーティングへ誘導。
			Object.keys(quotePlans).forEach(function (qkey) {
				var q = quotePlans[qkey];
				var b = chip(q.label, state.quote === qkey, '個別お見積り（要相談）');
				b.classList.add('est-chip--quote');
				b.addEventListener('click', function () {
					state.quote = qkey; state.service = null; state.plan = null; state.options = [];
					renderServices(); renderPlans(); renderSetup(); renderOptions(); renderTotal();
				});
				elServices.appendChild(b);
			});
		}

		function renderPlans() {
			elPlans.innerHTML = '';
			if (state.quote) { elPlans.innerHTML = '<p class="estimate__hint">この内容は個別お見積り（要相談）です。右側の「ミーティングで相談」へお進みください。</p>'; return; }
			if (!state.service) { elPlans.innerHTML = '<p class="estimate__hint">先にサービスを選択してください。</p>'; return; }
			var plans = services[state.service].plans;
			Object.keys(plans).forEach(function (key) {
				var p = plans[key];
				var b = chip(p.label, state.plan === key, '月額 ' + Number(p.monthly).toLocaleString('ja-JP') + '円〜');
				b.addEventListener('click', function () { state.plan = key; renderPlans(); renderTotal(); });
				elPlans.appendChild(b);
			});
		}

		function renderSetup() {
			if (!elSetup) { return; }
			elSetup.innerHTML = '';
			if (state.quote || !state.service) { elSetup.innerHTML = '<p class="estimate__hint">—</p>'; return; }
			var setups = services[state.service].setup;
			if (!setups) { elSetup.innerHTML = '<p class="estimate__hint">初期費用は0円です（1年契約）。</p>'; return; }
			Object.keys(setups).forEach(function (key) {
				var st = setups[key];
				var b = chip(st.label + '　' + (st.quote ? (st.price_label || 'お見積もり') : (st.price ? Number(st.price).toLocaleString('ja-JP') + '円' : '0円')), state.setup === key, st.desc || '');
				if (st.quote) { b.classList.add('est-chip--quote'); }
				b.addEventListener('click', function () {
					if (st.quote && quotePlans[st.quote]) {
						state.quote = st.quote; state.service = null; state.plan = null; state.options = [];
						renderServices(); renderPlans(); renderSetup(); renderOptions(); renderTotal();
						return;
					}
					state.setup = key; renderSetup(); renderTotal();
				});
				elSetup.appendChild(b);
			});
		}

		function renderOptions() {
			elOptions.innerHTML = '';
			if (state.quote) { elOptions.innerHTML = '<p class="estimate__hint">—</p>'; return; }
			if (!state.service) { elOptions.innerHTML = '<p class="estimate__hint">—</p>'; return; }
			var opts = services[state.service].options || {};
			var keys = Object.keys(opts);
			if (!keys.length) { elOptions.innerHTML = '<p class="estimate__hint">追加オプションはありません。</p>'; return; }
			var groups = {}, order = [];
			keys.forEach(function (k) { var g = opts[k].group || 'オプション'; if (!groups[g]) { groups[g] = []; order.push(g); } groups[g].push(k); });
			order.forEach(function (g) {
				var box = document.createElement('div');
				box.className = 'est-optgroup';
				box.innerHTML = '<h4>' + esc(g) + '</h4>';
				groups[g].forEach(function (key) {
					var o = opts[key];
					var on = state.options.indexOf(key) >= 0;
					var price = o.quote ? 'お見積り' : ('+' + Number(o.price).toLocaleString('ja-JP') + '円' + (o.billing === 'monthly' ? '／月' : (o.unit ? '／1' + o.unit : '（一回）')));
					var wrap = document.createElement('label');
					wrap.className = 'est-opt' + (o.quote ? ' est-opt--quote' : '') + (on ? ' is-on' : '');
					var qty = '';
					if (o.qty) {
						qty = '<select class="est-qty" aria-label="' + esc(o.label) + 'の数">';
						for (var n = 1; n <= o.qty; n++) { qty += '<option value="' + n + '"' + ((state.qty[key] || 1) === n ? ' selected' : '') + '>' + n + (o.unit || '') + '</option>'; }
						qty += '</select>';
					}
					wrap.innerHTML = '<input type="checkbox" value="' + key + '"' + (on ? ' checked' : '') + '><span class="est-opt-t"><span class="est-opt-l">' + esc(o.label) + '</span>' + (o.desc ? '<small>' + esc(o.desc) + '</small>' : '') + '</span>' + qty + '<b>' + price + '</b>';
					wrap.querySelector('input').addEventListener('change', function (e) {
						if (e.target.checked) {
							if (o.exclusive) { state.options = state.options.filter(function (k) { return !(opts[k] && opts[k].exclusive === o.exclusive); }); }
							state.options.push(key);
						} else { state.options = state.options.filter(function (k) { return k !== key; }); }
						renderOptions(); renderTotal();
					});
					var sel = wrap.querySelector('select');
					if (sel) {
						sel.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); });
						sel.addEventListener('change', function (e) { state.qty[key] = +e.target.value; if (state.options.indexOf(key) < 0) { state.options.push(key); } renderOptions(); renderTotal(); });
					}
					box.appendChild(wrap);
				});
				elOptions.appendChild(box);
			});
		}

		function compute() {
			if (!state.service || !state.plan) { return null; }
			var svc = services[state.service];
			var p = svc.plans[state.plan];
			var optTotal = 0, optMonthly = 0, optLines = [];
			state.options.forEach(function (k) {
				var o = svc.options && svc.options[k];
				if (!o) { return; }
				var q = o.qty ? Math.max(1, Math.min(o.qty, state.qty[k] || 1)) : 1;
				var price = (o.price || 0) * q;
				if (!o.quote) { if (o.billing === 'monthly') { optMonthly += price; } else { optTotal += price; } }
				optLines.push({ label: o.label + (q > 1 ? '（' + q + (o.unit || '') + '）' : ''), price: price, billing: o.billing || 'once', quote: !!o.quote });
			});
			var initialRegular = p.initial || 0;
			var st = svc.setup && svc.setup[state.setup] ? svc.setup[state.setup] : null;
			var initial = st ? st.price : (toZero ? 0 : initialRegular);
			return {
				setupKey: st ? state.setup : '', setupLabel: st ? st.label : '',
				svcLabel: svc.label, planLabel: p.label,
				monthly: p.monthly, monthlyRegular: p.monthly_regular || p.monthly,
				initialRegular: initialRegular, initial: initial,
				optLines: optLines, optTotal: optTotal, optMonthly: optMonthly,
				registration: svc.registration_fee || 0, registrationLabel: svc.registration_label || 'アプリ登録費',
				initialTotal: initial + optTotal + (svc.registration_fee || 0),
				annual: (p.monthly + optMonthly) * 12 + initial + optTotal + (svc.registration_fee || 0)
			};
		}

		function renderTotal() {
			// 要相談メニュー（オリジナルアプリ開発など）：価格は出さずミーティング予約へ誘導。
			if (state.quote) {
				var q = quotePlans[state.quote] || {};
				var h = '<div class="estimate__quote">';
				h += '<h4>' + esc(q.label || 'オリジナルアプリ開発') + '</h4>';
				if (q.lead) { h += '<p>' + esc(q.lead) + '</p>'; }
				if (q.rows) {
					h += '<ul class="estimate__sub">';
					Object.keys(q.rows).forEach(function (k) { h += '<li>' + esc(k) + '：<b>' + esc(q.rows[k]) + '</b></li>'; });
					h += '</ul>';
				}
				h += '<p class="estimate__hint">内容により料金が異なるため、まずは無料のオンライン相談で要件をお聞かせください。</p>';
				if (meetingUrl) { h += '<a class="btn btn--primary btn--block" href="' + meetingUrl + '">📅 ミーティングで相談（無料）</a>'; }
				if (contactUrl) { h += '<a class="btn btn--ghost btn--block" href="' + contactUrl + '" style="margin-top:8px">メールで相談する</a>'; }
				h += '</div>';
				elTotal.innerHTML = h;
				orderForm.hidden = true;
				doneBox.hidden = true;
				return;
			}
			var e = compute();
			if (!e) { elTotal.innerHTML = '<p class="estimate__hint">サービスとプランを選択してください。</p>'; orderForm.hidden = true; return; }
			var html = '<ul class="estimate__lines">';
			html += '<li><span>' + e.svcLabel + ' / ' + e.planLabel + '</span><b>' + yen(e.monthly) + '/月</b></li>';
			e.optLines.forEach(function (o) { html += '<li class="is-opt"><span>+ ' + esc(o.label) + '</span><b>' + (o.quote ? 'お見積り' : yen(o.price) + (o.billing === 'monthly' ? '/月' : '（一回）')) + '</b></li>'; });
			html += '</ul>';
			html += '<div class="estimate__big">' + yen(e.monthly + e.optMonthly) + '<small> / 月（税抜）</small></div>';
			if (e.optMonthly) { html += '<p class="estimate__hint">アプリ ' + yen(e.monthly) + '＋毎月のオプション ' + yen(e.optMonthly) + '</p>'; }
			html += '<ul class="estimate__sub">';
			if (e.monthlyRegular > e.monthly) { html += '<li>月額：<s>' + yen(e.monthlyRegular) + '</s> → <b>' + yen(e.monthly) + '</b> <em>キャンペーン</em></li>'; }
			if (e.setupKey) { html += '<li>初期費用：<b>' + yen(e.initial) + '</b>（' + esc(e.setupLabel) + '）</li>'; }
			else { html += '<li>初期費用：' + yen(e.initial) + '</li>'; }
			if (e.registration) { html += '<li>' + esc(e.registrationLabel) + '：' + yen(e.registration) + '（一律）</li>'; }
			if (e.optTotal) { html += '<li>一回オプション：' + yen(e.optTotal) + '</li>'; }
			html += '<li>初期お支払い目安：<b>' + yen(e.initialTotal) + '</b></li>';
			html += '<li>初年度概算：' + yen(e.annual) + '</li>';
			html += '<li style="color:var(--color-muted)">最低利用期間：1年契約（12ヶ月）</li>';
			html += '</ul>';
			elTotal.innerHTML = html;
			orderForm.hidden = false;
		}

		orderForm.addEventListener('submit', function (ev) {
			ev.preventDefault();
			if (!compute()) { return; }
			var btn = orderForm.querySelector('button[type="submit"]');
			btn.disabled = true; btn.textContent = '送信中…';
			var fd = new FormData(orderForm);
			var payload = {
				service: state.service, plan: state.plan, options: state.options, setup: state.setup, qty: state.qty,
				name: fd.get('name'), company: fd.get('company'), email: fd.get('email'),
				message: fd.get('message'), source_url: location.href
			};
			fetch(rest.root + 'order', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': rest.nonce },
				body: JSON.stringify(payload)
			})
				.then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
				.then(function (res) {
					if (res.ok && res.body && res.body.ok) {
						orderForm.hidden = true; doneBox.hidden = false;
						doneBox.innerHTML = '<div class="estimate__success"><h4>✅ お申し込みを受け付けました</h4><p>' + (res.body.message || '') + '</p>' + (res.body.summary || '') + '</div>';
						doneBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
					} else {
						alert((res.body && res.body.message) ? res.body.message : '送信に失敗しました。');
						btn.disabled = false; btn.textContent = 'この内容で発注する';
					}
				})
				.catch(function () { alert('通信エラーが発生しました。'); btn.disabled = false; btn.textContent = 'この内容で発注する'; });
		});

		renderServices(); renderPlans(); renderSetup(); renderOptions(); renderTotal();
	});
})();
