/**
 * APPREX 見積もり → 発注 calculator（APPREX仕様）。
 * 初期設定費は1年契約で0円、月額は通常価格を取り消し線で表示、
 * オプションは一回費用として加算。
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var root = document.getElementById('apprex-estimate');
		if (!root || !window.APPREX_PRICING) { return; }
		var cfg = APPREX_PRICING.config;
		var rest = APPREX_PRICING.rest || {};
		var services = cfg.services;
		var toZero = !!(cfg.campaign && cfg.campaign.initial_to_zero);
		var quotePlans = APPREX_PRICING.quotePlans || {};
		var meetingUrl = APPREX_PRICING.meetingUrl || '';
		var contactUrl = APPREX_PRICING.contactUrl || '';

		var elServices = document.getElementById('est-services');
		var elPlans = document.getElementById('est-plans');
		var elOptions = document.getElementById('est-options');
		var elTotal = document.getElementById('est-total');
		var orderForm = document.getElementById('est-order');
		var doneBox = document.getElementById('est-done');

		var state = { service: null, plan: null, options: [], quote: null };
		function yen(n) { return '¥' + Number(n).toLocaleString('ja-JP'); }
		function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

		function chip(label, active, sub) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'est-chip' + (active ? ' is-active' : '');
			b.innerHTML = '<span class="est-chip__label">' + label + '</span>' + (sub ? '<span class="est-chip__sub">' + sub + '</span>' : '');
			return b;
		}

		function renderServices() {
			elServices.innerHTML = '';
			Object.keys(services).forEach(function (key) {
				var svc = services[key];
				var b = chip(svc.label, state.service === key && !state.quote, '月額制・初期設定費0円（1年契約）');
				b.addEventListener('click', function () {
					state.service = key; state.plan = null; state.options = []; state.quote = null;
					renderServices(); renderPlans(); renderOptions(); renderTotal();
				});
				elServices.appendChild(b);
			});
			// 要相談メニュー（オリジナルアプリ開発など）→ 価格は出さず、ミーティングへ誘導。
			Object.keys(quotePlans).forEach(function (qkey) {
				var q = quotePlans[qkey];
				var b = chip(q.label, state.quote === qkey, '個別お見積り（要相談）');
				b.classList.add('est-chip--quote');
				b.addEventListener('click', function () {
					state.quote = qkey; state.service = null; state.plan = null; state.options = [];
					renderServices(); renderPlans(); renderOptions(); renderTotal();
				});
				elServices.appendChild(b);
			});
		}

		function renderPlans() {
			elPlans.innerHTML = '';
			if (state.quote) { elPlans.innerHTML = '<p class="estimate__hint">この内容は個別お見積り（要相談）です。右側の「ミーティングで相談」へお進みください。</p>'; return; }
			if (!state.service) { elPlans.innerHTML = '<p class="estimate__hint">先にサービスを選択してください。</p>'; return; }
			var plans = services[state.service].plans;
			Object.keys(plans).forEach(function (key) {
				var p = plans[key];
				var b = chip(p.label, state.plan === key, '月額 ' + Number(p.monthly).toLocaleString('ja-JP') + '円〜');
				b.addEventListener('click', function () { state.plan = key; renderPlans(); renderTotal(); });
				elPlans.appendChild(b);
			});
		}

		function renderOptions() {
			elOptions.innerHTML = '';
			if (state.quote) { elOptions.innerHTML = '<p class="estimate__hint">—</p>'; return; }
			if (!state.service) { elOptions.innerHTML = '<p class="estimate__hint">—</p>'; return; }
			var opts = services[state.service].options || {};
			var keys = Object.keys(opts);
			if (!keys.length) { elOptions.innerHTML = '<p class="estimate__hint">追加オプションはありません。</p>'; return; }
			keys.forEach(function (key) {
				var o = opts[key];
				var wrap = document.createElement('label');
				wrap.className = 'est-opt';
				wrap.innerHTML = '<input type="checkbox" value="' + key + '"><span>' + o.label + '</span><b>+' + Number(o.price).toLocaleString('ja-JP') + '円（一回）</b>';
				wrap.querySelector('input').addEventListener('change', function (e) {
					if (e.target.checked) {
						// 制作代行は「AIスタジオから」と「1から」のどちらか一方。
						if (o.excludes) {
							state.options = state.options.filter(function (k) { return k !== o.excludes; });
							var other = elOptions.querySelector('input[value="' + o.excludes + '"]');
							if (other) { other.checked = false; }
						}
						state.options.push(key);
					}
					else { state.options = state.options.filter(function (k) { return k !== key; }); }
					renderTotal();
				});
				elOptions.appendChild(wrap);
			});
		}

		function compute() {
			if (!state.service || !state.plan) { return null; }
			var svc = services[state.service];
			var p = svc.plans[state.plan];
			var optTotal = 0, optLines = [];
			state.options.forEach(function (k) {
				if (svc.options && svc.options[k]) { optTotal += svc.options[k].price; optLines.push(svc.options[k]); }
			});
			var initialRegular = p.initial || 0;
			var initial = toZero ? 0 : initialRegular;
			return {
				svcLabel: svc.label, planLabel: p.label,
				monthly: p.monthly, monthlyRegular: p.monthly_regular || p.monthly,
				initialRegular: initialRegular, initial: initial,
				optLines: optLines, optTotal: optTotal,
				initialTotal: initial + optTotal,
				annual: p.monthly * 12 + initial + optTotal
			};
		}

		function renderTotal() {
			// 要相談メニュー（オリジナルアプリ開発など）：価格は出さずミーティング予約へ誘導。
			if (state.quote) {
				var q = quotePlans[state.quote] || {};
				var h = '<div class="estimate__quote">';
				h += '<h4>' + esc(q.label || 'オリジナルアプリ開発') + '</h4>';
				if (q.lead) { h += '<p>' + esc(q.lead) + '</p>'; }
				if (q.rows) {
					h += '<ul class="estimate__sub">';
					Object.keys(q.rows).forEach(function (k) { h += '<li>' + esc(k) + '：<b>' + esc(q.rows[k]) + '</b></li>'; });
					h += '</ul>';
				}
				h += '<p class="estimate__hint">内容により料金が異なるため、まずは無料のオンライン相談で要件をお聞かせください。</p>';
				if (meetingUrl) { h += '<a class="btn btn--primary btn--block" href="' + meetingUrl + '">📅 ミーティングで相談（無料）</a>'; }
				if (contactUrl) { h += '<a class="btn btn--ghost btn--block" href="' + contactUrl + '" style="margin-top:8px">メールで相談する</a>'; }
				h += '</div>';
				elTotal.innerHTML = h;
				orderForm.hidden = true;
				doneBox.hidden = true;
				return;
			}
			var e = compute();
			if (!e) { elTotal.innerHTML = '<p class="estimate__hint">サービスとプランを選択してください。</p>'; orderForm.hidden = true; return; }
			var html = '<ul class="estimate__lines">';
			html += '<li><span>' + e.svcLabel + ' / ' + e.planLabel + '</span><b>' + yen(e.monthly) + '/月</b></li>';
			e.optLines.forEach(function (o) { html += '<li class="is-opt"><span>+ ' + o.label + '（一回）</span><b>' + yen(o.price) + '</b></li>'; });
			html += '</ul>';
			html += '<div class="estimate__big">' + yen(e.monthly) + '<small> / 月（税抜）</small></div>';
			html += '<ul class="estimate__sub">';
			if (e.monthlyRegular > e.monthly) { html += '<li>月額：<s>' + yen(e.monthlyRegular) + '</s> → <b>' + yen(e.monthly) + '</b> <em>キャンペーン</em></li>'; }
			if (e.initialRegular > e.initial) { html += '<li>初期設定費：<s>' + yen(e.initialRegular) + '</s> → <b>' + yen(e.initial) + '</b> <em>1年契約で0円</em></li>'; }
			else { html += '<li>初期設定費：' + yen(e.initial) + '</li>'; }
			if (e.optTotal) { html += '<li>一回オプション：' + yen(e.optTotal) + '</li>'; }
			html += '<li>初期お支払い目安：<b>' + yen(e.initialTotal) + '</b></li>';
			html += '<li>初年度概算：' + yen(e.annual) + '</li>';
			html += '<li style="color:var(--color-muted)">最低利用期間：1年契約（12ヶ月）</li>';
			html += '</ul>';
			elTotal.innerHTML = html;
			orderForm.hidden = false;
		}

		orderForm.addEventListener('submit', function (ev) {
			ev.preventDefault();
			if (!compute()) { return; }
			var btn = orderForm.querySelector('button[type="submit"]');
			btn.disabled = true; btn.textContent = '送信中…';
			var fd = new FormData(orderForm);
			var payload = {
				service: state.service, plan: state.plan, options: state.options,
				name: fd.get('name'), company: fd.get('company'), email: fd.get('email'),
				message: fd.get('message'), source_url: location.href
			};
			fetch(rest.root + 'order', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': rest.nonce },
				body: JSON.stringify(payload)
			})
				.then(function (r) { return r.json().then(function (b) { return { ok: r.ok, body: b }; }); })
				.then(function (res) {
					if (res.ok && res.body && res.body.ok) {
						orderForm.hidden = true; doneBox.hidden = false;
						doneBox.innerHTML = '<div class="estimate__success"><h4>✅ お申し込みを受け付けました</h4><p>' + (res.body.message || '') + '</p>' + (res.body.summary || '') + '</div>';
						doneBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
					} else {
						alert((res.body && res.body.message) ? res.body.message : '送信に失敗しました。');
						btn.disabled = false; btn.textContent = 'この内容で発注する';
					}
				})
				.catch(function () { alert('通信エラーが発生しました。'); btn.disabled = false; btn.textContent = 'この内容で発注する'; });
		});

		renderServices(); renderPlans(); renderOptions(); renderTotal();
	});
})();
