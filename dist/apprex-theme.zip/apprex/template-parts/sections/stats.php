<?php
/**
 * 02. Stats — counter animation, spec §6.
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$apprex_stats = array(
	array(
		'value'  => '0',
		'suffix' => __( '円', 'apprex' ),
		'label'  => __( 'AIスタジオ（デザイン・仕様書）', 'apprex' ),
	),
	array(
		'value'  => '1/10',
		'suffix' => '',
		'label'  => __( '従来の開発コスト', 'apprex' ),
	),
	array(
		'value'  => '2',
		'suffix' => __( '週間', 'apprex' ),
		'label'  => __( '最短公開', 'apprex' ),
	),
	array(
		'value'  => '19,800',
		'suffix' => __( '円〜', 'apprex' ),
		'label'  => __( '月額（業界最安水準）', 'apprex' ),
	),
);
?>
<section class="section section--soft" id="stats">
	<div class="container">
		<div class="stats">
			<?php foreach ( $apprex_stats as $stat ) : ?>
				<div class="stat is-reveal">
					<div class="stat__num" data-counter="<?php echo esc_attr( $stat['value'] ); ?>">
						<?php echo esc_html( $stat['value'] ); ?><small><?php echo esc_html( $stat['suffix'] ); ?></small>
					</div>
					<div class="stat__label"><?php echo esc_html( $stat['label'] ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
