<?php
/**
 * APPREX theme bootstrap.
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'APPREX_VERSION', '1.127.2' );
define( 'APPREX_DIR', get_template_directory() );
define( 'APPREX_URI', get_template_directory_uri() );

/**
 * Theme setup: supports, menus, image sizes.
 */
function apprex_setup() {
	load_theme_textdomain( 'apprex', APPREX_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 48,
			'width'       => 180,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	// 16:10 card thumbnail used across cases grid.
	add_image_size( 'apprex-card', 720, 450, true );

	register_nav_menus(
		array(
			'primary' => __( 'グローバルナビ', 'apprex' ),
			'footer'  => __( 'フッターメニュー', 'apprex' ),
		)
	);
}
add_action( 'after_setup_theme', 'apprex_setup' );

require_once APPREX_DIR . '/inc/enqueue.php';
require_once APPREX_DIR . '/inc/cpt-cases.php';
require_once APPREX_DIR . '/inc/acf-fields.php';
require_once APPREX_DIR . '/inc/template-helpers.php';
require_once APPREX_DIR . '/inc/campaign.php';
require_once APPREX_DIR . '/inc/pricing-config.php';
require_once APPREX_DIR . '/inc/openrouter-chat.php';
require_once APPREX_DIR . '/inc/claude-api.php';
require_once APPREX_DIR . '/inc/chat-enhance.php';
require_once APPREX_DIR . '/inc/chat-operator.php';
require_once APPREX_DIR . '/inc/integrations.php';
require_once APPREX_DIR . '/inc/orders.php';
require_once APPREX_DIR . '/inc/contracts.php';
require_once APPREX_DIR . '/inc/contract-doc.php';
require_once APPREX_DIR . '/inc/contracts-lifecycle.php';
require_once APPREX_DIR . '/inc/square-billing.php';
require_once APPREX_DIR . '/inc/member-portal.php';
require_once APPREX_DIR . '/inc/mypage-app.php';
require_once APPREX_DIR . '/inc/dashboard.php';
require_once APPREX_DIR . '/inc/email.php';
require_once APPREX_DIR . '/inc/forms.php';
require_once APPREX_DIR . '/inc/agency.php';
require_once APPREX_DIR . '/inc/agency-system.php';
require_once APPREX_DIR . '/inc/seminar.php';
require_once APPREX_DIR . '/inc/meeting-booking.php';
require_once APPREX_DIR . '/inc/richmenu.php';
require_once APPREX_DIR . '/inc/labo.php';
require_once APPREX_DIR . '/inc/labo-starter.php';
require_once APPREX_DIR . '/inc/aimeo.php';
require_once APPREX_DIR . '/inc/hp-ai.php';
require_once APPREX_DIR . '/inc/lp-slides.php';
require_once APPREX_DIR . '/inc/migrate.php';
require_once APPREX_DIR . '/inc/crm-notes.php';
require_once APPREX_DIR . '/inc/drive-sync.php';
require_once APPREX_DIR . '/inc/smtp.php';
require_once APPREX_DIR . '/inc/line-direct.php';
require_once APPREX_DIR . '/inc/line-steps.php';
require_once APPREX_DIR . '/inc/line-ai.php';
require_once APPREX_DIR . '/inc/line-member.php';
require_once APPREX_DIR . '/inc/billing-notice.php';
require_once APPREX_DIR . '/inc/admin-nav.php';
require_once APPREX_DIR . '/inc/rewrite-guard.php';
require_once APPREX_DIR . '/inc/notify-hub.php';
require_once APPREX_DIR . '/inc/lineworks-bot.php';
require_once APPREX_DIR . '/inc/sns-track.php';
require_once APPREX_DIR . '/inc/jp-linebreak.php';
require_once APPREX_DIR . '/inc/project-status.php';
require_once APPREX_DIR . '/inc/biz-leads.php';
require_once APPREX_DIR . '/inc/biz-mail.php';
require_once APPREX_DIR . '/inc/biz-queue.php';
require_once APPREX_DIR . '/inc/ai-news.php';
require_once APPREX_DIR . '/inc/redirects.php';
require_once APPREX_DIR . '/inc/meeting-join.php';
require_once APPREX_DIR . '/inc/rest-nonce.php';
require_once APPREX_DIR . '/inc/hp-plan.php';
require_once APPREX_DIR . '/inc/hp-proposal.php';
require_once APPREX_DIR . '/inc/gcal.php';
require_once APPREX_DIR . '/inc/cron-health.php';
require_once APPREX_DIR . '/inc/mf-invoice.php';
require_once APPREX_DIR . '/inc/invoice-pdf.php';
require_once APPREX_DIR . '/inc/liff.php';
require_once APPREX_DIR . '/inc/sns-direct.php';
require_once APPREX_DIR . '/inc/ai-blog.php';
require_once APPREX_DIR . '/inc/ai-brush.php';
require_once APPREX_DIR . '/inc/ig-studio.php';
require_once APPREX_DIR . '/inc/blog.php';
require_once APPREX_DIR . '/inc/line-banner.php';
require_once APPREX_DIR . '/inc/seo.php';
require_once APPREX_DIR . '/inc/ads.php';
require_once APPREX_DIR . '/inc/sns-ads.php';
require_once APPREX_DIR . '/inc/lp.php';
require_once APPREX_DIR . '/inc/pipeline.php';
require_once APPREX_DIR . '/inc/internal-links.php';
require_once APPREX_DIR . '/inc/renewal.php';
require_once APPREX_DIR . '/inc/studio.php';
require_once APPREX_DIR . '/inc/manual.php';
require_once APPREX_DIR . '/inc/demo.php';
require_once APPREX_DIR . '/inc/orig.php';
require_once APPREX_DIR . '/inc/orig-genre.php';
require_once APPREX_DIR . '/inc/installer.php';

/**
 * Fallback for the primary menu before the client assigns one in wp-admin.
 * Global nav (現行サイト準拠): 特徴 | 機能 | 料金 | 事例 | HP制作 | 会社概要 | FAQ
 */
function apprex_primary_menu_fallback() {
	$items = array(
		'/features'    => __( '特徴', 'apprex' ),
		'/functions'   => __( '機能', 'apprex' ),
		'/pricing'     => __( '料金', 'apprex' ),
		'/cases'       => __( '事例', 'apprex' ),
		'/estimate'    => __( '見積もり', 'apprex' ),
		'/hp-creation' => __( 'HP制作', 'apprex' ),
		'/blog'        => __( 'ブログ', 'apprex' ),
		'/partner'     => __( '代理店募集', 'apprex' ),
		'/company'     => __( '会社概要', 'apprex' ),
		'/faq'         => __( 'FAQ', 'apprex' ),
	);
	echo '<ul class="menu">';
	foreach ( $items as $path => $label ) {
		printf(
			'<li><a href="%s">%s</a></li>',
			esc_url( home_url( $path ) ),
			esc_html( $label )
		);
	}
	echo '</ul>';
}

/**
 * Zapier chatbot URL (修正要件 §2). Filterable so it can be overridden.
 */
function apprex_chatbot_url() {
	return apply_filters( 'apprex_chatbot_url', 'https://apprex.zapier.app' );
}

/**
 * Inject the floating Zapier chatbot on every page (修正要件 §2 — 全ページ).
 */
function apprex_render_chatbot() {
	get_template_part( 'template-parts/chatbot' );
}
add_action( 'wp_footer', 'apprex_render_chatbot' );
