<?php
/**
 * Site header & global navigation.
 *
 * @package APPREX
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#main"><?php esc_html_e( 'コンテンツへスキップ', 'apprex' ); ?></a>

<?php
$apprex_cb = apprex_campaign_text();
// スマホでは「。」までの短い文にする。
$apprex_cb_short = false !== mb_strpos( $apprex_cb, '。' ) ? mb_substr( $apprex_cb, 0, mb_strpos( $apprex_cb, '。' ) + 1 ) : $apprex_cb;
?>
<div class="campaign-bar">
	<span class="cb-full"><?php echo esc_html( $apprex_cb ); ?></span><span class="cb-short"><?php echo esc_html( $apprex_cb_short ); ?></span>
</div>

<header class="site-header">
	<div class="container site-header__inner">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="site-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<img class="logo-image" src="<?php echo esc_url( APPREX_URI . '/assets/images/apprex-logo.png' ); ?>" alt="APPREX" width="160" height="44">
				</a>
			<?php endif; ?>
		</div>

		<nav class="main-nav" aria-label="<?php esc_attr_e( 'グローバルナビ', 'apprex' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'menu',
					'fallback_cb'    => 'apprex_primary_menu_fallback',
					'depth'          => 1,
				)
			);
			?>
		</nav>

		<div class="header-actions">
			<?php if ( function_exists( 'apprex_chat_is_member' ) && apprex_chat_is_member() ) : ?>
				<a class="btn btn--ghost" href="<?php echo esc_url( apprex_mypage_url() ); ?>">
					<?php esc_html_e( 'マイページ', 'apprex' ); ?>
				</a>
			<?php endif; ?>
			<?php if ( function_exists( 'apprex_rn_enabled' ) && apprex_rn_enabled() ) : ?>
				<a class="btn btn--ghost header-studio" href="<?php echo esc_url( apprex_studio_url() ); ?>">
					<?php echo is_user_logged_in() ? esc_html__( 'AIスタジオ', 'apprex' ) : esc_html__( '無料会員登録', 'apprex' ); ?>
				</a>
			<?php endif; ?>
			<a class="btn btn--primary" href="<?php echo esc_url( apprex_page_url( 'meeting' ) ); ?>">
				<?php esc_html_e( '無料で相談', 'apprex' ); ?>
			</a>
		</div>

		<button class="nav-toggle" aria-expanded="false" aria-controls="mobile-drawer" aria-label="<?php esc_attr_e( 'メニューを開閉', 'apprex' ); ?>">
			<span></span><span></span><span></span>
		</button>
	</div>
</header>

<?php /* モバイルメニューは header の外に配置：site-header の backdrop-filter が position:fixed の包含ブロックになり、ドロワーが潰れる不具合を回避 */ ?>
<div class="mobile-drawer" id="mobile-drawer">
	<?php
	wp_nav_menu(
		array(
			'theme_location' => 'primary',
			'container'      => false,
			'menu_class'     => 'menu',
			'fallback_cb'    => 'apprex_primary_menu_fallback',
			'depth'          => 1,
		)
	);
	?>
	<?php if ( function_exists( 'apprex_rn_enabled' ) && apprex_rn_enabled() ) : ?>
		<a class="btn btn--ghost btn--block" href="<?php echo esc_url( apprex_studio_url() ); ?>">
			<?php esc_html_e( 'AIスタジオ（無料会員登録）', 'apprex' ); ?>
		</a>
	<?php endif; ?>
	<a class="btn btn--primary btn--block" href="<?php echo esc_url( apprex_page_url( 'meeting' ) ); ?>">
		<?php esc_html_e( '無料で相談', 'apprex' ); ?>
	</a>
</div>

<div class="mobile-drawer__overlay" id="mobile-drawer-overlay" hidden></div>

<?php do_action( 'apprex_header_after' ); ?>

<main id="main">
